package com.globalegrow.cs.proxy.deployer;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.globalegrow.cs.proxy.core.client.ClientHandlerFacade;
import com.globalegrow.cs.proxy.core.client.ClientTemplateFacade;
import com.globalegrow.cs.proxy.core.client.server.RedisProxyServer;
import com.globalegrow.cs.proxy.core.context.ProxyContextLocator;
import com.globalegrow.cs.proxy.core.context.ProxyController;

/**
* Title: ProxyManagerLauncher
* Description: 代理启动类
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月8日 下午2:44:49
*/
public class ProxyManagerLauncher
{
	private static final Logger logger = LoggerFactory.getLogger(ProxyManagerLauncher.class);

	public static void main(String[] args) {

		logger.info("## start the manager server.");

		final ProxyController server = ProxyContextLocator.getProxyController();
		
		final RedisProxyServer redisProxyServer = ProxyContextLocator.getRedisProxyServer();
		final ClientHandlerFacade clientHandlerFacade = ProxyContextLocator.getClientHandlerFacade();
		final ClientTemplateFacade clientTemplateFacade = ProxyContextLocator.getClientTemplateFacade();
		
		try {
			logger.info("## start the ProxyController server.");
			server.start();
			logger.info("## start the RedisProxyServer server.");
			redisProxyServer.start();
			logger.info("## start the ClientHandlerFacade server.");
			clientHandlerFacade.start();
			logger.info("## start the ClientTemplateFacade server.");
			clientTemplateFacade.start();
			logger.info("## start over.");
			
			Runtime.getRuntime().addShutdownHook(new Thread(){
				@Override
				public void run() {
					try {
						clientHandlerFacade.stop();
						clientTemplateFacade.stop();
						redisProxyServer.shutdown();
					} catch (Exception e) {
						logger.error("## Something goes wrong when execute server.join():\n{}", 
								ExceptionUtils.getFullStackTrace(e));
					}
				}
			});
		} catch (Throwable e){
			logger.error("## Something goes wrong when starting up the manager Server:\n{}", 
					ExceptionUtils.getFullStackTrace(e));

			System.exit(0);
		}
	}
}