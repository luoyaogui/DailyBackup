package proxy.core.cluster;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.BinaryClient.LIST_POSITION;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisSentinelPool;

public class ListTests{
	private JedisCluster jedisCluster = null;
	private JedisSentinelPool jedisPool = null ;
	
	@Before
	public void initJedisCluster(){
		try {
			jedisCluster = new JedisCluster(new HostAndPort("10.33.4.201", 8379),111111111,11111111,6,"10002:5ca420cd43d557a98e42a74b696f9de0:cluster",new GenericObjectPoolConfig());
			String proxyMasterName = "sentinel-proxy";
			Set<String> proxySentinels = new HashSet<>();
			proxySentinels.add("10.33.4.201:8379");//10.33.4.201:6380
			proxySentinels.add("10.33.4.201:8380");//10.33.4.201:6380
			proxySentinels.add("10.33.4.201:8381");//10.33.4.201:6380
			jedisPool = new JedisSentinelPool(proxyMasterName,proxySentinels,new GenericObjectPoolConfig(),18888888,"10000:f368df13704721db417916e0740a8915:sentinel");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void lpush(){
		for(int i=0;i<10;i++){
			Jedis jedis = jedisPool.getResource(); 
			long count = jedis.lpush("lindex", "lpush-value-3","insert-value-3");
			jedis.close();
			System.out.println(count);
		}
	}
	
	@Test
	public void llen(){
		Jedis jedis = jedisPool.getResource();
		long result = jedis.llen("lindex");
		jedis.close();
		System.out.println(result);
	}
	
	@Test
	public void lpushx(){
		long count = jedisPool.getResource().lpushx("lindex", "lpushx-value-1");
		System.out.println(count);
	}
	
	@Test
	public void brpoplpush(){
		int i = 20 ;
		while(i-- > 0){
		  Jedis jedis = jedisPool.getResource();
//		  List<String> result = jedis.brpop(60,"lindex");
//		  jedis.lpush("bulk01", result.get(1));
		  String oldValue = jedis.brpoplpush("lindex", "bulk01", 60);
		  System.out.println(oldValue+"; bulk01="+jedis.lpop("bulk01"));
		  jedis.close();
		}
	}
	
	@Test
	public void getKeySlot(){
//		int slot = jedisPool.getResource().getCRC16("demo");
	}
	
	@Test
	public void rpushx(){
//		jedis.rpushx("lindex", "val01","val02");
		try {
			Jedis jedis = jedisPool.getResource();
			long c = jedis.rpushx("lindex", "rpush-val-02");
			jedis.close();
			System.out.println(c);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void lrem(){
		long remCount = jedisPool.getResource().lrem("lindex", -1, "insert-value-3");
		System.out.println(remCount);
	}
	
	@Test
	public void lset(){
		String oldVal = jedisPool.getResource().lset("lindex", 2, "new-vale-bylset");
		System.out.println(oldVal);
	}
	
	@Test
	public void ltrim(){
		//只留下第0个元素到第3个位置处的元素
		String re = jedisPool.getResource().ltrim("lindex", 0, 3);
		System.out.println(re);
	}
	
	@Test
	public void lrange(){
		List<String> result = jedisPool.getResource().lrange("lindex", 0, -1);
		System.out.println(result);
	}
	
	@Test
	public void linsert(){
		long result = jedisPool.getResource().linsert("lindex", LIST_POSITION.BEFORE, "lpush-value-3", "insert-value--new3");
		System.out.println(result);
//		jedis.close();
	}
	
	@Test
	public void rpush(){
		Jedis jedis = jedisPool.getResource();
		long count = jedis.rpush("lindex", "rpush-value-1","rpush-value-2","rpush-value-3");
		jedis.close();
		System.out.println(count);
	}
	
	@Test
	public void blpop(){
		try {
			int count = 10;
			while(count > 0){
				Jedis jedis = jedisPool.getResource();
				List<String> result = jedis.blpop(Integer.MAX_VALUE, "lindex");
				System.out.println(result+"; count="+(count));
				count--;
				jedis.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("end of blpop");
	}
	
	@Test
	public void brpop(){
		int count = 10;
		while(count-->0){
			Jedis jedis = jedisPool.getResource();
			List<String> result = jedis.brpop(Integer.MAX_VALUE, "brpop");
			System.out.println(result+"; count="+(count));
			jedis.close();
		}
		System.out.println("end of rpush");
	}
	
	@Test
	public void lindex(){
//		long count = jedisPool.getResource().lpush("lindex", "lindex-value-1","lindex-value-2","lindex-value-3","lindex-value-4");
//		System.out.println(count);
		String valu = jedisPool.getResource().lindex("lindex", -1);
		System.out.println(valu);
	}
	
	/**
	 * cluster 测试
	 */
	@Test
	public void clusterLpush(){
		for(int i=0;i<10;i++){
			long count = jedisCluster.lpush("lindex", "lpush-value-"+i,"insert-value-"+i);
			System.out.println(count);
		}
	}
	
	@Test
	public void clusterLlen(){
		long result = jedisCluster.llen("lindex");
		System.out.println(result);
	}
	
	@Test
	public void clusterLpushx(){
		long count = jedisCluster.lpushx("lindex", "lpushx-value-1");
		System.out.println(count);
	}
	
	@Test
	public void clusterBrpoplpush(){
		int i = 20 ;
		while(i-- > 0){
		  String oldValue = jedisCluster.brpoplpush("lindex", "bulk01", 60);
		  System.out.println(oldValue+"; bulk01="+jedisCluster.lpop("bulk01"));
		}
	}
	
	@Test
	public void clusterGetKeySlot(){
//		int slot = jedisPool.getResource().getCRC16("demo");
	}
	
	@Test
	public void clusterRpushx(){
//		jedis.rpushx("lindex", "val01","val02");
		try {
			long c = jedisCluster.rpushx("lindex", "rpush-val-02");
			System.out.println(c);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void clusterLrem(){
		long remCount = jedisCluster.lrem("lindex", -1, "insert-value-3");
		System.out.println(remCount);
	}
	
	@Test
	public void clusterLset(){
		String oldVal = jedisCluster.lset("lindex", 2, "new-vale-bylset");
		System.out.println(oldVal);
	}
	
	@Test
	public void clusterLtrim(){
		//只留下第0个元素到第3个位置处的元素
		String re = jedisCluster.ltrim("lindex", 0, 3);
		System.out.println(re);
	}
	
	@Test
	public void clusterLrange(){
		List<String> result = jedisCluster.lrange("lindex", 0, -1);
		System.out.println(result);
	}
	
	@Test
	public void clusterLinsert(){
		long result = jedisCluster.linsert("lindex", LIST_POSITION.BEFORE, "lpush-value-3", "insert-value--new3");
		System.out.println(result);
//		jedis.close();
	}
	
	@Test
	public void clusterRpush(){
		long count = jedisCluster.rpush("lindex", "rpush-value-1","rpush-value-2","rpush-value-3");
		System.out.println(count);
	}
	
	@Test
	public void clusterBlpop(){
		try {
			int count = 10;
			while(count > 0){
				List<String> result = jedisCluster.blpop(Integer.MAX_VALUE, "lindex");
				System.out.println(result+"; count="+(count));
				count--;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("end of blpop");
	}
	
	@Test
	public void clusterBrpop(){
		int count = 10;
		while(count-->0){
			List<String> result = jedisCluster.brpop(Integer.MAX_VALUE, "brpop");
			System.out.println(result+"; count="+(count));
		}
		System.out.println("end of rpush");
	}
	
	@Test
	public void clusterLindex(){
//		long count = jedisPool.getResource().lpush("lindex", "lindex-value-1","lindex-value-2","lindex-value-3","lindex-value-4");
//		System.out.println(count);
		String valu = jedisCluster.lindex("lindex", -1);
		System.out.println(valu);
	}
	
	@After
	public void destory(){
		jedisPool.close();
	}
}
