package proxy.core.standalone;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Response;
import redis.clients.jedis.Transaction;

public class RedisProxyPoolTest {

	public JedisPool jedisPool ;
	
	@Before
	public void standAlonePoolTest(){
//		jedisPool = new JedisPool(new GenericObjectPoolConfig(), "127.0.0.1", 6379,2000, "10017:b1bc670b54b3c9334bc57e0ab6390375");
		jedisPool = new JedisPool(new GenericObjectPoolConfig(), "10.33.4.201",8080,Integer.MAX_VALUE, "10025:3c2ef2f7252e8f731bba0b5074b27827");
//		jedisPool = new JedisPool(new GenericObjectPoolConfig(), "10.40.6.118",6405,1112000);
	}
	
	@Test
	public void stingSetCmd(){
		Jedis jedis = jedisPool.getResource();
		String returnStatus = jedis.set("sentine-set-test", "set time="+new Date().toString());
		System.out.println(returnStatus);
		jedis.close();
	}
	
	@Test
	public void stringAllCmdClusterTest(){
		long s = System.currentTimeMillis();
		for(int i=0;i<1;i++){
			System.out.println(i);
			Jedis jedisCluster = jedisPool.getResource();
			jedisCluster.set("cluster_"+i, "cluster-value-"+i);
			jedisCluster.get("cluster_"+i);
			jedisCluster.getrange("cluster_"+i, 0, 3);
			jedisCluster.getSet("cluster_"+i,"cluster-new-value");
			jedisCluster.get("cluster_"+i);
			jedisCluster.setbit("cluster-bit-"+i, 3, true);
			jedisCluster.getbit("cluster-bit-"+i, 3);
			jedisCluster.setex("cluster-expire-"+i, 10, "cluster-expire-value");
			jedisCluster.setnx("cluster-setnx-"+i, "cluster-setnx-value-"+i);
			jedisCluster.get("cluster-setnx-"+i);
			jedisCluster.strlen("cluster-setnx-"+i);
			jedisCluster.set("cluster-incr-"+i, "2");
			jedisCluster.incr("cluster-incr-"+i);
			jedisCluster.incrBy("cluster-incr-"+i, 10);
			jedisCluster.get("cluster-incr-"+i);
			jedisCluster.set("cluster-float-"+i, "10.12");
			jedisCluster.incrByFloat("cluster-float-"+i, 1.12);
			jedisCluster.get("cluster-float-"+i);
			jedisCluster.get("cluster-incr-"+i);
			jedisCluster.decr("cluster-incr");
			jedisCluster.decrBy("cluster-incr-"+i, 3);
			jedisCluster.set("cluster-append-"+i, "init-value-"+i);
			jedisCluster.append("cluster-append-"+i, "-append-new");
			jedisCluster.get("cluster-append-"+i);
//			TimeUnit.MILLISECONDS.sleep(10);
			jedisCluster.close();
		}
		System.out.println("cost:"+(System.currentTimeMillis()-s));
	}
	
	@Test
	public void getJedis() throws Exception{
		while(true){
			try {
				Jedis jedis = jedisPool.getResource();
				System.out.println(jedis);
				String setS = jedis.set("all-cmd-set", "all-cmd-set-value");
				System.out.println(setS+";"+jedis.get("all-cmd-set"));
				jedis.close();
				TimeUnit.SECONDS.sleep(1);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	@Test
	public void testDisconnect(){
		
	}
	
	@Test
	public void stringAllCmdTest() throws Exception{
		long start = System.currentTimeMillis();
		for(int i=0;i<100;i++){
			Jedis jedis = jedisPool.getResource();
			String setS = jedis.set("all-cmd-set", "all-cmd-set-value");
			System.out.println("set response:"+setS+"; append:"+jedis.append("all-cmd-set", "-append-value"));
			String getS = jedis.get("all-cmd-set");
			System.out.println("get response:"+getS);
			String getrange = jedis.getrange("all-cmd-set", 0, 3);
			System.out.println("get range:"+getrange);
			String getset = jedis.getSet("all-cmd-set", "all-cmd-set-value-new");
			System.out.println("get set :"+getset);
			boolean getbit = jedis.getbit("all-cmd-getbit", 10);
			System.out.println("get bit:"+getbit);
			boolean setbit = jedis.setbit("all-cmd-getbit", 10l,true);
			System.out.println("set bit:"+setbit+"; after set bit:"+jedis.getbit("all-cmd-getbit", 10));
			String setex = jedis.setex("all-cmd-setex", 60, "all-cmd-setex-expire");
			System.out.println("set expire:"+setex);
			long setnx_1 = jedis.setnx("all-cmd-setnx", "all-cmd-setnx");
			long setnx_2 = jedis.setnx("all-cmd-setnx", "all-cmd-setnx");
			System.out.println("setnx 1:"+setnx_1+"; setnx 2:"+setnx_2);
			long setrange = jedis.setrange("all-cmd-set", 8, "setrange");
			System.out.println("set range:"+setrange+"; get after set range��"+jedis.get("1all-cmd-set"));
			long strlen = jedis.strlen("all-cmd-set");
			System.out.println("str len[all-cmd-set]:"+strlen+"; the value is:"+jedis.get("all-cmd-set"));
			String mset = jedis.mset("mset-key-1","mset-value-1","mset-key-2","met-value-2");
			List<String> mget = jedis.mget("mset-key-1","mset-ket-2");
			System.out.println("mset:"+mset+"; after mset mget is:"+mget);
			long msetnx = jedis.msetnx("mset-key-2","mset-value-2","mset-key-3","mset-value-3");
			System.out.println("mset nx:"+msetnx);
			String psetex = jedis.psetex("mset-key-1", 1000*60, "mset-value-new-1");
			System.out.println("psetex:"+psetex+"; get[mset-key-1]:"+jedis.get("mset-key-1"));
			jedis.set("all-cmd-incr", "1");
			System.out.println("incr:"+jedis.incr("all-cmd-incr"));
			System.out.println("incrby:"+jedis.incrBy("all-cmd-incr", 10)+"; decr:"+jedis.decr("all-cmd-incr")+"; decr by:"+jedis.decrBy("all-cmd-incr", 3));
			jedis.set("all-cmd-incr-float", "1.02");
			System.out.println("incr float:"+jedis.incrByFloat("all-cmd-incr-float", 1.05));
			jedis.close();
//			TimeUnit.SECONDS.sleep(1);
		}
		System.out.println("cost time:"+(System.currentTimeMillis()-start));
		TimeUnit.SECONDS.sleep(Integer.MAX_VALUE);
	}
	
	@Test
	public void transAction(){
		Jedis jedis = jedisPool.getResource();
		Response<String> response;
		try {
			Transaction transaction = jedis.multi();
			jedis.watch("hash");
			transaction.hset("hash", "field-1", "value-1");
			transaction.hset("hash", "field-2", "value-2");
			response = transaction.ping();
			List<Object> result = transaction.exec();
			for(Object val : result){
				System.out.println(val.toString());
			}
			System.out.println(response.get());
			System.out.println(jedis.hget("hash", "field-1"));
			System.out.println(jedis.hget("hash", "field-2"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void watcher(){
		Jedis jedis = jedisPool.getResource();
		jedis.set("key01", "other-setvalue01");
		jedis.set("key02", "other-setvalue02");
		Transaction t = jedis.multi();//���ʱ�������������������ʾ����Ŀ�ʼ��
		t.set("key01", "value01");
		t.set("key02", "value02");
//		System.out.println("watcher response:"+watch);
		List<Object> result = t.exec();//�������������ִ��������
		System.out.println(result);
		String re = jedis.get("key01");
		jedis.close();
		System.out.println("key01="+re+"; "+re.equals("value01"));
	}
	
	@Test
	public void unwather(){
		Jedis jedis = jedisPool.getResource();
		jedis.watch("key01","key02");
		jedisPool.getResource().set("key01", "other-setvalue01");
		jedisPool.getResource().set("key02", "other-setvalue02");
		String status = jedis.unwatch();
		System.out.println(status);
		
		Transaction t = jedis.multi();
		t.set("key01", "value01");
		t.set("key02", "value02");
		List<Object> result = t.exec();
		System.out.println(result);
		String re = jedis.get("key01");
		System.out.println("key01="+re+"; "+re.equals("value01"));
	}
	
	
	@Test
	public void blocklist(){
		Jedis jedis = jedisPool.getResource();
		jedis.lpush("blist", "value-1","value-2","value-3","value-4");
		List<String> values = jedis.blpop("blist");
		System.out.println(values);
		jedis.close();
	}
	
	@After
	public void afterTest(){
		jedisPool.close();
	}
	
	
}
