package proxy.core.zk;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.zookeeper.KeeperException.NoNodeException;
import org.junit.Before;
import org.junit.Test;

import com.globalegrow.cs.proxy.core.arbitrate.ZKArbitrateService;
import com.globalegrow.cs.proxy.core.monitor.GlobalManager;import com.globalegrow.cs.shared.common.utils.JsonUtils;
import com.globalegrow.cs.shared.common.utils.StringUtil;
import com.globalegrow.cs.shared.config.base.HostAndPort;
import com.globalegrow.cs.shared.config.zk.base.ProxyNodeParameter;
import com.globalegrow.cs.shared.config.zk.listener.ZKDataListener;
import com.globalegrow.cs.shared.config.zk.store.ZKNodeTree;

public class ZKlistenTest {
	private ZKArbitrateService service = new ZKArbitrateService();
	
	@Before
	public void init(){
		try {
//			service.start("127.0.0.1:2181", "testGroup", 1);
			ProxyNodeParameter param = new ProxyNodeParameter();
//			param.setZkAddresses("10.40.6.100:2181,10.40.6.101:2181,10.40.6.102:2181");
			param.setZkAddresses("127.0.0.1:2181");
			param.setCloseOuterIP(true);
			param.setBelongProxyGroup("proxy-xiaoluo-test");
			param.setIp("10.40.6.122");
			param.setPort(8992);
			GlobalManager.getInstance().setProxyUuid(2);//保存参数
			GlobalManager.getInstance().setParamConfig(param);//保存参数，共享
			service.start();
		} catch (Exception e) {
			e.printStackTrace();
			service = null;
		}
	}

	@Test
	public void testConn(){
		try {
			TimeUnit.SECONDS.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		print();
		/*try {
			TimeUnit.SECONDS.sleep(5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		print();
		try {
			TimeUnit.SECONDS.sleep(15);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		print();
		try {
			TimeUnit.SECONDS.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
	}
	private void print(){
		System.out.println("------------------------------");
		//ZKNodeTree.getInstance().print();
	}
}
