package proxy.core.cluster;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisSentinelPool;

public class HashTests {

	private JedisCluster jedisCluster = null;
	private JedisSentinelPool jedisPool = null ;
	
	@Before
	public void initJedisCluster(){
		try {
			jedisCluster = new JedisCluster(new HostAndPort("10.33.4.201", 6379),111111111,11111111,6,"10002:5ca420cd43d557a98e42a74b696f9de0:cluster",new GenericObjectPoolConfig());
			String proxyMasterName = "sentinel-proxy";
			Set<String> proxySentinels = new HashSet<>();
			proxySentinels.add("10.33.4.201:6379");//10.33.4.201:6380
			proxySentinels.add("10.33.4.201:6390");//10.33.4.201:6380
			proxySentinels.add("10.33.4.201:6391");//10.33.4.201:6380
			jedisPool = new JedisSentinelPool(proxyMasterName,proxySentinels,new GenericObjectPoolConfig(),18888888,"10000:f368df13704721db417916e0740a8915:sentinel");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void hset(){
		Jedis jedis = jedisPool.getResource();
		long l = jedisCluster.hset("person", "age", "21");
		System.out.println(l);
		l =jedisCluster.hset("person", "name", "globalegrow");
		System.out.println(l);
		l =jedisCluster.hset("person", "tel", "8688699");
		System.out.println(l);
	}
	
	@Test
	public void hget(){
		Jedis jedis = jedisPool.getResource();
		String val = jedisCluster.hget("person", "age");
		System.out.println("age="+val);
		val = jedisCluster.hget("person", "name");
		System.out.println("name="+val);
		val = jedisCluster.hget("person", "tel");
		System.out.println("tel="+val);
	}
	
	@Test
	public void hexists(){
		System.out.println(jedisCluster.hexists("person", "age"));
//		System.out.println(jedisPool.getResource().hexists("person", "age"));
	}
	
	@Test
	public void hgetAll(){
		Map<String,String> resultMap = jedisCluster.hgetAll("person");
		for(Entry<String, String> entry:resultMap.entrySet()){
			System.out.println(entry.getKey()+"="+entry.getValue());
		}
	}
	
	@Test
	public void hincrby(){
//		Jedis jedis = jedisPool.getResource();
		long l = jedisCluster.hincrBy("person", "age", 2);
		System.out.println(l+"; age="+jedisCluster.hget("person", "age"));
	}
	
	@Test
	public void hincrbyfloat(){
//		Jedis jedis = jedisPool.getResource();
		double l = jedisCluster.hincrByFloat("person".getBytes(),"age".getBytes(),2.3);
		System.out.println(l+"; age="+jedisCluster.hget("person", "age"));
	}
	
	@Test
	public void hkeys(){
//		Jedis jedis = jedisPool.getResource();
		Set<String> keys = jedisCluster.hkeys("person");
		for(String key:keys){
			System.out.println(key);
		}
	}
	
	@Test
	public void hlen(){
//		Jedis jedis = jedisPool.getResource();
		System.out.println(jedisCluster.hlen("person"));
	}
	
	@Test
	public void hmget(){
//		Jedis jedis = jedisPool.getResource();
		List<String> val = jedisCluster.hmget("person", "age","name");
		System.out.println(val);
	}
	
	@Test
	public void hmset(){
//		Jedis jedis = jedisPool.getResource();
		Map<String,String> valMap = new HashMap<String,String>();
		valMap.put("wife", "youku");
		valMap.put("address", "广东省深圳市");
		String result = jedisCluster.hmset("person",valMap);
		System.out.println(result);
	}
	
	@Test
	public void hvals(){
//		Jedis jedis = jedisPool.getResource();
		List<String> vals = jedisCluster.hvals("person");
		System.out.println(vals);
	}
	
	@Test
	public void hsetnx(){
//		Jedis jedis = jedisPool.getResource();
		long l = jedisCluster.hsetnx("person", "age", "100");
		System.out.println(l);
		l = jedisCluster.hsetnx("person", "age_01", "100");
		System.out.println(l);
	}
	
	@After
	public void finalize(){
		jedisCluster.close();
		jedisPool.close();
	}
	
}
