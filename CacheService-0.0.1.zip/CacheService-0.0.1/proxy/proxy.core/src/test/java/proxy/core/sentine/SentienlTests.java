package proxy.core.sentine;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisSentinelPool;
import redis.clients.jedis.Response;
import redis.clients.jedis.Transaction;

public class SentienlTests {

	private JedisSentinelPool jedisSentinelPool;
	private JedisSentinelPool proxyJedisSentinelPool;
	
	@Before
	public void sentinelInit(){
//		String masterName = "sentinel-10.40.6.118-6406";
//		Set<String> sentinels = new HashSet<>();
//		sentinels.add("10.40.6.118:6408");
//		sentinels.add("10.40.6.118:6409");
//		sentinels.add("10.40.6.118:6410");
//		jedisSentinelPool = new JedisSentinelPool(masterName, sentinels, new GenericObjectPoolConfig());
		
		String proxyMasterName = "sentinel-proxy";
		Set<String> proxySentinels = new HashSet<>();
		proxySentinels.add("10.33.4.201:8080");
//		proxySentinels.add("10.33.4.201:6380");
//		proxySentinels.add("10.33.4.201:6381");
		proxyJedisSentinelPool = new JedisSentinelPool(proxyMasterName,proxySentinels,new GenericObjectPoolConfig(),18888888,"10025:3c2ef2f7252e8f731bba0b5074b27827");
	}
	
	@Test
	public void sentinelMater() throws Exception{
		System.out.println(proxyJedisSentinelPool.getCurrentHostMaster());
		Jedis jedis = proxyJedisSentinelPool.getResource();
		String re = jedis.select(1);
		System.out.println(re);
	}

	@Test
	public void stingSetCmd(){
		Jedis jedis = proxyJedisSentinelPool.getResource();
		String returnStatus = jedis.set("sentine-set-test", "set time="+new Date().toString());
		System.out.println(returnStatus);
		jedis.close();
	}
	
	@Test
	public void stringAllCmdClusterTest(){
		long s = System.currentTimeMillis();
		for(int i=0;i<1;i++){
			System.out.println(i);
			Jedis jedisCluster = proxyJedisSentinelPool.getResource();
			jedisCluster.set("cluster_"+i, "cluster-value-"+i);
			jedisCluster.get("cluster_"+i);
			jedisCluster.getrange("cluster_"+i, 0, 3);
			jedisCluster.getSet("cluster_"+i,"cluster-new-value");
			jedisCluster.get("cluster_"+i);
			jedisCluster.setbit("cluster-bit-"+i, 3, true);
			jedisCluster.getbit("cluster-bit-"+i, 3);
			jedisCluster.setex("cluster-expire-"+i, 10, "cluster-expire-value");
			jedisCluster.setnx("cluster-setnx-"+i, "cluster-setnx-value-"+i);
			jedisCluster.get("cluster-setnx-"+i);
			jedisCluster.strlen("cluster-setnx-"+i);
			jedisCluster.set("cluster-incr-"+i, "2");
			jedisCluster.incr("cluster-incr-"+i);
			jedisCluster.incrBy("cluster-incr-"+i, 10);
			jedisCluster.get("cluster-incr-"+i);
			jedisCluster.set("cluster-float-"+i, "10.12");
			jedisCluster.incrByFloat("cluster-float-"+i, 1.12);
			jedisCluster.get("cluster-float-"+i);
			jedisCluster.get("cluster-incr-"+i);
			jedisCluster.decr("cluster-incr");
			jedisCluster.decrBy("cluster-incr-"+i, 3);
			jedisCluster.set("cluster-append-"+i, "init-value-"+i);
			jedisCluster.append("cluster-append-"+i, "-append-new");
			jedisCluster.get("cluster-append-"+i);
//			TimeUnit.MILLISECONDS.sleep(10);
			jedisCluster.close();
		}
		System.out.println("cost:"+(System.currentTimeMillis()-s));
	}
	
	@Test
	public void getJedis() throws Exception{
		while(true){
			try {
				Jedis jedis = proxyJedisSentinelPool.getResource();
				System.out.println(jedis);
				String setS = jedis.set("all-cmd-set", "all-cmd-set-value");
				System.out.println(setS+";"+jedis.get("all-cmd-set"));
				jedis.close();
				TimeUnit.SECONDS.sleep(1);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	@Test
	public void testEventLoop(){
		
	}
	
	@Test
	public void stringAllCmdTest() throws Exception{
		long start = System.currentTimeMillis();
		for(int i=0;i<100;i++){
			Jedis jedis = proxyJedisSentinelPool.getResource();
			String setS = jedis.set("all-cmd-set", "all-cmd-set-value");
			System.out.println("set response:"+setS+"; append:"+jedis.append("all-cmd-set", "-append-value"));
			String getS = jedis.get("all-cmd-set");
			System.out.println("get response:"+getS);
			String getrange = jedis.getrange("all-cmd-set", 0, 3);
			System.out.println("get range:"+getrange);
			String getset = jedis.getSet("all-cmd-set", "all-cmd-set-value-new");
			System.out.println("get set :"+getset);
			boolean getbit = jedis.getbit("all-cmd-getbit", 10);
			System.out.println("get bit:"+getbit);
			boolean setbit = jedis.setbit("all-cmd-getbit", 10l,true);
			System.out.println("set bit:"+setbit+"; after set bit:"+jedis.getbit("all-cmd-getbit", 10));
			String setex = jedis.setex("all-cmd-setex", 60, "all-cmd-setex-expire");
			System.out.println("set expire:"+setex);
			long setnx_1 = jedis.setnx("all-cmd-setnx", "all-cmd-setnx");
			long setnx_2 = jedis.setnx("all-cmd-setnx", "all-cmd-setnx");
			System.out.println("setnx 1:"+setnx_1+"; setnx 2:"+setnx_2);
			long setrange = jedis.setrange("all-cmd-set", 8, "setrange");
			System.out.println("set range:"+setrange+"; get after set range："+jedis.get("1all-cmd-set"));
			long strlen = jedis.strlen("all-cmd-set");
			System.out.println("str len[all-cmd-set]:"+strlen+"; the value is:"+jedis.get("all-cmd-set"));
			String mset = jedis.mset("mset-key-1","mset-value-1","mset-key-2","met-value-2");
			List<String> mget = jedis.mget("mset-key-1","mset-ket-2");
			System.out.println("mset:"+mset+"; after mset mget is:"+mget);
			long msetnx = jedis.msetnx("mset-key-2","mset-value-2","mset-key-3","mset-value-3");
			System.out.println("mset nx:"+msetnx);
			String psetex = jedis.psetex("mset-key-1", 1000*60, "mset-value-new-1");
			System.out.println("psetex:"+psetex+"; get[mset-key-1]:"+jedis.get("mset-key-1"));
			jedis.set("all-cmd-incr", "1");
			System.out.println("incr:"+jedis.incr("all-cmd-incr"));
			System.out.println("incrby:"+jedis.incrBy("all-cmd-incr", 10)+"; decr:"+jedis.decr("all-cmd-incr")+"; decr by:"+jedis.decrBy("all-cmd-incr", 3));
			jedis.set("all-cmd-incr-float", "1.02");
			System.out.println("incr float:"+jedis.incrByFloat("all-cmd-incr-float", 1.05));
			jedis.close();
//			TimeUnit.SECONDS.sleep(1);
		}
		System.out.println("cost time:"+(System.currentTimeMillis()-start));
		TimeUnit.SECONDS.sleep(Integer.MAX_VALUE);
	}
	
	@Test
	public void transAction(){
		Jedis jedis = proxyJedisSentinelPool.getResource();
		Response<String> response;
		try {
			Transaction transaction = jedis.multi();
			transaction.hset("hash", "field-1", "value-1");
			transaction.hset("hash", "field-2", "value-2");
			response = transaction.ping();
			List<Object> result = transaction.exec();
			for(Object val : result){
				System.out.println(val.toString());
			}
			System.out.println(response.get());
			System.out.println(jedis.hget("hash", "field-1"));
			System.out.println(jedis.hget("hash", "field-2"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	@After
	public void destory(){
		if(jedisSentinelPool!=null)
			jedisSentinelPool.close();
		if(proxyJedisSentinelPool!=null)
			proxyJedisSentinelPool.close();
	}
}
