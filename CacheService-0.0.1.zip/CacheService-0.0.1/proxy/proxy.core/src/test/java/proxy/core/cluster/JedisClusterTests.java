package proxy.core.cluster;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.globalegrow.cs.proxy.core.client.ClientTemplateFacade;
import com.globalegrow.cs.shared.config.base.PointSlot;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

public class JedisClusterTests {

	private JedisCluster jedisCluster = null;
	
	@Before
	public void initJedisCluster(){
		try {
			jedisCluster = new JedisCluster(new HostAndPort("10.33.4.201", 6379),111111111,11111111,6,"10002:5ca420cd43d557a98e42a74b696f9de0:cluster",new GenericObjectPoolConfig());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void generTemplate(){
		List<com.globalegrow.cs.shared.config.base.HostAndPort> listProxyServer = new ArrayList<com.globalegrow.cs.shared.config.base.HostAndPort>();
		listProxyServer.add(new com.globalegrow.cs.shared.config.base.HostAndPort("10.32.4.202", 8080));
		listProxyServer.add(new com.globalegrow.cs.shared.config.base.HostAndPort("10.32.4.202", 8081));
		listProxyServer.add(new com.globalegrow.cs.shared.config.base.HostAndPort("10.32.4.202", 8082));
		List<PointSlot> pointSlots = ClientTemplateFacade.generSlotsRange(3);
		listProxyServer.get(0).setPointSlot(pointSlots.get(0));
		listProxyServer.get(1).setPointSlot(pointSlots.get(1));
		listProxyServer.get(2).setPointSlot(pointSlots.get(2));
		ClientTemplateFacade.generatorClusterNodesTemplate(listProxyServer);
	}
	
	@Test
	public void jedisClusterConnect(){
		System.out.println(jedisCluster);
		String response = jedisCluster.set("cluster", "value-cluster-1");
		System.out.println(response);
	}
	
	@Test
	public void stringCmd(){
		long s = System.currentTimeMillis();
		for(int i=0;i<1000;i++){
			System.out.println(i);
			try {
				jedisCluster.set("cluster_"+i, "cluster-value-"+i);
				jedisCluster.get("cluster_"+i);
				TimeUnit.SECONDS.sleep(3);;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("cost:"+(System.currentTimeMillis()-s));
	}
	
	@Test
	public void stringAllCmd(){
		long s = System.currentTimeMillis();
		for(int i=0;i<1000;i++){
			System.out.println(i);
			try {
				jedisCluster.set("cluster_"+i, "cluster-value-"+i);
				jedisCluster.get("cluster_"+i);
				jedisCluster.getrange("cluster_"+i, 0, 3);
				jedisCluster.getSet("cluster_"+i,"cluster-new-value");
				jedisCluster.get("cluster_"+i);
				jedisCluster.setbit("cluster-bit-"+i, 3, true);
				jedisCluster.getbit("cluster-bit-"+i, 3);
				jedisCluster.setex("cluster-expire-"+i, 10, "cluster-expire-value");
				jedisCluster.setnx("cluster-setnx-"+i, "cluster-setnx-value-"+i);
				jedisCluster.get("cluster-setnx-"+i);
				jedisCluster.strlen("cluster-setnx-"+i);
				jedisCluster.set("cluster-incr-"+i, "2");
				jedisCluster.incr("cluster-incr-"+i);
				jedisCluster.incrBy("cluster-incr-"+i, 10);
				jedisCluster.get("cluster-incr-"+i);
				jedisCluster.set("cluster-float-"+i, "10.12");
				jedisCluster.incrByFloat("cluster-float-"+i, 1.12);
				jedisCluster.get("cluster-float-"+i);
				jedisCluster.get("cluster-incr-"+i);
				jedisCluster.decr("cluster-incr");
				jedisCluster.decrBy("cluster-incr-"+i, 3);
				jedisCluster.set("cluster-append-"+i, "init-value-"+i);
				jedisCluster.append("cluster-append-"+i, "-append-new");
				jedisCluster.get("cluster-append-"+i);
				TimeUnit.SECONDS.sleep(1);;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("cost:"+(System.currentTimeMillis()-s));
	}
	
	@Test
	public void hashAllCmd(){
		
	}
	
	@After
	public void jedisclusterDestory(){
		jedisCluster.close();
	}
}
