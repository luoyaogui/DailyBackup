package proxy.core.sentine;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import com.globalegrow.cs.proxy.core.client.event.EventObjectDispatcher;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.loop.AsyncEventLoopGroup;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Executor;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisSentinelPool;

public class SentinelEventLoop extends AsyncEventLoopGroup<JedisSentinelPool> {
	public SentinelEventLoop(Executor executor, long loopInterval) {
		super(executor, loopInterval);
	}

	public SentinelEventLoop(String executorName, long loopInterval) {
		super(executorName, loopInterval);
	}

	@Override
	public void attachListener() {
		this.addLast(new PipelineObjectListener<JedisSentinelPool>() {
			private AtomicInteger acount = new AtomicInteger(0);
			@Override
			public boolean onEvent(ObjectEvent<JedisSentinelPool> event, int listenerIndex) {

				if(acount.incrementAndGet()>Integer.MAX_VALUE){
					return true ;
				}
				JedisSentinelPool jedisPool = event.getValue();
				System.err.println("the count of execute is："+acount.get());
				Jedis jedis = jedisPool.getResource();
				String setS = jedis.set("all-cmd-set", "all-cmd-set-value");
				System.out.println("set response:"+setS+"; append:"+jedis.append("all-cmd-set", "-append-value"));
				String getS = jedis.get("all-cmd-set");
				System.out.println("get response:"+getS);
				String getrange = jedis.getrange("all-cmd-set", 0, 3);
				System.out.println("get range:"+getrange);
				String getset = jedis.getSet("all-cmd-set", "all-cmd-set-value-new");
				System.out.println("get set :"+getset);
				boolean getbit = jedis.getbit("all-cmd-getbit", 10);
				System.out.println("get bit:"+getbit);
				boolean setbit = jedis.setbit("all-cmd-getbit", 10l,true);
				System.out.println("set bit:"+setbit+"; after set bit:"+jedis.getbit("all-cmd-getbit", 10));
				String setex = jedis.setex("all-cmd-setex", 60, "all-cmd-setex-expire");
				System.out.println("set expire:"+setex);
				long setnx_1 = jedis.setnx("all-cmd-setnx", "all-cmd-setnx");
				long setnx_2 = jedis.setnx("all-cmd-setnx", "all-cmd-setnx");
				System.out.println("setnx 1:"+setnx_1+"; setnx 2:"+setnx_2);
				long setrange = jedis.setrange("all-cmd-set", 8, "setrange");
				System.out.println("set range:"+setrange+"; get after set range："+jedis.get("1all-cmd-set"));
				long strlen = jedis.strlen("all-cmd-set");
				System.out.println("str len[all-cmd-set]:"+strlen+"; the value is:"+jedis.get("all-cmd-set"));
				String mset = jedis.mset("mset-key-1","mset-value-1","mset-key-2","met-value-2");
				List<String> mget = jedis.mget("mset-key-1","mset-ket-2");
				System.out.println("mset:"+mset+"; after mset mget is:"+mget);
				long msetnx = jedis.msetnx("mset-key-2","mset-value-2","mset-key-3","mset-value-3");
				System.out.println("mset nx:"+msetnx);
				String psetex = jedis.psetex("mset-key-1", 1000*60, "mset-value-new-1");
				System.out.println("psetex:"+psetex+"; get[mset-key-1]:"+jedis.get("mset-key-1"));
				jedis.set("all-cmd-incr", "1");
				System.out.println("incr:"+jedis.incr("all-cmd-incr"));
				System.out.println("incrby:"+jedis.incrBy("all-cmd-incr", 10)+"; decr:"+jedis.decr("all-cmd-incr")+"; decr by:"+jedis.decrBy("all-cmd-incr", 3));
				jedis.set("all-cmd-incr-float", "1.02");
				System.out.println("incr float:"+jedis.incrByFloat("all-cmd-incr-float", 1.05));
				jedis.close();
				return false;
			}
		}, 1);
	}
	
	public static void main(String[] args) {
		String proxyMasterName = "sentinel-proxy";
		Set<String> proxySentinels = new HashSet<>();
		proxySentinels.add("10.33.4.201:8080");
		JedisSentinelPool proxyJedisSentinelPool = new JedisSentinelPool(proxyMasterName,proxySentinels,new GenericObjectPoolConfig(),18888888,"10025:3c2ef2f7252e8f731bba0b5074b27827");
		SentinelEventLoop sentinelEventLoop = new SentinelEventLoop(EventObjectDispatcher.BLOCK_EXECUTOR,1);
		sentinelEventLoop.publish(proxyJedisSentinelPool, 1);
	}
}
