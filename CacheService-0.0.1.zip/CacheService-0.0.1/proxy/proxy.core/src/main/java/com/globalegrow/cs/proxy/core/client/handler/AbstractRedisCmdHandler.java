package com.globalegrow.cs.proxy.core.client.handler;

import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import io.netty.channel.Channel;
import redis.clients.jedis.Protocol;
import redis.clients.jedis.exceptions.JedisConnectionException;

public abstract class AbstractRedisCmdHandler implements IRedisCmdHandler {

	@Override
	public abstract void execute(final Channel channel,final RedisMessage redisMessage);

	/**
	 * 决定这个response message 是否需要返回给客户端。 目前只有这两个消息不需要返回给客户端： moved,ask
	 * 
	 * @param response
	 * @return
	 */
	public boolean process(byte[] response) {
		int count = 0;
		final byte b = response[count++];
		if (b == Protocol.MINUS_BYTE) {
			String message = readLine(response, count);
			if (message.startsWith(Protocol.MOVED_RESPONSE) || message.startsWith(Protocol.ASK_RESPONSE)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * read the error response from the redis server
	 * @param buf
	 * @param count
	 * @return
	 */
	public String readLine(byte[] buf, int count) {
		final StringBuilder sb = new StringBuilder();
		while (true) {
			byte b = buf[count++];
			if (b == '\r') {
				byte c = buf[count++];
				if (c == '\n') {
					break;
				}
				sb.append((char) b);
				sb.append((char) c);
			} else {
				sb.append((char) b);
			}
		}

		final String reply = sb.toString();
		if (reply.length() == 0) {
			throw new JedisConnectionException("It seems like server has closed the connection.");
		}

		return reply;
	}

}
