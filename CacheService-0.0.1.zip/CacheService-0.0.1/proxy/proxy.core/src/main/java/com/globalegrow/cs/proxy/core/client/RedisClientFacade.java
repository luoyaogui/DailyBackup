package com.globalegrow.cs.proxy.core.client;

import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.TimeUnit;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import com.globalegrow.cs.shared.common.exception.InitRedisServerBootstrapException;
import com.globalegrow.cs.shared.config.base.AppInstanceInfo;
import com.globalegrow.cs.shared.event.common.Facade;
import com.globalegrow.cs.shared.event.common.IdempotentConfirmer;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisSentinelPool;

/**
 * 代理跟redis server 连接的 统一处理class.
 * 这里将会记录每一个app 的channel 所对应的Jedis。
 * 即：每一个channel 都会对应自己的Jedis。
 * @author pengbingting
 *
 */
public class RedisClientFacade implements Facade{
	private final static ConcurrentHashMap<Integer, JedisPool> jedisPoolRegister = new ConcurrentHashMap<Integer, JedisPool>();
	private final static ConcurrentHashMap<Integer, JedisCluster> jedisCluterRegister = new ConcurrentHashMap<Integer, JedisCluster>();
	private final static ConcurrentHashMap<Integer, JedisSentinelPool> jedisSentinelRegister = new ConcurrentHashMap<Integer, JedisSentinelPool>();
	/**
	 * 将客户端所有以集群方式连接的给
	 */
	public final static ConcurrentHashMap<String, Channel> redisClientClusterChannelRegister = new ConcurrentHashMap<String, Channel>();
	
	/**
	 * 一级分类：按 app id 分
	 * 二级分类：每一个channel 都会对应自己的Jedis。而这些个channel 都是属于某一个app id
	 */
	
	public final static ConcurrentHashMap<Integer, ConcurrentHashMap<String, Jedis>> redisClientJedisRegister = new ConcurrentHashMap<Integer, ConcurrentHashMap<String, Jedis>>();
	/**
	 * app id check status.
	 */
	private final static ConcurrentMap<Integer, ConcurrentHashMap<Integer,CheckStatus>> checkStatusRegister = 
										new ConcurrentHashMap<Integer, ConcurrentHashMap<Integer,CheckStatus>>();
	/**
	 * 跟订阅相关的channel。{key,value}={remote address,channel}
	 */
	private static final ConcurrentHashMap<String, Channel> subscribeChannelRegister = new ConcurrentHashMap<String, Channel>();
	/**
	 * 这里将会记住所有客户端 所subscribe topic to channel register.
	 * {key,value}={channel topic,channel}
	 */
	private static final ConcurrentHashMap<String, ConcurrentSkipListMap<String,Channel>> subscribeTopicChannelRegister = new ConcurrentHashMap<String, ConcurrentSkipListMap<String,Channel>>();
	
	/**
	 * 
	 * @param appid
	 * @param channel
	 * @return if have initialize,then return false,if return -1,then app id is error,-2 then app
	 */
	public static boolean init(int appId,String appKey,AppInstanceInfo appInstanceInfo,final Channel channel){
		if(jedisCluterRegister.containsKey(appId)){
			return true;
		}

		if(jedisPoolRegister.containsKey(appId)){
			return true;
		}
		
		if(jedisSentinelRegister.containsKey(appId)){
			return true;
		}
		
		//Here you can certainly get the type of application deployment
		boolean result = new InitIdempotentConfirmer(3,appId,appKey,channel,appInstanceInfo).run();
		
		Log.info("the result of initialize the redis client of app id ["+appId+"] is :"+result+", channel="+channel.toString());
		
		return result;
	}
	
	private static GenericObjectPoolConfig getGenericObjectPoolConfig(){
		GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
		poolConfig.setMaxTotal(GenericObjectPoolConfig.DEFAULT_MAX_TOTAL * 3);
		poolConfig.setMaxIdle(GenericObjectPoolConfig.DEFAULT_MAX_IDLE * 2);
		poolConfig.setMinIdle(GenericObjectPoolConfig.DEFAULT_MIN_IDLE);
		poolConfig.setJmxEnabled(true);
		poolConfig.setJmxNamePrefix("jedis-pool");
		return poolConfig;
	}
	
	/**
	 * check the appid is check validate.同一个 app id 的对app id 检测的有效性是串行的，因此这里无须考虑多线程并发带来的状态不一致的情况。
	 * 对同一个app id 检测的状态只会等第一个到来的处理完之后，后面到来的请求只许判断第一次的状态即可。
	 * @return
	 */
	public static CheckStatus getAppCheckStatus(int appId,int checkType){
		
		ConcurrentHashMap<Integer,CheckStatus> checkStatusMap = checkStatusRegister.putIfAbsent(appId,new ConcurrentHashMap<Integer,CheckStatus>());
		if(checkStatusMap == null){
			checkStatusMap = checkStatusRegister.get(appId);
		}
		
		CheckStatus checkStatus = checkStatusMap.putIfAbsent(checkType, CheckStatus.sleepCheck);
		if(checkStatus == null){
			checkStatus = checkStatusMap.get(checkType);
		}
		
		return checkStatus;
	}
	
	/**
	 * 对某个 app id 设置他的检测状态
	 * @param appId
	 * @param checkType 1 表示对app id 进行检测，2 表示对app key 进行检测。具体可详见：RedisProxtSysProperty 这个类
	 * @param checkStatus
	 */
	public static void setAppCheckStatus(int appId,int checkType,CheckStatus checkStatus){
		if(appId<0 || appId > Integer.MAX_VALUE){
			return ;
		}
		
		ConcurrentHashMap<Integer,CheckStatus> appIdCheckStatusMap = checkStatusRegister.putIfAbsent(appId,new ConcurrentHashMap<Integer,CheckStatus>());
		if(appIdCheckStatusMap == null){
			appIdCheckStatusMap = checkStatusRegister.get(appId) ;
		}
		
		appIdCheckStatusMap.put(checkType,checkStatus);
	}
	
	public static Jedis getJedis(int appid){
		
		JedisPool jedisPool = jedisPoolRegister.get(appid);
		if(jedisPool!=null){
			return jedisPool.getResource();
		}
		
		JedisSentinelPool jedisSentinelPool = jedisSentinelRegister.get(appid);
		if(jedisSentinelPool!=null){
			return jedisSentinelPool.getResource();
		}
		Log.warn("app id="+appid+" get Jedis is null.");
		return null;
	}
	
	public static JedisCluster getJedisCluster(int appId){
		
		return jedisCluterRegister.get(appId);
	}
	
	/**
	 * 
	 * @param appid
	 * @param hostAndPort
	 * @param inboundChannel 代理客户端的那个连接channel
	 */
	public static Jedis getRedisServerJedis(int appid,final Channel inboundChannel) throws InitRedisServerBootstrapException{
		// Start the connection attempt.
		Log.debug("app id["+appid+"] get redis server jedis,the input channel is "+inboundChannel);
		String remoteAddress = getRemoterAddress(inboundChannel);
		ConcurrentHashMap<String, Jedis> oldOutboundJedisMap = redisClientJedisRegister.putIfAbsent(appid,new ConcurrentHashMap<String, Jedis>());
		if(oldOutboundJedisMap == null){
			oldOutboundJedisMap = redisClientJedisRegister.get(appid);
		}
		//这里对old jedis 没有加锁的原因是：客户端一个channel -> jedis 是一一对应的基于redis 的tpc 都是request/response 模型. 因此同一时刻，客户端只能用channel 做一件事。
		Jedis oldJedis = oldOutboundJedisMap.get(remoteAddress);
		HostAndPort master = getSentinelMaster(appid);//当前sentinel 监听到的最新的master 信息
		if(isInit(oldJedis,master)){
			Log.debug("app id["+appid+"] get redis server jedis,the input channel is "+inboundChannel+" is initialize.");
			return initJedis(appid, inboundChannel, oldJedis, master);
		}
		return oldJedis;
	}

	//这个只会在客户端验证通过之后调用一次
	private static Jedis initJedis(int appid, final Channel inboundChannel, Jedis oldJedis, HostAndPort master)
			throws InitRedisServerBootstrapException {
		Jedis newJedis = null ;
		//1.1、try连接
		int count = 3 ;
		try {
			for(;count>0;count--){
				newJedis = new Jedis(master.getHost(), master.getPort());
				newJedis.connect();
				boolean isReConnect = (newJedis.getClient().isBroken()||!newJedis.isConnected());
				if(isReConnect){
					TimeUnit.SECONDS.sleep(1);
				}else{
					break;
				}
			}
		} catch (Exception e) {
			Log.error("appid="+appid+" init redis exception", e);
			if(newJedis != null){
				newJedis.close();
			}
		}
		//1.2 check the result of connect
		if(count==0){
			String message = String.format("[ %s ]after three count connect is faill.", appid); 
			Log.warn(message);
			throw new InitRedisServerBootstrapException(message);
		}
		
		//2.store in memory
		ConcurrentHashMap<String, Jedis> outboundJedisMap = redisClientJedisRegister.putIfAbsent(appid,new ConcurrentHashMap<String, Jedis>());
		if(outboundJedisMap == null){
			outboundJedisMap = redisClientJedisRegister.get(appid);
		}
		outboundJedisMap.put(getRemoterAddress(inboundChannel), newJedis);//标识当前这根channel 所连接的 Jedis
		
		//3、check whether close the old jedis or not
		if(oldJedis!=null && !master.equals(oldJedis.getHostAndPort())&&oldJedis.isConnected()){//这种情况下master 进行切换了，需要将之前的连接进行关闭
			oldJedis.close();
		}
		return newJedis;
	}
	
	/**
	 * 当master 进行切换时，需要更新客户端的连接
	 * @param oldJedis
	 * @param currentMaster
	 * @return
	 */
	public static boolean isInit(Jedis oldJedis,HostAndPort currentMaster){
		//note:这里判断的顺序的需要注意：因为这里的代码将是热点区，顺序没注意可能会增加多次无意义的判断降低性能
		if(oldJedis == null){
			return true ;
		}
		//1、经常对数据的write/read ,会增加broken 的概率。因此这个发生的概率是最大的
		if(oldJedis.getClient().isBroken()){
			return true ;
		}
		//2、这个发生的概率是折中的
		if(!oldJedis.isConnected()){
			return true;
		}
		//3.1
		if(currentMaster == null){
			return true;
		}
		//3.2、 只要master 切换了，则一定要进行一次初始化，这种发生的可能性比较少
		if(!currentMaster.equals(oldJedis.getHostAndPort())){
			return true;
		}
		
		return  false ;
	}
	
	public static boolean closeJedis(Channel channel,int appId){
		Log.debug("close the jedis of app id="+appId+" and the channel of proxy client is="+channel);
		String remoteAddress = getRemoterAddress(channel);
		ConcurrentHashMap<String, Jedis> oldOutboundJedisMap = redisClientJedisRegister.putIfAbsent(appId,new ConcurrentHashMap<String, Jedis>());
		if(oldOutboundJedisMap == null){
			oldOutboundJedisMap = redisClientJedisRegister.get(appId);
		}
		Jedis jedis = oldOutboundJedisMap.get(remoteAddress);
		if(jedis!=null&&jedis.isConnected()){
			jedis.close();
		}
		return true ;
	}
	
	public static int getRemoterAddressTopic(Channel channel){
		String clientIp = getRemoterAddress(channel);
		char[] array = clientIp.toCharArray();
		int checkSum = 0 ;
		for(char ch:array){
			checkSum += ch;
		}
		return checkSum;
	}
	
	public static String getRemoterAddress(Channel channel){
		if(channel.remoteAddress() instanceof InetSocketAddress){
			InetSocketAddress insocket = (InetSocketAddress) channel.remoteAddress();
	        return insocket.toString() ;
		}
		return "" ;
	}
	
	public static class InitIdempotentConfirmer extends IdempotentConfirmer{
		private int appid;
		private String appKey;
		private AppInstanceInfo appInstanceInfo ;
		private Channel channel ;
		public InitIdempotentConfirmer(int retry,int appid,String appKey,Channel channel,AppInstanceInfo appInstanceInfo) {
			super(retry);
			this.appid = appid;
			this.channel = channel;
			this.appKey = appKey;
			this.appInstanceInfo = appInstanceInfo;
		}
		@Override
		public boolean execute() {
			int i= 0 ,size = 0 ;
			//1 initialize redistribution cluster jedis client
			size = appInstanceInfo.getSentinel().size();
			String masterName = appInstanceInfo.getMasterName();
			List<com.globalegrow.cs.shared.config.base.HostAndPort> hosts = appInstanceInfo.getSentinel();
			Set<String> sentinels = new HashSet<>(size);
			for(i=0;i<size;i++){
				sentinels.add(hosts.get(i).getHostAndPort());
			}
			Log.info("the result of initialize the redis client of app id ["+appid+"] is :"+(sentinels.isEmpty())+" ,the redis mode is [ SENTINEL ],and the sentinel instance size is:"+size);
			if(sentinels.isEmpty()){
				return false;
			}
			
			JedisSentinelPool jedisSentinelPool = new JedisSentinelPool(masterName,sentinels,getGenericObjectPoolConfig());                                                                                                                                                                                                                                                                                                                      
			boolean resultInit = true ;
			try {
				initJedis(appid,channel,null,jedisSentinelPool.getCurrentHostMaster());
				jedisSentinelRegister.put(appid, jedisSentinelPool);
			} catch (InitRedisServerBootstrapException e) {
				Log.error(jedisSentinelPool.getCurrentHostMaster().toString(),e);
				resultInit = false;
			}
			return resultInit;
		}
	}
	
	/**
	 * 如果有发 subscribe 命令，都会记录
	 * @param channelTopic
	 * @param channel
	 */
	public static void putSubscribeChannel(String channelTopic,Channel channel){
		Log.debug("put subscribe channel of topic="+channelTopic+" and channel is="+channel);
		subscribeChannelRegister.put(getRemoterAddress(channel), channel);
		
		subscribeTopicChannelRegister.putIfAbsent(channelTopic, new ConcurrentSkipListMap<String,Channel>());
		subscribeTopicChannelRegister.get(channelTopic).putIfAbsent(getRemoterAddress(channel), channel);
	}
	
	/**
	 * channel is inactive and unsubscribe call this method
	 * @param channel
	 */
	public static void removeSubscribeChannel(Channel channel){
		Log.debug("remove subscribe channel="+channel);
		String remoteAddress = getRemoterAddress(channel);
		subscribeChannelRegister.remove(remoteAddress);
		for(Entry<String, ConcurrentSkipListMap<String,Channel>> entry: subscribeTopicChannelRegister.entrySet()){
			entry.getValue().remove(remoteAddress);
		}
	}
	
	/**
	 * 向指定的 channel topic send some message.so will get all of the channel of that has subscribed the topic
	 * @param channelTopic
	 * @return
	 */
	public static Collection<Channel> getSubscribeChannel(String channelTopic){
		
		Map<String,Channel> channels = subscribeTopicChannelRegister.get(channelTopic);
		if(channels == null || channels.isEmpty()){
			return null;
		}
		return channels.values();
	}
	public static HostAndPort getSentinelMaster(int appid){
		
		JedisSentinelPool jedisSentinelPool = jedisSentinelRegister.get(appid);//.getCurrentHostMaster();
		if(jedisSentinelPool == null){
			return null;
		}
		
		return jedisSentinelPool.getCurrentHostMaster();
	}
}
