package com.globalegrow.cs.proxy.core.client.handler.conn;

import java.util.List;
import java.util.Locale;
import com.globalegrow.cs.proxy.core.client.CheckStatus;
import com.globalegrow.cs.proxy.core.client.ClientConnectType;
import com.globalegrow.cs.proxy.core.client.ClientTemplateFacade;
import com.globalegrow.cs.proxy.core.client.RedisClientFacade;
import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.anotation.RedisCmd;
import com.globalegrow.cs.proxy.core.client.handler.AbstractBaseSupportRedisCmdHandler;
import com.globalegrow.cs.proxy.core.client.server.RedisMessageHanndler;
import com.globalegrow.cs.shared.config.app.AppConfigQuery;
import com.globalegrow.cs.shared.config.base.AppInstanceInfo;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.channel.Channel;

/**
 * if the app id has pass to check,then check the app key directly
 * @author pengbingting
 *
 */
@RedisCmd(cmd=RedisProtocol.AUTH,desc="app key check")
public class AuthCmdHandler extends AbstractBaseSupportRedisCmdHandler{

	/**
	 * key 的形式是 appkey:connect type.
	 * for example:f368df13704721db417916e0740a8915:cluster
	 */
	@Override
	public byte[] execute(Channel channel, final int appId, String key, List<byte[]> args) throws Exception {
		String[] keyConnectType = key.split(":");
		key = keyConnectType[0];
		String connectType = keyConnectType[1].toLowerCase(Locale.ENGLISH);
		//如果已经检测通过了，则直接进行返回，
		CheckStatus checkStatus = RedisClientFacade.getAppCheckStatus(appId,Constant.APP_SECRET_KEY);
		if(CheckStatus.isCheckPass(checkStatus)){
			channel.attr(RedisMessageHanndler.appIdAttryKey).set(appId);
			channel.attr(RedisMessageHanndler.channelConnectType).set(connectType);
			//如果是集群的连接方式，需要记录客户端拿到代理拓扑结果的一个epoll 值。当代理拓扑结构发现变化时，通过这个epoll 的值来和客户端进行对比，必要时向客户端返回master 发现的命令
			if(ClientConnectType.isCluster(connectType)){
				channel.attr(RedisMessageHanndler.clusterTemEpoolKey).set(ClientTemplateFacade.clusterSlotesEpoll.get());
				RedisClientFacade.redisClientClusterChannelRegister.put(RedisClientFacade.getRemoterAddress(channel), channel);
			}
			return ResponseMessage.OK.getBytes();
		}
		
		RedisClientFacade.setAppCheckStatus(appId,Constant.APP_SECRET_KEY,CheckStatus.checking);
		AppInstanceInfo result = null;
		String response = null;
		try {
			result = AppConfigQuery.belongCurrentProxyGroup(String.valueOf(appId), key);
			if(result.isOffline()){
				RedisClientFacade.setAppCheckStatus(appId, Constant.APP_SECRET_KEY,CheckStatus.checkInvalidate);
				response = String.format(ResponseMessage.ERROR_APPKEY, key);
			}else{
				/**
				 * 验证成功之后：需要做以下几件事：
				 * 1、初始化好客户端访问redis 的Jedis 客户端
				 * 2、设置对 app id 验证的最后结果 
				 */
				boolean initResult = RedisClientFacade.init(appId,key,result,channel);
				if(!initResult){
					response = String.format(ResponseMessage.ERROR_INIT_JEDIS_CLIENT, appId);
					RedisClientFacade.setAppCheckStatus(appId,Constant.APP_SECRET_KEY, CheckStatus.checkInvalidate);
				}else{
					response = ResponseMessage.OK;
					RedisClientFacade.setAppCheckStatus(appId,Constant.APP_SECRET_KEY, CheckStatus.checkpass);
					channel.attr(RedisMessageHanndler.appIdAttryKey).set(appId);
					//the default connect type is stand alone
					channel.attr(RedisMessageHanndler.channelConnectType).set(connectType);
					if(ClientConnectType.isCluster(connectType)){
						channel.attr(RedisMessageHanndler.clusterTemEpoolKey).set(ClientTemplateFacade.clusterSlotesEpoll.get());
						RedisClientFacade.redisClientClusterChannelRegister.put(RedisClientFacade.getRemoterAddress(channel), channel);
					}
				}
			}
		} catch (Exception e) {
			Log.error("appid["+appId+"] appKey["+key+"] auth cause an exception", e);
			response = String.format(ResponseMessage.ERROR_REPLY, "An error occurred on the internal server!");
		}
		
		return response.getBytes();
	}

}
