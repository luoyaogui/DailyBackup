package com.globalegrow.cs.proxy.core.client.server;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

/**
 * 这里将消息类型定义为byte[],目的就是要将redis server 返回的数据直接转发给客户端。无需进一步的编码工作。
 * 因为客户端已经实现了redis protocol 的编码工作。所以这里只许进行转发即可。
 * @author pengbingting
 *
 */
public class RedisMessageEncoder extends MessageToByteEncoder<byte[]> {

	@Override
	protected void encode(ChannelHandlerContext arg0, byte[] response, ByteBuf byteBuffer) throws Exception {
		byteBuffer.writeBytes(response);
	}

}
