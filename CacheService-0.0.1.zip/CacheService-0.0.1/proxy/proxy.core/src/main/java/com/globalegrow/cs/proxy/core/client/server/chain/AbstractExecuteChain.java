package com.globalegrow.cs.proxy.core.client.server.chain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.globalegrow.cs.proxy.core.client.event.RedisProxyClientInspector;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;

import io.netty.channel.Channel;

public abstract class AbstractExecuteChain implements IExecuteChain{
	protected Logger logger = LoggerFactory.getLogger(AbstractExecuteChain.class);
	private Integer order ;
	protected final static RedisProxyClientInspector redisProxyClientCheck = new RedisProxyClientInspector();
	
	public AbstractExecuteChain(Integer order) {
		super();
		this.order = order;
	}

	@Override
	public abstract boolean executeChain(RedisMessage redisMessage, Channel channel);

	@Override
	public int getOrder() {
		return order.intValue();
	}

	public static void main(String[] args) {
		List<Integer> values = new ArrayList<>();
		values.add(1);
		values.add(4);
		values.add(10);
		values.add(3);
		Collections.sort(values, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}
		});
		System.out.println(values);
	}
}
