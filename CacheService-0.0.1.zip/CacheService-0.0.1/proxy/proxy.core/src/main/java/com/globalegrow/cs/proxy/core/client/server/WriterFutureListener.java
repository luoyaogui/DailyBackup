package com.globalegrow.cs.proxy.core.client.server;

import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;

public class WriterFutureListener implements GenericFutureListener<Future<Object>> {
	
	private String opts ;
	private String response ;
	public WriterFutureListener(String opts,String response) {
		super();
		this.opts = opts;
		this.response = response;
	}

	@Override
	public void operationComplete(Future<Object> future) throws Exception {
		if(!future.isSuccess()){
			Log.warn(opts+"; is un success to reply:"+response);
		}
	}

}
