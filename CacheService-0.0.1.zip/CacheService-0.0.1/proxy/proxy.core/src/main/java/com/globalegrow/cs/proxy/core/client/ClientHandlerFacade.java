package com.globalegrow.cs.proxy.core.client;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.globalegrow.cs.proxy.core.client.anotation.RedisCmd;
import com.globalegrow.cs.proxy.core.client.handler.IRedisCmdHandler;
import com.globalegrow.cs.proxy.core.client.handler.ProxyCmdHandlerPackage;
import com.globalegrow.cs.proxy.core.lifecycle.AbstractLifeCycle;
import com.globalegrow.cs.shared.common.utils.ClassUtil;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import com.globalegrow.cs.shared.event.common.Facade;
import com.globalegrow.cs.shared.event.graph.RunnableNodeCmd;
import com.globalegrow.cs.shared.event.task.queue.Action;
import com.globalegrow.cs.shared.event.task.queue.Log;
import com.globalegrow.cs.shared.event.task.queue.TaskEventAsyncQueue;

public class ClientHandlerFacade extends AbstractLifeCycle implements Facade{
	
	/**
	 * store redistribution command handler register
	 */
	private final static HashMap<String, IRedisCmdHandler> redisCmdHandlerRegister = new HashMap<String, IRedisCmdHandler>();
	
	/**
	 * will the same key of client will execute in queue
	 */
	private final static ConcurrentHashMap<Integer,TaskEventAsyncQueue<Action>> proxyClientKeyOpQueue = new ConcurrentHashMap<Integer,TaskEventAsyncQueue<Action>>();
	
	public static boolean isDirectlyConnection = false ;
	
	//直连情况下代理需要处理的命令
	public static List<String> HANDLER_REDIS_CMD = 
			Arrays.asList(
					RedisProtocol.SENTINEL,
					RedisProtocol.CLUSTER,
					RedisProtocol.AUTH,
					RedisProtocol.BRPOP,
					RedisProtocol.BLPOP,
					RedisProtocol.BRPOPLPUSH);
	
	//优化快速定位 directly redistribution command handler 
	private final static HashMap<String, Boolean> directlyFlagRegister = new HashMap<String, Boolean>(); 
	
	public static  List<String> TRANSACTION_CMDSET = 
			Arrays.asList(RedisProtocol.DISCARD,RedisProtocol.EXEC,RedisProtocol.MULTI,RedisProtocol.UNWATCH,RedisProtocol.WATCH);
	
	@Override
	public void start() {
		super.start();
		init();
	}

	@Override
	public void stop() {
		super.stop();
	}
	/**
	 * 初始化所有的netty 消息处理器
	 * @param nettyCmdPackages netty 消息处理器所在的包
	 * @return 
	 */
	public boolean init(){
		boolean result = true ;
		int count = 0 ;
		Set<Class<?>> redisCmdHandlerClassSet = ClassUtil.getClasses(ProxyCmdHandlerPackage.class.getPackage());
		for(Class<?> redisCmdHandler : redisCmdHandlerClassSet){
			try {
				@SuppressWarnings("unchecked")
				Class<? extends IRedisCmdHandler> tmpRedisCmdHandler = (Class<? extends IRedisCmdHandler>) redisCmdHandler;
				if(tmpRedisCmdHandler.isInterface()){
					continue;
				}
				RedisCmd rediscmd = tmpRedisCmdHandler.getAnnotation(RedisCmd.class);
				if(rediscmd==null){
					continue;
				}
				String cmd = rediscmd.cmd();
				String desc = rediscmd.desc();
				if(redisCmdHandlerRegister.containsKey(cmd)){
					throw new RuntimeException(cmd+" has resprent a nettt command:"+cmd+":"+desc);
				}
				redisCmdHandlerRegister.put(cmd, tmpRedisCmdHandler.newInstance());
			} catch (InstantiationException e) {
				Log.error("initialize redis cmd handler",e);
				result = false ;
			} catch (IllegalAccessException e) {
				Log.error("initialize redis cmd handler",e);
				result = false ;
			}
		}
		Log.debug("the total of cmd handler is:"+count);
		initDirectlyFlag();
		return result ;
	}
	
	private static void initDirectlyFlag(){
		Log.debug("directly handler commands="+HANDLER_REDIS_CMD.toString());
		for(String cmd : HANDLER_REDIS_CMD){
			directlyFlagRegister.put(cmd, Boolean.valueOf(true));
		}
	}
	
	public static boolean isDirectlyRedisCmd(String redisCmd){
		Boolean flag = directlyFlagRegister.get(redisCmd);
		return flag == null ? false:flag;
	}
	
	public static int getCheckSum(String source){
		char[] src = source.toCharArray();
		int checkSum = 0 ;
		for(char ch:src){
			checkSum += ch ;
		}
		return checkSum;
	}
	
	public static void initNettyCmd(List<String> classNameList){
		if(classNameList == null || classNameList.isEmpty()){
			return ;
		}
		for(String clazz:classNameList){
			try {
				@SuppressWarnings("unchecked")
				Class<? extends IRedisCmdHandler> redisCmdHandler = (Class<? extends IRedisCmdHandler>) Class.forName(clazz);
				if(redisCmdHandler.isInterface()){
					continue;
				}
				RedisCmd rediscmd = redisCmdHandler.getAnnotation(RedisCmd.class);
				if(rediscmd==null){
					continue;
				}
			 	String cmd = rediscmd.cmd();
			 	String desc = rediscmd.desc();
			 	if(redisCmdHandlerRegister.containsKey(cmd)){
			 		throw new RuntimeException(cmd+" has resprent a nettt command:"+cmd+":"+desc);
			 	}
			 	redisCmdHandlerRegister.put(cmd, redisCmdHandler.newInstance());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static TaskEventAsyncQueue<Action> getKeyTaskQueue(int appid){
		
		TaskEventAsyncQueue<Action> tmpTaskQueue = proxyClientKeyOpQueue.putIfAbsent(appid, new TaskEventAsyncQueue<Action>("appkey-dispatcker-executor"));
		if(tmpTaskQueue == null){
			TaskEventAsyncQueue<Action> taskEventAsyncQueue = new TaskEventAsyncQueue<Action>("appkey-dispatcker-executor");
			proxyClientKeyOpQueue.put(appid, taskEventAsyncQueue);
			return taskEventAsyncQueue;
		}else{
			return tmpTaskQueue;
		}
	}
	
	public static IRedisCmdHandler getRedisCmdHandler(String redisCmd){
		
		return redisCmdHandlerRegister.get(redisCmd);
	}
	
	public static class InitNettyCmdNode implements RunnableNodeCmd{
		List<String> classNameList ;
		
		public InitNettyCmdNode(List<String> classNameList) {
			super();
			this.classNameList = classNameList;
		}

		public void handler() {
			initNettyCmd(classNameList);
		}
	}
}
