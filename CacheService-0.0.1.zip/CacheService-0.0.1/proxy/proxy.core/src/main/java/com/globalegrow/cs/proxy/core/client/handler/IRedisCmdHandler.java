package com.globalegrow.cs.proxy.core.client.handler;

import com.globalegrow.cs.proxy.core.client.server.RedisMessage;

import io.netty.channel.Channel;

public interface IRedisCmdHandler {

	public void execute(Channel channel,RedisMessage redisMessage);
}
