package com.globalegrow.cs.proxy.core.client.handler.block;

import java.util.List;
import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.proxy.core.client.anotation.RedisCmd;
import com.globalegrow.cs.proxy.core.client.event.MultiBulkAsyncEventLoopGroup;
import com.globalegrow.cs.proxy.core.client.handler.AbstractBlockingRedisCmdHandler;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import io.netty.channel.Channel;

@RedisCmd(cmd=RedisProtocol.BLPOP,desc="")
public class BlpopCmdHandler extends AbstractBlockingRedisCmdHandler {
	@Override
	public byte[] execute(Channel channel, int appid, String key, List<byte[]> args) throws Exception {
		ChannelRedisMessage channelRedisMessage = new ChannelRedisMessage(channel, new RedisMessage(appid, RedisProtocol.BLPOP, key, args));
		multiBulkAsyncEventLoop.publish(channelRedisMessage, MultiBulkAsyncEventLoopGroup.BLPOP_EVENT);
		return null;
	}
}
