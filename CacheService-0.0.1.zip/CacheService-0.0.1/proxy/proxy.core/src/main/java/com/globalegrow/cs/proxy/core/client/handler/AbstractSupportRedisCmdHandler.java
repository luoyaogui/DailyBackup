package com.globalegrow.cs.proxy.core.client.handler;

import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.proxy.core.client.server.WriterFutureListener;
import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;

public abstract class AbstractSupportRedisCmdHandler extends AbstractRedisCmdHandler {

	@Override
	public abstract void execute(Channel channel, RedisMessage redisMessage);
	
	public void handlerResponse(Channel channel,boolean isSuccess,byte[] response,RedisMessage redisMessage){
		int appid =redisMessage.getAppId();
		if(isSuccess){
			try {
				/**
				 * in here will handler the response message from
				 * redistribution server.must know which message can send to
				 * client or not.
				 */
				if (process(response)) {
					ChannelFuture channelFuture = channel.writeAndFlush(response);
					channelFuture.addListener(new WriterFutureListener(this.getClass().getName()+".execute,[appid="+appid+"] cmd="+redisMessage.getCmd()+"; key="+redisMessage.getKey(), new String(response)));
				}
			} catch (Exception e) {
				String exceptionResponse = String.format(ResponseMessage.ERROR_REPLY, e.getMessage());
				ChannelFuture channelFuture = channel.writeAndFlush(exceptionResponse.getBytes());
				channelFuture.addListener(new WriterFutureListener(this.getClass().getName()+".execute,[appid="+appid+"] cmd="+redisMessage.getCmd()+"; key="+redisMessage.getKey(),exceptionResponse));
				System.out.println("cmd:" + redisMessage.getCmd() + "; key:" + redisMessage.getKey());
				e.printStackTrace();
				Log.error("app id=" + appid + "; cmd =" + redisMessage.getCmd() + " is error", e);
			}
		}else{
			String busyNowResponse = String.format(ResponseMessage.REDIS_BUSY_NOW, redisMessage.getCmd());
			ChannelFuture channelFuture = channel.writeAndFlush(busyNowResponse.getBytes());
			channelFuture.addListener(new WriterFutureListener(this.getClass().getName()+".execute,[appid="+appid+"] cmd="+redisMessage.getCmd()+"; key="+redisMessage.getKey(),busyNowResponse));
		}
	}

}
