package com.globalegrow.cs.proxy.core.arbitrate;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.NodeCache;
import org.apache.curator.framework.recipes.cache.NodeCacheListener;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.framework.recipes.cache.TreeCache;
import org.apache.curator.framework.recipes.cache.TreeCacheEvent;
import org.apache.curator.framework.recipes.cache.TreeCacheListener;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.curator.framework.state.ConnectionStateListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.globalegrow.cs.proxy.core.client.RedisProxyClusterFacade;
import com.globalegrow.cs.proxy.core.monitor.GlobalManager;
import com.globalegrow.cs.shared.common.utils.ByteUtils;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.config.base.HostAndPort;
import com.globalegrow.cs.shared.config.zk.ZKStatusModify;
import com.globalegrow.cs.shared.config.zk.client.ZKClientUtils;
import com.globalegrow.cs.shared.config.zk.path.ZKPathFormatUtils;
import com.globalegrow.cs.shared.config.zk.path.ZKPathOperator;
import com.globalegrow.cs.shared.config.zk.store.ZKNodeTree;

/**
 * Title: ZKArbitrateService
 * Description: zk仲裁服务类，主要实现zk的监听、数据存储调用、代理注册
 * Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
 * @author yaoguiluo
 * @date 2017年5月16日 下午6:05:29
 */
public final class ZKArbitrateService {
	private static final Logger logger = LoggerFactory.getLogger(ZKArbitrateService.class);
	private int failNumber = 0;
	private ExecutorService pool = Executors.newFixedThreadPool(3);//事件处理线程池
	private String currentProxyPath;
	private HostAndPort local;
	private CuratorFramework client;//zk客户端，自动重连
	private NodeCache groupStatus;
	private TreeCache appRootTree;
	private PathChildrenCache groupNodes;
	private AtomicInteger launcher = new AtomicInteger(3);
	private volatile boolean isFirstStart = true;

	/**
	 * 启动zk仲裁服务
	 * @throws Exception  启动异常
	 */
	public void start() throws Exception{
		//生产当前代理节点对应的zk路径
		currentProxyPath = ZKPathFormatUtils.getProxyGroupNode(GlobalManager.getInstance().getParamConfig().getBelongProxyGroup(), GlobalManager.getInstance().getProxyUuid());
		//生成本机地址信息
		if(GlobalManager.getInstance().getParamConfig().isCloseOuterIP())
			local = new HostAndPort(GlobalManager.getInstance().getParamConfig().getIp(),GlobalManager.getInstance().getParamConfig().getPort());
		else
			local = new HostAndPort(GlobalManager.getInstance().getParamConfig().getOuterIp(),GlobalManager.getInstance().getParamConfig().getPort());
		client = ZKClientUtils.getInstance(GlobalManager.getInstance().getParamConfig().getZkAddresses());
		initConnectListener();//连接成功
		//initProxyGroupStatusListener();//初始化组状态监听器，暂不使用
		initAppRootTreeListener();//初始化app树监听器成功
		initProxyGroupNodesListener();//初始化代理组节点列表监听器
		while(launcher.get() > 0){
			TimeUnit.SECONDS.sleep(3);
		}
		isFirstStart = false;
		logger.info("zk  ZKArbitrateService    lauch   success !");
	}

	/**
	 * 关闭zk仲裁器
	 */
	@SuppressWarnings("deprecation")
	public void stop(){
		if(client.isStarted())
			client.close();
		client = null;
		groupStatus  = null;
		appRootTree = null;
		groupNodes = null;
		pool.shutdownNow();
		ZKNodeTree.getInstance().reset();
		failNumber = 0;
	}
	private void notifyFacade(String path, boolean isAdd){
		if(isAdd) {
			try {
				byte[] data = ZKPathOperator.getData(client, path, null);
				ZKNodeTree.getInstance().createNode(path, data);
				HostAndPort info = ByteUtils.jsonByte2CustomType(data,HostAndPort.class);//数据反序列化
				if(null == info)
					logger.error(path + " notifyFacade   data is null when excute add operator!");
				RedisProxyClusterFacade.addProxyServer(info);
			} catch (Exception e) {
				logger.error(path + " notifyFacade add node exception:\n{}", ExceptionUtils.getFullStackTrace(e));
				return ;
			}
		} else {
			try {
				HostAndPort info = ZKNodeTree.getInstance().getData(path, HostAndPort.class);
				RedisProxyClusterFacade.removeProxyServer(info);
			} catch (Exception e) {
				logger.error(path + " notifyFacade remove  node exception:\n{}", ExceptionUtils.getFullStackTrace(e));
			}
		}
	}
	/**
	 * 添加当前代理组状态监听
	 */
	private void initProxyGroupStatusListener() throws Exception {
		groupStatus = new NodeCache(client, ZKPathFormatUtils.getProxyGroupStatus(GlobalManager.getInstance().getParamConfig().getBelongProxyGroup()), false);
		groupStatus.start();
		groupStatus.getListenable().addListener(new NodeCacheListener() {
			@Override
			public void nodeChanged() throws Exception {
				try {
					if(ByteUtils.jsonByte2CustomType(groupStatus.getCurrentData().getData(), Boolean.class))
						ZKNodeTree.getInstance().turnOn();//组上线
					else
						ZKNodeTree.getInstance().turnOff();//组下线
				} catch (Throwable e) {
					logger.error(" zk initProxyGroupStatusListener exception : \n{}", 
							ExceptionUtils.getFullStackTrace(e));
				}
			}
		}, pool);
	}
	/**
	 * 添加当前代理组的子节点监听
	 */
	private void initProxyGroupNodesListener() throws Exception{
		groupNodes = new PathChildrenCache(client, ZKPathFormatUtils.getProxyGroupNodeRoot(GlobalManager.getInstance().getParamConfig().getBelongProxyGroup()), false);
		groupNodes.start();
		groupNodes.getListenable().addListener(new PathChildrenCacheListener(){
			@Override
			public void childEvent(CuratorFramework client, PathChildrenCacheEvent event) {
				try {
					switch(event.getType()){
					case CHILD_ADDED:
						if(!currentProxyPath.equals(event.getData().getPath())){
							notifyFacade(event.getData().getPath(),true);
						}
						break;
					case CHILD_REMOVED:
						if(!currentProxyPath.equals(event.getData().getPath())){
							notifyFacade(event.getData().getPath(),false);
						}
						break;
					case CONNECTION_RECONNECTED:
						launchCheck("addProxyGroupNodesListener");
						break;
					default:
						break;
					}
				} catch (Throwable e) {
					logger.error(" zk addProxyGroupListener exception : " + event + "\n{}", 
							ExceptionUtils.getFullStackTrace(e));
				}
			}
		},pool);
	}
	/**
	 * 代理服务自己检查，临时节点（保证zk上的状态是实时的）所以每次连接上zk后需要重新注册
	 */
	private void checkProxyNode(){
		pool.submit(new Runnable(){
			public void run() {
				try {
					if(!ZKStatusModify.proxyNodeOnline(client,
							GlobalManager.getInstance().getParamConfig().getBelongProxyGroup(), 
							GlobalManager.getInstance().getProxyUuid(), 
							new HostAndPort(GlobalManager.getInstance().getParamConfig().getIp(), GlobalManager.getInstance().getParamConfig().getPort()))){
						if(++failNumber < Constant.TRY_NUM_AFTER_ZK_CONNECT_FAILED){
							checkProxyNode();//默认重试多次
						} else {
							failNumber = 0;//归零
							logger.error("proxy node  register failed!    failNumber:"+failNumber);
						}
					} else {
						RedisProxyClusterFacade.addProxyServer(local);//把本机地址加入
						launchCheck("checkProxyNode");
					}
				} catch (Throwable e) {
					logger.error(" zk checkProxyNode exception : \n{}", 
							ExceptionUtils.getFullStackTrace(e));
				}
			}
		});
	}
	//启动检查
	private void launchCheck(String methodName){
		if(isFirstStart){//是
			launcher.decrementAndGet();
			logger.info("zk  " + methodName + "    lauch   success !");
		}
	}

	/**
	 * 添加连接监听器，以实现注册代理服务的临时节点
	 */
	private void initConnectListener() {
		client.getConnectionStateListenable().addListener(new ConnectionStateListener() {
			public void stateChanged(CuratorFramework client, ConnectionState newState) {
				switch(newState){
				case CONNECTED:
				case RECONNECTED:
					launchCheck("initConnectListener");
					checkProxyNode();
					break;
				case SUSPENDED:
					RedisProxyClusterFacade.removeProxyServer(local);//把本机地址移除
					break;
				default:
					break;
				}
			}
		});
	}
	/**
	 * 初始化app-root为根的树监听器，监听根节点下所有节点的变更
	 * 			变更时，存储信息到本地zk树中，并调用相关的监听器
	 * @throws Exception  初始化异常
	 */
	private void initAppRootTreeListener() throws Exception {
		appRootTree = new TreeCache(client, ZKPathFormatUtils.getProxyGroupAppRoot(GlobalManager.getInstance().getParamConfig().getBelongProxyGroup()));//监听app-root节点
		appRootTree.start();
		appRootTree.getListenable().addListener(new TreeCacheListener() {//监听器处理
			public void childEvent(CuratorFramework paramCuratorFramework, TreeCacheEvent event) {
				try {
					switch(event.getType()){
					case NODE_ADDED://节点增加
						ZKNodeTree.getInstance().createNode(event.getData().getPath(), event.getData().getData());//存储到本地zk树中
						break;
					case NODE_REMOVED://节点删除
						ZKNodeTree.getInstance().deleteNode(event.getData().getPath());//存储到本地zk树中
						break;
					case NODE_UPDATED://节点数据变更
						ZKNodeTree.getInstance().setData(event.getData().getPath(), event.getData().getData());//存储到本地zk树中
						break;
					case INITIALIZED://初始化完成
						launchCheck("initAppRootTreeListener");
						break;
					default:
						break;
					}
				} catch (Throwable e) {
					logger.error(" zk initZKTreeListener exception : " + event + "\n{}", 
							ExceptionUtils.getFullStackTrace(e));
				}
			}
		},pool);
	}
}
