package com.globalegrow.cs.proxy.core.client.server;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 对于redis server 来说。所有接受的请求都以参数进行来处理。
 * 第一个参数便是需要处理的command.
 * 第二个参数是 命令后跟的key
 * 第三个参数+ 跟的是该命令所能接受的参数
 * 参考:redis 的设计与实现。
 * @author pengbingting
 *
 */
public class RedisMessage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//初始化解析时跟的第二个参数.主要就是记录auth 命令时会跟上一些额外的参数，比如 appId:key:type 这个时候在auth 命令处理前可能需要解析这个基本参数
	private String appIdCmdStr;
	private int appId;
	private String cmd;//第一个参数：需要处理的redistribution command 或者 自定义扩展的command
	private String key;//第二个参数:
	private List<byte[]> args ;//第三个参数开始:vaue 啥的 传递给redis server 的参数都会放在这里。从第三个参数开始
	private ByteArrayOutputStream originalMessage;//received from client send original
	public RedisMessage(int appId, String cmd, String key, List<byte[]> args) {
		super();
		this.appId = appId;
		this.cmd = cmd;
		this.key = key;
		this.args = args;
	}

	public RedisMessage() {
		args = new ArrayList<byte[]>();
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public String getCmd() {
		return cmd;
	}
	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
	public List<byte[]> getArgs() {
		return Collections.unmodifiableList(args);
	}
	
	public void addArg(byte[] arg) {
		args.add(arg);
	}

	public String getAppIdCmdStr() {
		return appIdCmdStr;
	}

	public void setAppIdCmdStr(String appIdCmdStr) {
		this.appIdCmdStr = appIdCmdStr;
	}

	public ByteArrayOutputStream getOriginalMessage() {
		return originalMessage;
	}

	public void setOriginalMessage(ByteArrayOutputStream originalMessage) {
		this.originalMessage = originalMessage;
	}
	
}
