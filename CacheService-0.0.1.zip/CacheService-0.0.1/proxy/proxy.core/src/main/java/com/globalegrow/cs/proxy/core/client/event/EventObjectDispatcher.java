package com.globalegrow.cs.proxy.core.client.event;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import com.globalegrow.cs.shared.event.task.queue.Executor;

public final class EventObjectDispatcher {

	public final static ConcurrentHashMap<Integer, RedisProxyClientInspector> redisProxtClientCheckRegister = new ConcurrentHashMap<Integer, RedisProxyClientInspector>();
	
	private final static int THREAD_CORE_SIZE =Runtime.getRuntime().availableProcessors()*4;
	private final static int THREAD_MAX_SIZE = 2 * THREAD_CORE_SIZE;
	private final static int THREAD_IDEL_TIME = 60;
	public final static Executor BLOCK_EXECUTOR = new Executor(THREAD_CORE_SIZE, THREAD_MAX_SIZE, THREAD_IDEL_TIME, TimeUnit.SECONDS, "block-executor");
}
