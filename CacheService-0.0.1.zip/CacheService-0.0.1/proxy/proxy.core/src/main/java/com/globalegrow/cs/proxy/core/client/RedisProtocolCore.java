package com.globalegrow.cs.proxy.core.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import com.globalegrow.cs.shared.event.task.queue.Log;
import redis.clients.jedis.Protocol;
import redis.clients.util.SafeEncoder;

public class RedisProtocolCore extends RedisProtocol{
	public static Logger logger = LoggerFactory.getLogger(RedisProtocolCore.class);
	public static enum Keyword {
		AGGREGATE, ALPHA, ASC, BY, DESC, GET, LIMIT, MESSAGE, NO, NOSORT, PMESSAGE, PSUBSCRIBE, PUNSUBSCRIBE, OK, ONE, QUEUED, SET, STORE, SUBSCRIBE, UNSUBSCRIBE, WEIGHTS, WITHSCORES, RESETSTAT, RESET, FLUSH, EXISTS, LOAD, KILL, LEN, REFCOUNT, ENCODING, IDLETIME, AND, OR, XOR, NOT, GETNAME, SETNAME, LIST, MATCH, COUNT, PING, PONG, UNLOAD;
		public final byte[] raw;

		Keyword() {
			raw = SafeEncoder.encode(this.name().toLowerCase(Locale.ENGLISH));
		}
	}
	
	private final static byte[] DigitTens = { '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1',
			'1', '1', '1', '1', '1', '1', '1', '1', '1', '2', '2', '2', '2', '2', '2', '2', '2', '2',
			'2', '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', '4', '4', '4', '4', '4', '4', '4',
			'4', '4', '4', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '6', '6', '6', '6', '6',
			'6', '6', '6', '6', '6', '7', '7', '7', '7', '7', '7', '7', '7', '7', '7', '8', '8', '8',
			'8', '8', '8', '8', '8', '8', '8', '9', '9', '9', '9', '9', '9', '9', '9', '9', '9', };
	
	private final static byte[] DigitOnes = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
			'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8',
			'9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6',
			'7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4',
			'5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2',
			'3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', };
	
	private final static byte[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a',
			'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
			't', 'u', 'v', 'w', 'x', 'y', 'z' };
	
	private final static int[] sizeTable = { 9, 99, 999, 9999, 99999, 999999, 9999999, 99999999,
	          999999999, Integer.MAX_VALUE };
	
	
	public static byte[] writeBulkResponse(String message){
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] response = new byte[calculateByteSize(message)];
			int index = 0 ;
			//2.1、set the one of the message length  start if $
			response[index++] = Protocol.DOLLAR_BYTE;
			byte[] val = message.getBytes();
			index = writeIntCrLf(val.length, response, index);
			//2.2、set the real message body
			for(int i=0;i<val.length;i++){
				response[index++] = val[i];
			}
			//3、end of one message
			response[index++] = '\r';
			response[index++] = '\n';
			baos.write(response, 0, index);
			return baos.toByteArray();
		} catch (IOException e) {
			Log.error("write bulk response is exception", e);
			return String.format(ResponseMessage.ERROR_REPLY, e.getMessage()).getBytes();
		}
	}
	
	/**
	 * 
	 * @param messages
	 * @return
	 */
	public static byte[] writeMultiBulkResponse(String... messages){
		try {
			byte[] response = new byte[calculateByteSize(messages)];
			int index = 0 ;
			int length = messages.length;
			//1、set the length of array
			response[index++] = Protocol.ASTERISK_BYTE;
			index = writeIntCrLf(length, response, index);//end of the \r\n
			//2、start set the body of message
			for(String message:messages){
				//2.1、set the one of the message length  start if $
				response[index++] = Protocol.DOLLAR_BYTE;
				byte[] val = message.getBytes();
				index = writeIntCrLf(val.length, response, index);
				//2.2、set the real message body
				for(int i=0;i<val.length;i++){
					response[index++] = val[i];
				}
				//3、end of one message
				response[index++] = '\r';
				response[index++] = '\n';
			}
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			baos.write(response, 0,index);
			return baos.toByteArray();
		} catch (IOException e) {
			Log.error("write multiple bulk response is exception", e);
			return String.format(ResponseMessage.ERROR_REPLY, e.getMessage()).getBytes();
		}
	}
	
	private static int calculateByteSize(String... messages){
		int size = 0 ;
		for(String m:messages){
			size+=m.getBytes().length;
		}
		//size = length of message body + length of message + exten length of  
		return size+messages.length+100;
	}
	
	public static int writeIntCrLf(int value, byte[] byteVal, int count) throws IOException {
		if (value < 0) {
			byteVal[count++] = '-';
			value = -value;
		}

		int size = 0;
		while (value > sizeTable[size])
			size++;

		size++;
		int q, r;
		int charPos = count + size;
		while (value >= 65536) {
			q = value / 100;
			r = value - ((q << 6) + (q << 5) + (q << 2));
			value = q;
			byteVal[--charPos] = DigitOnes[r];
			byteVal[--charPos] = DigitTens[r];
		}

		for (;;) {
			q = (value * 52429) >>> (16 + 3);
			r = value - ((q << 3) + (q << 1));
			byteVal[--charPos] = digits[r];
			value = q;
			if (value == 0)
				break;
		}
		count += size;

		byteVal[count++] = '\r';
		byteVal[count++] = '\n';

		return count;
	}
}
