package com.globalegrow.cs.proxy.core.lifecycle;

import com.globalegrow.cs.proxy.core.monitor.GlobalManager;
import com.globalegrow.cs.shared.common.utils.lifecycle.LifeCycle;
import com.globalegrow.cs.shared.common.utils.lifecycle.LifecycleException;

/**
 * 基本实现
 */
public abstract class AbstractLifeCycle implements LifeCycle {

    protected volatile boolean running = false; // 是否处于运行中

    public boolean isStart() {
        return running;
    }

    public void start() {
    		GlobalManager.getInstance().addService(this);//添加监控
        if (running) {
            throw new LifecycleException(this.getClass().getName() + " has startup , don't repeat start");
        }
        
        running = true;
    }

    public void stop() {
        if (!running) {
            throw new LifecycleException(this.getClass().getName() + " isn't start , please check");
        }

        running = false;
    }

}
