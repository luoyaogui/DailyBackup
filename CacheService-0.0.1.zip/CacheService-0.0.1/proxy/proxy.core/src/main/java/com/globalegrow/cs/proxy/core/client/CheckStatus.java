package com.globalegrow.cs.proxy.core.client;

/**
 * 检验状态。这里规定所有的检测状态都是从这三个进行过度的：
 * 0 未开始，1 正在检验，2 检验通过，3 检验不通过
 * @author pengbingting
 *
 */
public enum CheckStatus {
	sleepCheck(0),checking(1),checkpass(2),checkInvalidate(3);
	private int status;
	CheckStatus(int status){
		this.status = status;
	}
	
	public int getStatus() {
		return status;
	}
	
	public static boolean isCheckPass(CheckStatus checkStatus){
		
		return checkpass == checkStatus;
	}
}
