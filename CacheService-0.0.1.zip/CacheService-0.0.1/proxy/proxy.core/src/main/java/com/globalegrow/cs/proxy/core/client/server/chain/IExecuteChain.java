package com.globalegrow.cs.proxy.core.client.server.chain;

import com.globalegrow.cs.proxy.core.client.server.RedisMessage;

import io.netty.channel.Channel;

/**
 * netty 接收消息时的执行链。因为可能会根据不同的命令有不同的处理。
 * 当有特殊命令（例如：自己扩展的命令）则新增一个执行链。在那里面实现相关的逻辑。
 * @author pengbingting
 *
 */
public interface IExecuteChain {

	/**
	 * 
	 * @param redisMessage
	 * @param channel
	 * @return true 则后续的 execute chain 将会执行。false 后面的execute chain 将不会执行。
	 */
	public boolean executeChain(RedisMessage redisMessage,Channel channel);
	
	/**
	 * @return 指定当前这个execute chain 在这组中的一个执行顺序
	 */
	public int getOrder();
}
