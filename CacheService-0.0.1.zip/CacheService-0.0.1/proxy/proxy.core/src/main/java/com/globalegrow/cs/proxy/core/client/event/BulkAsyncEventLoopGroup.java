package com.globalegrow.cs.proxy.core.client.event;

import org.apache.commons.lang.StringUtils;
import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.proxy.core.client.RedisClientFacade;
import com.globalegrow.cs.proxy.core.client.RedisProtocolCore;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.common.utils.cmd.Result;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Executor;
import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.channel.Channel;
import redis.clients.jedis.Jedis;

/**
* if handler the result will write signal bulk to redistribution client,then please extends this class.
* for example:brpoplpush command operation will response bulk
*/
public class BulkAsyncEventLoopGroup extends AbstractAsyncEventLoopGroup{
	public static final int BRPOPLPUH_EVENT = 1 ;
	public BulkAsyncEventLoopGroup(Executor executor, long loopInterval) {
		super(executor, loopInterval);
	}

	public BulkAsyncEventLoopGroup(String executorName, long loopInterval) {
		super(executorName, loopInterval);
	}

	@Override
	public void attachListener() {
		this.addListener(new PipelineObjectListener<ChannelRedisMessage>() {
			
			@Override
			public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
				ChannelRedisMessage channelRedisMessage = event.getValue();
				return jedisProcess(channelRedisMessage,BRPOPLPUH_EVENT);
			}
		}, BRPOPLPUH_EVENT);
	}
	
	private boolean brpoplpush(Jedis jedis, Result<String> result, RedisMessage redisMessage){
		String source = redisMessage.getKey();
		String destination = new String(redisMessage.getArgs().get(0));
		boolean flag = false ;
		String val = jedis.rpop(source);
		if (!StringUtils.isEmpty(val)) {
			flag = true ;
			result.setV(val);
			jedis.lpush(destination, val);
		}
		return flag;
	}
	@Override
	public boolean jedisProcess(ChannelRedisMessage channelRedisMessage, int cmdType) {

		Channel inboundChannel = channelRedisMessage.getChannel();
		RedisMessage redisMessage = channelRedisMessage.getRedisMessage();
		int appId = redisMessage.getAppId();
		if(!inboundChannel.isActive() || !inboundChannel.isOpen()){
			return true;
		}
		
		Result<String> result = new Result<String>() ;
		boolean flag = false;
		//handler the stand alone and sentinel
		Jedis jedis = null;
		try{
			jedis = RedisClientFacade.getJedis(appId);
			switch (cmdType) {
			case BRPOPLPUH_EVENT:
				flag = brpoplpush(jedis, result,channelRedisMessage.getRedisMessage());
				break;
			default:
				break;
			}
		}catch (Exception e) {
			Log.error("handler the redis command"+redisMessage.getCmd(), e);
			flag = false ;//must next event loop
		}finally{
			if(jedis != null){
				jedis.close();
			}
		}
		if(flag){
			handlerResult(result,channelRedisMessage);
		}
		return flag;
	}

	public byte[] getResponse(Result<String> result,ChannelRedisMessage redisMessage){
		byte[] response = RedisProtocolCore.writeBulkResponse(result.getV());
		return response;
	}

}
