package com.globalegrow.cs.proxy.core.client.server;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.util.List;
import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import redis.clients.jedis.exceptions.JedisConnectionException;

/**
 * 这里需要对收到的所有redis proxy 客户端发送的message 进行解码工作。因为这里面有我们比较重要的信息那就是
 * app id 来标识这个客户端是哪一个app id（由cache cloud 生成）发送的。
 * @author peng bing ting
 *
 */
public class RedisMessageDecoder extends ByteToMessageDecoder {
	public RedisMessageDecoder() {
	}
	/**
	 * 对 输入缓冲区 byte buffer 中的协议进行解析。
	 */
	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {

	 	int originalReadableBytes = in.readableBytes();
	 	//1、处理最基本的字节长度>=7
	 	if(originalReadableBytes<4){
	 		return;
	 	}
	 	//2、命令结束必须带有 \r\n 因此至少需要额外的两个字节
	 	if(originalReadableBytes < 11){
	 		return;
	 	}
	 	in.markReaderIndex();
	 	byte start = in.readByte();// * 
	 	if(start != '*'){
	 		in = in.resetReaderIndex();
	 		return ;
	 	}
	 	in.resetReaderIndex();
	 	
	 	ByteBuf tmpbuf = in.alloc().buffer(originalReadableBytes);
	 	in.markReaderIndex();
	 	tmpbuf.writeBytes(in);//the method will change the source bytebuf of readable index.so you must mark the readable index
	 	in.resetReaderIndex();
	 	if(!ensureCanReadable(tmpbuf)){
	 		Log.info("can not read the message,because the message is Incomplete. ");
	 		tmpbuf.release();
	 		return ;
	 	}
	 	//这里记录原生的 message。只因为需要对某些命令做直接转发的工作
	 	ByteArrayOutputStream originalMessage = new ByteArrayOutputStream(originalReadableBytes);
	 	ByteBuf rb = in.readBytes(in.bytesBefore((byte) '\r')+2);//这里多读两个字节，是因为下面获取长度的方法（readLongCrLf）需要带上 \r\n 判断。
	 	long argLength = readLongCrLf(rb.array());
	 	originalMessage.write(rb.array());
	 	rb.clear();
	 	//获取此处对redis操作一共发送多少个参数(命令本身也算是一个参数)
	 	ByteArrayOutputStream byteArrayOutputStream = null ;
	 	RedisMessage redisMessage = new RedisMessage();
	 	try {
			for (int i = 0; i < argLength; i++) {
				//step1:读取参数的长度
				rb = in.readBytes(in.bytesBefore((byte) '\r')+2);
				int argByteSize = (int) readLongCrLf(rb.array());//fetch the byte of argument size
				originalMessage.write(rb.array());
				
				//step2:根据参数的长度提取具体的参数值
				byteArrayOutputStream = new ByteArrayOutputStream(argByteSize);
				ByteBuf arg = in.readBytes(argByteSize);
				byteArrayOutputStream.write(arg.array());
				originalMessage.write(arg.array());
				
				//step3:处理
				Log.debug("read:"+new String(byteArrayOutputStream.toByteArray(), Charset.forName("utf-8")));
				if (i == 0) {
					//第一个是具体的redis 命令
					redisMessage.setCmd(new String(byteArrayOutputStream.toByteArray(), Charset.forName("utf-8")));
				}else if(i == 1){
					//第二个是命令之后跟的key 或者其他关键的东西。比如：cluster slots/nodes
					String setAppIdCmdStr = new String(byteArrayOutputStream.toByteArray(), Charset.forName("utf-8"));
					redisMessage.setAppIdCmdStr(setAppIdCmdStr);
				} else {
					//第三个就是values
					redisMessage.addArg(byteArrayOutputStream.toByteArray());
				}
				
				//the end step
				// \r\n 这两个字节没有读取解析，所以直接跳过。 in.skipBytes(2);
				originalMessage.write(in.readBytes(2).array());
				rb.clear();
			}
			redisMessage.setOriginalMessage(originalMessage);
			out.add(redisMessage);
		} finally {
			rb.release();
		}
	}

	/**
	 * 要确保是有一个完整可解码的消息
	 * @param in
	 * @return
	 */
	public boolean ensureCanReadable(ByteBuf in){
		int writerIndex = in.writerIndex();
		int dataLength = 0 ;
		//1.1 the head of message length
		int index = in.bytesBefore((byte) '\r');
		if(index == -1 || index+2 > writerIndex){
			return false;
		}
		//1.2、
		ByteBuf rb = in.readBytes(index+2);
		byte[] messageHead = rb.array();
		dataLength += messageHead.length;
		
		boolean isCan = true ;
		try {
			long argLength = readLongCrLf(rb.array());
			byte[] messageBody = null;
			for (int i = 0; i < argLength; i++) {
				//2.1
				index = in.bytesBefore((byte) '\r');
				if(index == -1 || (dataLength+index+2) > writerIndex){
					isCan = false;
					break;
				}
				//2.2、
				messageBody = in.readBytes(index + 2).array();
				dataLength += messageBody.length;
				//3.1
				int argByteSize = (int) readLongCrLf(messageBody);//fetch the byte of argument size
				if(dataLength+argByteSize+2 > writerIndex){
					isCan = false;
					break;
				}
				//3.2、
				in.readBytes(argByteSize);
				dataLength += argByteSize;
				//4.1、
				in.skipBytes(2);
				//4.2
				dataLength += 2;
			} 
		} finally {
			rb.release();
		}
		
		return isCan;
	}
	/**
	 * * 或者 $ 后面是直接跟大小(* 后面跟的是有几个参数，$ 后面跟的是参数大小)
	 * @param buf
	 * @return
	 */
	public long readLongCrLf(byte[] buf) {
		int count = 1;// 这里直接从第二个字节那里开始读了，跳过第一个字节是因为是个标识符（* or $）
		final boolean isNeg = buf[count] == '-';// is negative or not
		if (isNeg) {
			++count;
		}

		long value = 0;
		while (true) {
			final int b = buf[count++];
			if (b == '\r') {
				if (buf[count++] != '\n') {
					throw new JedisConnectionException("Unexpected character!");
				}

				break;
			} else {
				value = value * 10 + b - '0';
			}
		}

		return (isNeg ? -value : value);
	}
}
