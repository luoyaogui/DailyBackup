package com.globalegrow.cs.proxy.core.client.handler;

import java.io.ByteArrayOutputStream;
import java.util.List;

import com.globalegrow.cs.proxy.core.client.event.BulkAsyncEventLoopGroup;
import com.globalegrow.cs.proxy.core.client.event.EventObjectDispatcher;
import com.globalegrow.cs.proxy.core.client.event.MultiBulkAsyncEventLoopGroup;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.event.common.IdempotentConfirmer;
import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.channel.Channel;

public abstract class AbstractBlockingRedisCmdHandler extends AbstractSupportRedisCmdHandler {
	protected MultiBulkAsyncEventLoopGroup multiBulkAsyncEventLoop = new MultiBulkAsyncEventLoopGroup(EventObjectDispatcher.BLOCK_EXECUTOR, 500);
	protected BulkAsyncEventLoopGroup bulkAsyncEventLoopGroup = new BulkAsyncEventLoopGroup(EventObjectDispatcher.BLOCK_EXECUTOR, 500);
	@Override
	public void execute(final Channel channel,final RedisMessage redisMessage) {
		final int appid = redisMessage.getAppId();
		if (appid < 0 || appid > Integer.MAX_VALUE) {
			return;
		}
		final String key = redisMessage.getKey();
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
		
		boolean flag = true ;
		boolean result = new IdempotentConfirmer(3) {
			@Override
			public boolean execute() {
				byte[] byteBuffer = null ;
				try {
					//execute success then return null,exception 
					byteBuffer = AbstractBlockingRedisCmdHandler.this.execute(channel, appid, key,redisMessage.getArgs());
					if (byteBuffer == null || byteBuffer.length == 0) {
						return true;
					}
					baos.write(byteBuffer, 0, byteBuffer.length);
					return true;
				} catch (Exception e) {
					baos.reset();
					byteBuffer = e.getMessage().getBytes();
					baos.write(byteBuffer, 0, byteBuffer.length);
					Log.error("handler the redis cmd execute for the channel="+channel.toString()+" occuer the exception", e);
					return false ;
				}
			}
		}.run();
		flag = result;
		
		if(baos.size()>0){
			super.handlerResponse(channel, flag, baos.toByteArray(), redisMessage);
		}
	}

	public abstract byte[] execute(Channel channel, int appid, String key, List<byte[]> args) throws Exception;
}
