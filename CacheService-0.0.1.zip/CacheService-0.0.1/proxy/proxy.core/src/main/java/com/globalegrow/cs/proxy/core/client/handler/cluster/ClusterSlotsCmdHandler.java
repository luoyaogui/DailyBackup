package com.globalegrow.cs.proxy.core.client.handler.cluster;

import java.util.List;
import com.globalegrow.cs.proxy.core.client.ClientTemplateFacade;
import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.anotation.RedisCmd;
import com.globalegrow.cs.proxy.core.client.handler.AbstractBaseSupportRedisCmdHandler;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import io.netty.channel.Channel;

/**
 * the newest Jedis version(1.9+) use the cluster slots to descovery the new redis server.and
 * the less than 1.9 use the cluster nodes.
 * @author pengbingting
 *
 */
@RedisCmd(cmd=RedisProtocol.CLUSTER,desc="")
public class ClusterSlotsCmdHandler extends AbstractBaseSupportRedisCmdHandler {

	@Override
	public byte[] execute(Channel channel, int appid, String key, List<byte[]> args) throws Exception {
		if(RedisProtocol.CLUSTER_SLOTS.equals(key)){
			System.out.println(new String(ClientTemplateFacade.getClusterSlotsBytesTemplate()));
			return ClientTemplateFacade.getClusterSlotsBytesTemplate();
		}else if(RedisProtocol.CLUSTER_NODES.equals(key)){//带密码的Jedis 版本 只用 cluster slots 来做master 发现
			return ClientTemplateFacade.getClusterNodesBytesTemplate();
		}
		
		return String.format(ResponseMessage.UNSUPPORT_CMD, key).getBytes();
	}

}
