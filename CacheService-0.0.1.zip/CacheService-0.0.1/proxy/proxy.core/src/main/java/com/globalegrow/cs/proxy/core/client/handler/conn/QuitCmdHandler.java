package com.globalegrow.cs.proxy.core.client.handler.conn;

import java.util.List;
import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.anotation.RedisCmd;
import com.globalegrow.cs.proxy.core.client.handler.AbstractBaseSupportRedisCmdHandler;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;

@RedisCmd(cmd=RedisProtocol.QUIT,desc="")
public class QuitCmdHandler extends AbstractBaseSupportRedisCmdHandler {

	@Override
	public byte[] execute(Channel channel, int appid, String key, List<byte[]> args) throws Exception {
		Log.info("appid="+appid+" "+channel.toString()+" is quit.");
		return ResponseMessage.OK.getBytes();
	}

}
