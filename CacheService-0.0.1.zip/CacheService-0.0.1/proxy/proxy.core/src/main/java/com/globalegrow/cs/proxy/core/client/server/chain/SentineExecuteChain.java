package com.globalegrow.cs.proxy.core.client.server.chain;

import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.proxy.core.client.event.RedisProxyClientInspector;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;

/**
 * 跟 sentinel 相关的命令处理。客户端以sentinel 的模式连接时，需要使用sentinel 相关的命令来做master 发现。因此这里发现
 * 客户端发的是sentinel 相关的命令，这直接找相关的命令处理。
 * @author pengbingting
 *
 */

public class SentineExecuteChain extends AbstractExecuteChain {
	
	public SentineExecuteChain(Integer order) {
		super(order);
	}

	@Override
	public boolean executeChain(RedisMessage redisMessage, Channel channel) {
		String cmd = redisMessage.getCmd();
		String appIdKeyStr = redisMessage.getAppIdCmdStr();
		if(RedisProtocol.SENTINEL.equals(cmd.toUpperCase())){
			Log.debug("process the key of sentinel="+appIdKeyStr);
			redisMessage.setKey(appIdKeyStr);
			redisProxyClientCheck.publish(new ChannelRedisMessage(channel, redisMessage), RedisProxyClientInspector.REDIS_PROXY_CLIENT_PROCESS);
			return false;
		}
		return true;
	}

}
