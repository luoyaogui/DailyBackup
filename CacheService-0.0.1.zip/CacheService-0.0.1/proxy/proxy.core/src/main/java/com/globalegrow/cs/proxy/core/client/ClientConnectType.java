package com.globalegrow.cs.proxy.core.client;

import java.util.Locale;

/**
 * 标识客户端的连接类型。客户端连接类型为 集群时，代理拓扑结构发生变更时根据channel 的指定类型
 * 向客户端发送 服务发现的命令
 * @author pengbingting
 *
 */
public enum ClientConnectType {
    STANDALONE,SENTINEL,CLUSTER;
    public String name;

    ClientConnectType() {
    	name = this.name().toLowerCase(Locale.ENGLISH);
    }
  
    public static boolean isCluster(String src){
    	
    	return ClientConnectType.CLUSTER.name.equals(src);
    }
    
    public static boolean isSentinel(String src){
    
    	return ClientConnectType.SENTINEL.name.equals(src);
    }
    
    public static boolean isStandalone(String src){
    	
    	return ClientConnectType.STANDALONE.name.equals(src);
    }
    
    public static boolean isValidateType(String src){
    	
    	return STANDALONE.name.equals(src) || SENTINEL.name.equals(src) || CLUSTER.name.equals(src);
    }
}
