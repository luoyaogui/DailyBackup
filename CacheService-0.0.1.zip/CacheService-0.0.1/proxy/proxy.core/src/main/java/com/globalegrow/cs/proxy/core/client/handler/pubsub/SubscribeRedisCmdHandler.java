package com.globalegrow.cs.proxy.core.client.handler.pubsub;

import java.util.List;
import com.globalegrow.cs.proxy.core.client.ClientTemplateFacade;
import com.globalegrow.cs.proxy.core.client.RedisClientFacade;
import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.anotation.RedisCmd;
import com.globalegrow.cs.proxy.core.client.handler.AbstractBaseSupportRedisCmdHandler;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import io.netty.channel.Channel;

@RedisCmd(cmd=RedisProtocol.SUBSCRIBE,desc="")
public class SubscribeRedisCmdHandler extends AbstractBaseSupportRedisCmdHandler {

	@Override
	public byte[] execute(Channel channel, int appid, String key, List<byte[]> args) throws Exception {
		if(Constant.SENTINEL_SWITCH_TOPIC.equals(key)){
			System.out.println("sentienlSubscribeTemplate length ="+ClientTemplateFacade.sentienlSubscribeTemplate.length);
			System.out.println("sentienlSubscribeTemplate"+new String(ClientTemplateFacade.sentienlSubscribeTemplate));
			RedisClientFacade.putSubscribeChannel(Constant.SENTINEL_SWITCH_TOPIC,channel);
			return ClientTemplateFacade.sentienlSubscribeTemplate;
		}
		
		return String.format(ResponseMessage.UNSUPPORT_CHANNEL, key).getBytes();
	}

}
