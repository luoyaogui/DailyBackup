package com.globalegrow.cs.proxy.core.client.server.chain;

import com.globalegrow.cs.proxy.core.client.ClientConnectType;
import com.globalegrow.cs.proxy.core.client.ClientTemplateFacade;
import com.globalegrow.cs.proxy.core.client.RedisProtocolCore;
import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.proxy.core.client.server.RedisMessageHanndler;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.config.base.HostAndPort;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;

/**
 * 对客户端发送的redis command 执行链。
 * 主要是需要特殊处理 auth 命令和非auth 命令。
 * 1、如果是auth 命令。这个时候value 的值必须是：appid:appkey:type. 则需要在value 中解析出app id 和 appke以及连接类型.进行基本的处理
 * 2、如果是其他正常操作的命令。则需要判断是否是以 集群模式连接的客户端。必要时需要连接命令向客户端发送master 发现的命令(-MOVED)
 * @author pengbingting
 */
public class RedisCmdExecuteChain extends AbstractExecuteChain {

	public RedisCmdExecuteChain(Integer order) {
		super(order);
	}

	@Override
	public boolean executeChain(RedisMessage redisMessage, Channel channel) {
		String appIdKeyStr = redisMessage.getAppIdCmdStr();//有可能带app id 的key.目前只有AUTH 命令带有app id，其他的命令都没有
		String cmd = redisMessage.getCmd();
		if(RedisProtocolCore.AUTH.equals(cmd.toUpperCase())){
			Log.debug("start handler the AUTH command."+" the key is:"+appIdKeyStr);
			/**
			 * check the app id must integer
			 */
			//1、是否含有 : 符号
			if(appIdKeyStr.indexOf(Constant.APPID_CMD_SPLIT) == -1){
				String response = String.format(ResponseMessage.NO_INPUT_APPID, appIdKeyStr);
				Log.error(response);
				channel.writeAndFlush(response.getBytes());
				return false;
			}
			//2、是否有三个必要的参数
			String[] appIdKeyArr = appIdKeyStr.split(Constant.APPID_CMD_SPLIT);
			if(appIdKeyArr.length!=3){
				String response = String.format(ResponseMessage.ERROR_REPLY,"please use the { appid:appkey:connect type[cluster|sentinel|standalone] }format of value.");
				Log.error(response);
				channel.writeAndFlush(response.getBytes());
				return false;
			}
			//3、app id 是否是 整数
			String appIdStr = appIdKeyArr[0];
			if(!appIdStr.matches(Constant.INTEGER_REG)){
				String response = String.format(ResponseMessage.APPI_ERROR, appIdStr); 
				Log.error(response);
				channel.writeAndFlush(response.getBytes());
				return false;
			}
			
			//4、是否是 代理指定的连接类型
			if(!ClientConnectType.isValidateType(appIdKeyArr[2])){
				String response = String.format(ResponseMessage.ERROR_REPLY, "The type of connection supported[cluster|standalone|sentinel] by the client does not match.,the type of client connect type is: "+appIdKeyArr[2]);
				Log.error(response);
				channel.writeAndFlush(response.getBytes());
				return false;
			}
			
			redisMessage.setAppId(Integer.parseInt(appIdStr));
			redisMessage.setKey(appIdKeyArr[1]+":"+appIdKeyArr[2]);//让指定的auth 命令handler 处理
		}else{
			//check the current proxy client is the new epoll.if is not ,then tell the client to moved and update
			Integer appId = channel.attr(RedisMessageHanndler.appIdAttryKey).get();
			if(appId == null){
				channel.writeAndFlush(String.format(ResponseMessage.NONE_AUTH, cmd).getBytes());
				return false;
			}
			
			if(!checkClusterMoved(channel, appIdKeyStr)){
				return false;
			}
			
			if(!checkSentinel(channel,appIdKeyStr)){
				return false;
			}
			
			redisMessage.setAppId(appId.intValue());
			redisMessage.setKey(appIdKeyStr);
		}
		return true;
	}

	/**
	 * 这里是依赖与客户端做服务自发现的。如果proxy 依赖于zookeeper 让客户端做全量服务发现。则执行下面这个逻辑。
	 * 在验证通过之后就会标识当前这根 chanel 的 epoll 的值
	 */
	private boolean checkClusterMoved(Channel channel, String appIdKeyStr) {
		String clientConType = channel.attr(RedisMessageHanndler.channelConnectType).get();
		//目前支持支jedis 的客户端。Jedis 客户端使用密码的JedisCluster 版本时，使用的cluster slots来做master 发现的
		if(ClientConnectType.isCluster(clientConType)){
			long proxyClientEpoll = channel.attr(RedisMessageHanndler.clusterTemEpoolKey).get().longValue();
			long proxyEpoll = ClientTemplateFacade.clusterSlotesEpoll.get();
			return check(channel, appIdKeyStr, proxyClientEpoll, proxyEpoll);
		}
		return true ;
	}

	private boolean check(Channel channel, String appIdKeyStr, long proxyClientEpoll, long proxyEpoll) {
		if(proxyClientEpoll != proxyEpoll){
			if(Constant.CLUSTER_DISCOVER_KEY.indexOf(appIdKeyStr)==-1){//要判断客户端本身发的就不是master 发现的命令
				channel.attr(RedisMessageHanndler.clusterTemEpoolKey).set(proxyEpoll);
				HostAndPort proxyHostAndPort = ClientTemplateFacade.movedProxyHostAndPort;
				String movedMessage = ResponseMessage.formatMovedResponse(proxyHostAndPort.getPointSlot().getStartSlot()+1, proxyHostAndPort.getHost(), proxyHostAndPort.getPort());
				channel.writeAndFlush(movedMessage.getBytes());
				return false;
			}
		}
		
		return true;
	}

	private boolean checkSentinel(Channel channel, String appIdKeyStr) {
		String src = channel.attr(RedisMessageHanndler.channelConnectType).get();
		
		if(ClientConnectType.isSentinel(src)){
			//process something in here
			
		}
		return true ;
	}
}
