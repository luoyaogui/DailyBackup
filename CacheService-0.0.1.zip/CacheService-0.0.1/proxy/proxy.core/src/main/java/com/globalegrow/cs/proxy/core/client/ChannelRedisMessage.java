package com.globalegrow.cs.proxy.core.client;

import java.io.Serializable;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import io.netty.channel.Channel;

public class ChannelRedisMessage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Channel channel;
	private RedisMessage redisMessage;
	public ChannelRedisMessage() {
	}
	public ChannelRedisMessage(Channel channel, RedisMessage redisMessage) {
		super();
		this.channel = channel;
		this.redisMessage = redisMessage;
	}
	public Channel getChannel() {
		return channel;
	}
	public void setChannel(Channel channel) {
		this.channel = channel;
	}
	public RedisMessage getRedisMessage() {
		return redisMessage;
	}
	public void setRedisMessage(RedisMessage redisMessage) {
		this.redisMessage = redisMessage;
	}
	
}
