package com.globalegrow.cs.proxy.core.client.server.chain;

import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.proxy.core.client.event.RedisProxyClientInspector;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;

/**
 * 跟集群相关的命令 处理。
 * @author pengbingting
 *
 */
public class ClusterExecuteChain extends AbstractExecuteChain {

	public ClusterExecuteChain(Integer order) {
		super(order);
	}

	@Override
	public boolean executeChain(RedisMessage redisMessage, Channel channel) {
		String cmd = redisMessage.getCmd();
		String appIdKeyStr = redisMessage.getAppIdCmdStr();
		//如果发现是集群相关的命令，则直接找相关的 redis command handler 处理。后面的 execute chain 将不会执行
		if(RedisProtocol.CLUSTER.equals(cmd.toUpperCase())){
			Log.debug(this.getClass().getName()+" execute command ["+cmd+"] of key="+appIdKeyStr);
			redisMessage.setKey(appIdKeyStr);
			redisProxyClientCheck.publish(new ChannelRedisMessage(channel, redisMessage), RedisProxyClientInspector.REDIS_PROXY_CLIENT_PROCESS);
			Log.debug("[ END ]"+this.getClass().getName()+" execute. return [ false ]");
			return false;
		}
		return true;
	}

}
