package com.globalegrow.cs.proxy.core.context;

import java.io.IOException;
import java.text.MessageFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.globalegrow.cs.proxy.core.arbitrate.ZKArbitrateService;
import com.globalegrow.cs.proxy.core.lifecycle.AbstractLifeCycle;
import com.globalegrow.cs.proxy.core.monitor.GlobalManager;
import com.globalegrow.cs.shared.common.utils.AddressUtils;
import com.globalegrow.cs.shared.common.utils.JsonUtils;
import com.globalegrow.cs.shared.common.utils.model.config.ConfigException;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.config.prop.InitArbitrate;
import com.globalegrow.cs.shared.config.zk.base.ProxyNodeParameter;
import com.globalegrow.cs.shared.config.zk.store.ZKNodeTree;

import okhttp3.FormBody;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
* Title: ProxyController
* Description: 代理控制服务类
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月10日 上午9:58:15
*/
public class ProxyController extends AbstractLifeCycle {
	private static final Logger logger = LoggerFactory.getLogger(ProxyController.class);
	private InitArbitrate init = new InitArbitrate();
	@Autowired()
	ZKArbitrateService zkAr;

	@Override
    public void start() {
        if (super.isStart()) 
            throw new ConfigException("proxy has started ! please check…………");
        
        logger.info("loading  config …………………………………………");
        init.initConf();//初始化配置文件
        
        
        String url = getUrl();
        logger.info("request http …………………………………………"+url);
		RequestBody body = new FormBody.Builder().build();
		
		Response resp = init.httpPost(url,body);//检查代理的配置信息
		if(!resp.isSuccessful()){
			throw new ConfigException("http request failed, response :"+ resp);
		}
		
		logger.info("json decode …………………………………………");
		String json = null;
		try {
			json = resp.body().string();
		} catch (IOException e) {
			throw new ConfigException(e);
		}  
		ProxyNodeParameter param = JsonUtils.unmarshalFromString(json, ProxyNodeParameter.class);
		if(null == param)
			throw new ConfigException("ProxyNodeParameter decode failed    , response :"+ resp);
        	
		checkIpAndPort(param.getIp(),param.getPort());
		
		ZKNodeTree.getInstance().setGroup(param.getBelongProxyGroup());//保存组名
		GlobalManager.getInstance().setProxyUuid(init.getProxyUuid());//保存参数，共享
		GlobalManager.getInstance().setParamConfig(param);//保存参数，共享
		logger.info("ZKArbitrateService start …………………………………………");
		try {
			zkAr.start();
		} catch (Exception e) {
			throw new ConfigException("ZKArbitrateService start failed,  reason:"+e.getMessage());
		}
		super.start();
    }
    
    private void checkIpAndPort(String ip,int port){
    		if(!AddressUtils.isHostIp(ip))
    			throw new ConfigException(ip + " can't match local-ip, please check!");
    		if(AddressUtils.isAvailablePort(port))
    			throw new ConfigException(port + " can't bind, please check!");
    }
    
    private String getUrl(){
    		return MessageFormat.format(Constant.PROXY_NODE_HTTP_PATH,
    				init.getWebHost(),
    				String.valueOf(init.getWebPort()),
    				init.getCheckCode(),
    				String.valueOf(init.getProxyUuid()));
    }
}
