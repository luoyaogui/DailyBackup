package com.globalegrow.cs.proxy.core.client;

public final class ResponseMessage {

	public static final String OK = "+OK\r\n" ;
	
	public static final String PONG = "+PONG\r\n";
	
	public static final String QUEUED = "+QUEUED\r\n";
	
	public static final String UNSUPPORT_CMD_INPROXY = "-ERROR this redis command[ %s ] doen't support in proxy mode to deply of our redis proxy server!\r\n";
	
	public static final String UNSUPPORT_CMD = "-ERROR this redis command[ %s ] doen't support!\r\n";

	public static final String UNSUPPORT_CHANNEL = "-ERROR this channel of subscribe [ %s ] doen't support!\r\n";

	public static final String NONE_AUTH = "-ERROR doesn't auth anymore!please auth to the redis proxy before execute the cmd [%s]\r\n";
	
	public static final String NO_INPUT_APPID = "-ERROR please input the app id before the key[ %s ].please input the wright appid or contact the adminstrator!\r\n";
	
	public static final String APPI_ERROR ="-ERROR appid[ %s ] is invalidate.please input the wright appid or contact the adminstrator!\r\n";
	
	public static final String ERROR_PARAM = "-ERROR ERR wrong number of arguments for '%s' command!\r\n";
	
	public static final String ERROR_REPLY = "-ERROR %s\r\n";

	public static final String ERROR_REPLY_PLUS = "+ERROR %s\r\n";
	
	public static final String ERROR_NOT_SUPPORT_TRANSACTION = "-ERROR this operation doesn.t support transaction.because the redis deploy of you app is cluster.\r\n";
	
	public static final String ERROR_ISNOT_INTRANSACTION = "-ERROR this operation doesn.t support transaction.because is not in transaction.please execute multi command before.\r\n";
	
	public static final String REDIS_BUSY_NOW = "-ERROR redis is busy now posible after three execute the cmd[%s] and the redis server response none data.\r\n";
	
	public static final String ERROR_APPKEY = "-ERROR appkey[ %s ] is invalidate.please input the wright appid or contact the adminstrator!\r\n";
	
	public static final String ERROR_INIT_JEDIS_CLIENT = "-ERROR [ %s ] initialize redis client fail.please contact the adminstrator make sure that all of the redis instance is alive.\r\n" ;
	
	public static final String ERROR_MOVED = "-MOVED %s %s:%s\r\n";
	
	public static final String ERROR_PARAM_ZINTERSTORE_PARAM = "-ERROR [ ZINTERSTORE ] parameter is error[%s].\r\n";
	
	public static final String ERROR_PARAM_ZINTERSTORE_AGGREGATE = "-ERROR [ ZINTERSTORE ] parameter of aggergate is error[%s].\r\n";
	
	public static final String ERROR_PARAM_ZINTERSTORE_WEIGHTS = "-ERROR [ ZINTERSTORE ] the count parameter of weights is error. expect count is [%s] but the real value is[%s].\r\n";

	public static final String ERROR_PARAM_ZINTERSTORE_WEIGHTS_VALUE = "-ERROR [ ZINTERSTORE ] parameter of weighs is error[%s].\r\n";

	public static final String ERROR_PARAM_ZINTERSTORE_WEIGHTS_KEYWORDS = "-ERROR [ ZINTERSTORE ] parameter of weighs keyword is error[%s].\r\n";
	
	public static final String ERROR_PARAM_ZSCAN_PARAM = "-ERROR [ ZSCAN ] params pointed %s is doesn't supprt.\r\n";
	
	public static String formatMovedResponse(int slot,String ip,int port){
		
		return String.format(ERROR_MOVED, slot,ip,port);
	}
	
	public static void main(String[] args) {
		System.out.println(String.format(ERROR_PARAM, "APPEND"));
	}
}
