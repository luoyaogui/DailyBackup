package com.globalegrow.cs.proxy.core.client.server.chain;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.proxy.core.client.CheckStatus;
import com.globalegrow.cs.proxy.core.client.RedisClientFacade;
import com.globalegrow.cs.proxy.core.client.event.RedisProxyClientInspector;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;

/**
 * 执行链中的最后一个。在这里将会处理普通的redis 命令了。
 * @author pengbingting
 *
 */
public class DefaultExecuteChain extends AbstractExecuteChain {

	public DefaultExecuteChain(Integer order) {
		super(order);
	}
	private ConcurrentHashMap<Integer,ReentrantLock> clientLockRegister = new ConcurrentHashMap<Integer,ReentrantLock>();
	@Override
	public boolean executeChain(RedisMessage redisMessage, Channel channel) {
		int appId = redisMessage.getAppId();//注意这里给cache cloud 留一个可用的app id ，以便可以自由的给redis proxy 发送一些消息。比如说app id 新增
		//如果对这个 app id 检测通过了，则不需要每次请求都做一次权限检测的操作
		if(isCheck(appId)){
			Log.debug("app id["+appId+"] has checked success.");
			redisProxyClientCheck.publish(new ChannelRedisMessage(channel, redisMessage), RedisProxyClientInspector.REDIS_PROXY_CLIENT_PROCESS);
		}else{
			Log.debug("app id["+appId+"] Not checked yet.");
			ReentrantLock lock = clientLockRegister.putIfAbsent(appId, new ReentrantLock(true));
			if(lock==null){
				lock = clientLockRegister.get(appId);
			}
			try{
				lock.tryLock(3, TimeUnit.SECONDS);
				redisProxyClientCheck.publish(new ChannelRedisMessage(channel, redisMessage), RedisProxyClientInspector.REDIS_PROXY_CLIENT_CHECK);
			}catch(Exception e){
				logger.error("appid="+appId+" check occur exception", e);
			}finally{
				lock.unlock();
			}
		}
		return true;
	}

	private boolean isCheck(int appId) {
		return Constant.CACHE_CLOUD_APPID == appId || CheckStatus.isCheckPass(RedisClientFacade.getAppCheckStatus(appId,Constant.APP_SECRET_KEY));
	}
}
