package com.globalegrow.cs.proxy.core.client.event;

import org.apache.commons.lang.StringUtils;
import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.proxy.core.client.RedisClientFacade;
import com.globalegrow.cs.proxy.core.client.RedisProtocolCore;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.common.utils.cmd.Result;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Executor;
import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.channel.Channel;
import redis.clients.jedis.Jedis;

/**
 * 
 * if handler the result will write multiple bulk to redistribution client,then please extends this class
 * for example:brpop blpop command operation will response multiple bulk
 * @author pengbingting
 *
 */
public class MultiBulkAsyncEventLoopGroup extends AbstractAsyncEventLoopGroup{
	
	public static final int BLPOP_EVENT = 1 ; 
	public static final int BRPOP_EVENT = 2 ; 
	
	public MultiBulkAsyncEventLoopGroup(Executor executor, long loopInterval) {
		super(executor, loopInterval);
	}

	@Override
	public void attachListener() {
		this.addLast(new PipelineObjectListener<ChannelRedisMessage>() {
			@Override
			public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
				ChannelRedisMessage channelRedisMessage = event.getValue();
				return jedisProcess(channelRedisMessage,BLPOP_EVENT);
			}
		}, BLPOP_EVENT);
		
		this.addLast(new PipelineObjectListener<ChannelRedisMessage>() {

			@Override
			public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
				ChannelRedisMessage channelRedisMessage = event.getValue();
				return jedisProcess(channelRedisMessage,BRPOP_EVENT);
			}
		}, BRPOP_EVENT);
	}
	/**
	 * 
	 * @param channelRedisMessage
	 * @param cmdType
	 * @return
	 */
	@Override
	public boolean jedisProcess(ChannelRedisMessage channelRedisMessage,int cmdType){
		Channel inboundChannel = channelRedisMessage.getChannel();
		RedisMessage redisMessage = channelRedisMessage.getRedisMessage();
		int appId = redisMessage.getAppId();
		if(!inboundChannel.isActive() || !inboundChannel.isOpen()){
			return true;
		}
		
		Result<String> result = new Result<String>() ;
		boolean flag = false;
		//handler the stand alone and sentinel
		Jedis jedis = null;
		try{
			jedis = RedisClientFacade.getJedis(appId);
			switch (cmdType) {
			case BLPOP_EVENT:
				flag = blpopProcess(jedis, result,channelRedisMessage.getRedisMessage());
				break;
			case BRPOP_EVENT:
				flag = brpopProcess(jedis, result,channelRedisMessage.getRedisMessage());
				break;
			default:
				break;
			}
		}catch (Exception e) {
			Log.error("handler the redis command"+redisMessage.getCmd(), e);
			flag = false ;//must next event loop
		}finally{
			if(jedis != null){
				jedis.close();
			}
		}
		if(flag){
			handlerResult(result,channelRedisMessage);
		}
		
		return flag;
	}
	
	/**
	 * 
	 * @return if return false,then the event will push event loop queue and wait next handler.
	 *  or return true then remove from the event loop queue.
	 */
	public boolean blpopProcess(Jedis jedis, Result<String> result, RedisMessage redisMessage) {
		boolean flag = false ;
		String val = jedis.lpop(redisMessage.getKey());
		if (StringUtils.isEmpty(val)) {//处理动多个队列取值的情况。依次取完，若前一个队列的值没有取完，是不会从后面的队列里面去的
			if(!redisMessage.getArgs().isEmpty()){
				//handler multiple keys block pop operation
				for(byte[] keys : redisMessage.getArgs()){
					val = jedis.lpop(new String(keys));
					if(val == null || val.equals("null")){
						continue;
					}
					flag = true ;
					result.setV(val); break;
				}
			}
		}else{
			flag = true ;
			result.setV(val);
		}
		return flag;
	}
	
	public boolean brpopProcess(Jedis jedis, Result<String> result, RedisMessage redisMessage) {
		boolean flag = false ;
		String val = jedis.rpop(redisMessage.getKey());
		if (StringUtils.isEmpty(val)) {
			if(!redisMessage.getArgs().isEmpty()){
				//handler multiple keys block pop operation
				for(byte[] keys : redisMessage.getArgs()){
					val = jedis.rpop(new String(keys));
					if(val == null || val.equals("null")){
						continue;
					}
					flag = true ;
					result.setV(val); break;
				}
			}
		}else{
			flag = true ;
			result.setV(val);
		}
		
		return flag;
	}
	
	/**
	 * if return true then response the result to redistribution proxy client
	 */
	@Override
	public byte[] getResponse(Result<String> result, ChannelRedisMessage redisClient) {
		byte[] response = RedisProtocolCore.writeMultiBulkResponse(redisClient.getRedisMessage().getKey(),result.getV());
		return response;
	}

}
