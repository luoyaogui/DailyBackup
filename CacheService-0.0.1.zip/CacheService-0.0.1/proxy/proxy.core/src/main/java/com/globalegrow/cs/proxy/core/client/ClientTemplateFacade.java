package com.globalegrow.cs.proxy.core.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import com.globalegrow.cs.proxy.core.lifecycle.AbstractLifeCycle;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.config.base.HostAndPort;
import com.globalegrow.cs.shared.config.base.PointSlot;
import com.globalegrow.cs.shared.event.common.Facade;
import com.globalegrow.cs.shared.event.task.queue.Log;

public class ClientTemplateFacade extends AbstractLifeCycle implements Facade{
	
	private static volatile byte[] clusterSlotsBytesTemplate = null ;//使用cluster slots
	public static volatile AtomicLong clusterSlotesEpoll = new AtomicLong(0) ;//记录当前template 的最新值
	
	private static volatile byte[] clusterNodesBytesTemplate = null ;//使用cluster nodes
	public static volatile AtomicLong clusterNodesEpoll = new AtomicLong(0) ;//记录当前template 的最新值
	/**
	 * moved error message only tell redis client slots have redistribute,then reinitialize
	 */
	public static volatile HostAndPort movedProxyHostAndPort = null ;
	
	public static volatile byte[] sentienlSubscribeTemplate = null ;
	public static volatile byte[] sentinelGetMasterAddrTemplate = null ;
	public static volatile byte[] sentinelMasterSwitcherTemplate = null ;
	public static volatile AtomicLong sentinelEpoll = new AtomicLong(0) ;//记录当前template 的最新值
	
	//模板生成注册表
	public static ConcurrentHashMap<Integer, List<PointSlot>> templateRegister = new ConcurrentHashMap<>();
	@Override
	public void start() {
		super.start();
		//1、
		generatorSentienlSubscribeTemplate();
		//2、
		Log.debug("Pre initialization the cluster template of size ["+Constant.INIT_CLUSTER_TEMPLATE_SIZE+"]");
		for(int size=1;size<=Constant.INIT_CLUSTER_TEMPLATE_SIZE;size++){
			generSlotsRange(size);
		}
	}
	@Override
	public void stop() {
		super.stop();
	}
	
	/**
	 *  template format example below.Jedis 老版本依赖于这个命令做master 发现。只会解析出master 行信息。因此我们这里只生成master 的信息
	    $709
		7662356b792e1fa4074880004431dc8a16e48f55 10.40.6.114:6380 myself,master - 0       0       1 connected 0-5461
		e6b3e0a6a67870e22f8b2e03252ae6f244364a2b 10.40.6.114:6382 master        - 0 1490621068583 0 connected 5462-10923
		2ef4aaac713d4450246f9e42f4201feb54cc7c12 10.40.6.114:6384 master        - 0 1490621069586 2 connected 10924-16383
	 * @return
	 */
	public static boolean generatorClusterNodesTemplate(List<HostAndPort> proxyHostAndPort){
		Log.debug("generator cluster nodes template .the topological structure size is="+proxyHostAndPort.size()+",the detail info :"+proxyHostAndPort.toString());
		String nodeFormat = "%s %s %s - 0 %s 1 connected %s-%s";
		String localiP = redis.clients.jedis.HostAndPort.getLocalHostQuietly();
		ArrayList<String> masterNodeList = new ArrayList<String>();
		for(HostAndPort hap:proxyHostAndPort){
			String roleName = localiP.equals(hap.getHost()) ? "myself,master":"master";
			masterNodeList.add(String.format(nodeFormat, getNodeId(),hap.getHostAndPort(),roleName,System.currentTimeMillis(),hap.getPointSlot().getStartSlot(),hap.getPointSlot().getEndSlot()));
		}
		StringBuffer sb = new StringBuffer();
		for(String str:masterNodeList){
			sb.append(str);
			sb.append("\r\n");
		}
		byte[] template = sb.toString().getBytes();
		ByteArrayOutputStream baos;
		try {
			baos = new ByteArrayOutputStream();
			int count = 0 ;
			byte[] byteVal = new byte[8192];
			byteVal[count++] = '$';
			count = RedisProtocolCore.writeIntCrLf(template.length, byteVal, count);
			int tmpLimit = count -1 ;
			for(int index = tmpLimit;index<tmpLimit+template.length;index++){
				byteVal[count++] = template[index-tmpLimit];
			}
			baos.write(byteVal, 0, count);
			clusterNodesBytesTemplate = baos.toByteArray();
			Log.debug(new String(clusterNodesBytesTemplate));
		} catch (IOException e) {
			Log.error("generator cluster template cause an exception",e);
			return false;
		}
		clusterNodesEpoll.incrementAndGet();
		return true;
	}
	
	/**
	 * 
	 * @param proxyHostAndPort
	 * @return
	 */
	public static boolean generatorClusterSlotsTemplate(List<HostAndPort> proxyHostAndPort){
		Log.debug("generator cluster slots template .the topological structure size is="+proxyHostAndPort.size()+",the detail info :"+proxyHostAndPort.toString());
		final ByteArrayOutputStream baos = new ByteArrayOutputStream() ;
		try {
			int count = 0 ;
			byte[] byteVal = new byte[8192];
			byteVal[count++] = '*';
			count = RedisProtocolCore.writeIntCrLf(proxyHostAndPort.size(), byteVal, count);
			List<PointSlot> slotRange = generSlotsRange(proxyHostAndPort.size());
			movedProxyHostAndPort = proxyHostAndPort.get(0);
			movedProxyHostAndPort.setPointSlot(slotRange.get(0));
			for(int index = 0;index<proxyHostAndPort.size();index++){
				proxyHostAndPort.get(index).setPointSlot(slotRange.get(index));
			}
			for(int i=0;i<proxyHostAndPort.size();i++){
				PointSlot point = slotRange.get(i);
				byteVal[count++] = '*';
				count = RedisProtocolCore.writeIntCrLf(3,byteVal,count);
				byteVal[count++] = ':';
				count = RedisProtocolCore.writeIntCrLf(point.getStartSlot(),byteVal,count);
				byteVal[count++] = ':';
				count = RedisProtocolCore.writeIntCrLf(point.getEndSlot(),byteVal,count);
				byteVal[count++] = '*';
				count = RedisProtocolCore.writeIntCrLf(2, byteVal, count);
				byteVal[count++] = '$';
				HostAndPort proxyHostPort = proxyHostAndPort.get(i);
				count = RedisProtocolCore.writeIntCrLf(proxyHostPort.getHost().getBytes().length, byteVal, count);
				byte[] ipAddress = proxyHostPort.getHost().getBytes();
				int tmpLimit = count -1 ;
				for(int index = tmpLimit;index<tmpLimit+ipAddress.length;index++){
					byteVal[count++] = ipAddress[index-tmpLimit];
				}
				byteVal[count++] = '\r' ;
				byteVal[count++] = '\n' ;
				byteVal[count++] = ':' ;
				count = RedisProtocolCore.writeIntCrLf(proxyHostPort.getPort(), byteVal, count);
			}
			
			baos.write(byteVal, 0, count);
			clusterSlotsBytesTemplate = baos.toByteArray();
			Log.debug(clusterSlotsBytesTemplate);
		} catch (IOException e) {
			Log.error("generator cluster slots template cause an exception.",e);
			return false;
		}
		clusterSlotesEpoll.incrementAndGet();
		return true;
	}
	
	public static List<PointSlot> generSlotsRange(int clusterSize) {
		List<PointSlot> slotRange = templateRegister.putIfAbsent(clusterSize, new ArrayList<PointSlot>(clusterSize));
		if(slotRange!=null && slotRange.size()>0){//size >0 表示已经分配好了
			return slotRange;
		}
		
		slotRange = templateRegister.get(clusterSize);
		
		final int masterSize = clusterSize;
		int perSize = (int) Math.ceil(16384 / masterSize);
		int index = 0;
		final ArrayList<Integer> slots = new ArrayList<Integer>();
		// 分配slot
		for (int slot = 0; slot <= 16383; slot++) {
			slots.add(slot);
			if (index++ >= perSize || slot == 16383) {
				slotRange.add(new PointSlot(slots.get(0), slots.get(slots.size()-1)));
				slots.clear();
				index = 0;
			}
		}
		return slotRange;
	}
	
	/**
	 *  客户端使用sentinel连接时，使用 sentinel get-master-addr-by-name 返回的模板信息：
	 *  故：当proxy server 逻辑结构发生变更时，需要动态生成这个模板
	 * 	templeate format example:	
	 * 		*2
			$11
			10.40.6.118
			$4
			6407
	 * @param proxyHostAndPort
	 */
	public static void generatorSentinelMasterTemplate(HostAndPort proxyHostAndPort){
		Log.debug("generator sentinel master template:"+proxyHostAndPort.getHostAndPort());
		final ByteArrayOutputStream bytes = new ByteArrayOutputStream(8192);
		byte[] byteVal = new byte[8192];
		int count = 0 ;
		byteVal[count++] = '*';
		try {
			count = RedisProtocolCore.writeIntCrLf(2, byteVal, count);
			byteVal[count++] = '$';
			count = RedisProtocolCore.writeIntCrLf(proxyHostAndPort.getHost().length(), byteVal, count);
			byte[] ipAddress = proxyHostAndPort.getHost().getBytes();
			int tmpLimit = count -1 ;
			for(int index = tmpLimit;index<tmpLimit+ipAddress.length;index++){
				byteVal[count++] = ipAddress[index-tmpLimit];
			}
			byteVal[count++] = '\r' ;
			byteVal[count++] = '\n' ;
			byteVal[count++] = '$';
			count = RedisProtocolCore.writeIntCrLf(String.valueOf(proxyHostAndPort.getPort()).length(), byteVal, count);
			byte[] portBytes = String.valueOf(proxyHostAndPort.getPort()).getBytes();
			tmpLimit = count -1 ;
			for(int index = tmpLimit;index<tmpLimit+portBytes.length;index++){
				byteVal[count++] = portBytes[index-tmpLimit];
			}
			byteVal[count++] = '\r' ;
			byteVal[count++] = '\n' ;
			bytes.write(byteVal, 0, count);
			sentinelGetMasterAddrTemplate = bytes.toByteArray();
			sentinelEpoll.incrementAndGet();
			Log.debug("generator sentinel master template:"+new String(sentinelGetMasterAddrTemplate));
		} catch (IOException e) {
			Log.error("generator sentinel master template cause an exception", e);
		}
	}
	
	/**
	 * 客户端以sentinel 的方式连接的时候，都会subscribe master 切换的订阅频道。
	 * 一开始收到subscribe 的消息后，应该返回这样的模板信息：	而且这个模板是固定不变的
	 * 		*3
			$9
			subscribe
			$14
			+switch-master
			:1
	 */
	public static void generatorSentienlSubscribeTemplate(){
		Log.debug("generator sentinel subscribe template.");
		final ByteArrayOutputStream bytes = new ByteArrayOutputStream(8192);
		byte[] byteVal = new byte[8192];
		int count = 0 ;
		byteVal[count++] = '*';
		try {
			count = RedisProtocolCore.writeIntCrLf(3, byteVal, count);
			byteVal[count++] = '$';
			count = RedisProtocolCore.writeIntCrLf(9, byteVal, count);
			byte[] ipAddress = "subscribe".getBytes();
			int tmpLimit = count -1 ;
			for(int index = tmpLimit;index<tmpLimit+ipAddress.length;index++){
				byteVal[count++] = ipAddress[index-tmpLimit];
			}
			byteVal[count++] = '\r' ;
			byteVal[count++] = '\n' ;
			byteVal[count++] = '$';
			count = RedisProtocolCore.writeIntCrLf(14, byteVal, count);
			byte[] channelBytes = "+switch-master".getBytes();
			tmpLimit = count -1 ;
			for(int index = tmpLimit;index<tmpLimit+channelBytes.length;index++){
				byteVal[count++] = channelBytes[index-tmpLimit];
			}
			byteVal[count++] = '\r' ;
			byteVal[count++] = '\n' ;
			byteVal[count++] = ':';
			count = RedisProtocolCore.writeIntCrLf(1, byteVal, count);
			bytes.write(byteVal, 0, count);
			sentienlSubscribeTemplate = bytes.toByteArray();
			Log.debug("sentienl subscribe template:"+new String(sentienlSubscribeTemplate));
		} catch (IOException e) {
			e.printStackTrace();
			Log.error("sentinel subscribe template cause an exception", e);
		}
	}
	
	/**
	 * 
	 *  作用：生成这个模板数据主要是因为客户端以sentinel 的连接方式时，监听master 挂了或者进行切换时，在 +switch-master channel 发送
	 *  master 切换的消息数据
	  * template for example below:	
	  * 	*3
			$7
			message
			$14
			+switch-master
			$59
			sentinel-10.40.6.118-6406 10.40.6.118 6407 10.40.6.118 6406
	 * master 下线或者切换时的server
	 * @param proxyHostAndPort
	 */
	public static void generatorMasterSwitcherTemplate(HostAndPort offlineProxyServer,HostAndPort masterProxyServer){
		Log.debug("generator master switcher template.the off line proxy server is:"+offlineProxyServer.getHostAndPort()+"; switch master is:"+masterProxyServer.getHostAndPort());
		final ByteArrayOutputStream bytes = new ByteArrayOutputStream(8192);
		byte[] byteVal = new byte[8192];
		int count = 0 ;
		byteVal[count++] = '*';
		try {
			count = RedisProtocolCore.writeIntCrLf(3, byteVal, count);
			//1、
			byteVal[count++] = '$';
			count = RedisProtocolCore.writeIntCrLf(7, byteVal, count);
			byte[] ipAddress = "message".getBytes();
			int tmpLimit = count -1 ;
			for(int index = tmpLimit;index<tmpLimit+ipAddress.length;index++){
				byteVal[count++] = ipAddress[index-tmpLimit];
			}
			byteVal[count++] = '\r' ;
			byteVal[count++] = '\n' ;
			//2、
			byteVal[count++] = '$';
			count = RedisProtocolCore.writeIntCrLf(14, byteVal, count);
			byte[] switchMaster = "+switch-master".getBytes();
			tmpLimit = count -1 ;
			for(int index = tmpLimit;index<tmpLimit+switchMaster.length;index++){
				byteVal[count++] = switchMaster[index-tmpLimit];
			}
			byteVal[count++] = '\r' ;
			byteVal[count++] = '\n' ;
			//3、
			String switchMasterDetail = "sentinel-proxy %s %s %s %s";
			switchMasterDetail = String.format(switchMasterDetail, offlineProxyServer.getHost(),offlineProxyServer.getPort(),masterProxyServer.getHost(),masterProxyServer.getPort());
			byteVal[count++] = '$';
			byte[] switchMasterDetailBytes = switchMasterDetail.getBytes();
			count = RedisProtocolCore.writeIntCrLf(switchMasterDetailBytes.length, byteVal, count);
			tmpLimit = count -1 ;
			for(int index = tmpLimit;index<tmpLimit+switchMasterDetailBytes.length;index++){
				byteVal[count++] = switchMasterDetailBytes[index-tmpLimit];
			}
			byteVal[count++] = '\r' ;
			byteVal[count++] = '\n' ;
			
			bytes.write(byteVal, 0, count);
			sentinelMasterSwitcherTemplate = bytes.toByteArray();
			Log.debug("generator master switch template of client sentienl is:"+new String(sentinelMasterSwitcherTemplate));
		} catch (IOException e) {
			Log.error("generator master switch template cause an exception.",e);
		}
	}

	private static String getNodeId(){
		StringBuffer sb =  new StringBuffer();
		sb.append(UUID.randomUUID().toString());
		int startIndex = new Random().nextInt(32)+1;
		sb.append(UUID.randomUUID().toString().subSequence(startIndex, startIndex+4));
		return sb.toString();
	}
	
	public static byte[] getClusterSlotsBytesTemplate(){
		
		return clusterSlotsBytesTemplate;
	}
	
	public static byte[] getClusterNodesBytesTemplate(){
		
		return clusterNodesBytesTemplate;
	}
}
