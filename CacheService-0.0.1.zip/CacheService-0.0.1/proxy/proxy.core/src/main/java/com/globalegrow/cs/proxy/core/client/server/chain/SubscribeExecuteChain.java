package com.globalegrow.cs.proxy.core.client.server.chain;

import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.proxy.core.client.event.RedisProxyClientInspector;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;

/**
 * 跟发布订阅相关的命令处理。
 * 客户端以sentinel 模式连接时，或者直接发送 发布订阅的命令时，需要特殊处理。
 * @author pengbingting
 *
 */
public class SubscribeExecuteChain extends AbstractExecuteChain{

	public SubscribeExecuteChain(Integer order) {
		super(order);
	}

	@Override
	public boolean executeChain(RedisMessage redisMessage, Channel channel) {
		String cmd = redisMessage.getCmd();
		String appIdKeyStr = redisMessage.getAppIdCmdStr();
		if(RedisProtocol.SUBSCRIBE.equals(cmd.toUpperCase())){
			Log.debug("process the key of subscribe="+appIdKeyStr);
			redisMessage.setKey(appIdKeyStr);
			redisProxyClientCheck.publish(new ChannelRedisMessage(channel, redisMessage), RedisProxyClientInspector.REDIS_PROXY_CLIENT_PROCESS);
			return false;
		}
		return true;
	}

}
