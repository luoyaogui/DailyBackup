package com.globalegrow.cs.proxy.core.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;
import java.util.concurrent.locks.ReentrantLock;
import com.globalegrow.cs.proxy.core.client.server.WriterFutureListener;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.config.base.HostAndPort;
import com.globalegrow.cs.shared.config.base.RedisProtocol;
import com.globalegrow.cs.shared.event.common.Facade;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;

public class RedisProxyClusterFacade implements Facade{

	//集群模式下服务发现的cluster slots/nodes
	public final static List<String> CLUSTER_DISCOVER_KEY = Arrays.asList(RedisProtocol.CLUSTER_SLOTS,RedisProtocol.CLUSTER_NODES);
	
	public static final TreeMap<HostAndPort,HostAndPort> proxyServerRegister = new TreeMap<HostAndPort,HostAndPort>(new Comparator<HostAndPort>() {
		@Override
		public int compare(HostAndPort o1, HostAndPort o2) {
			int flag = o1.getHost().compareTo(o2.getHost());
			
			return flag == 0 ? o1.getPort()-o2.getPort() : flag;
		}
	}); 
	
	private final static ReentrantLock lock = new ReentrantLock(true);
	
	/**
	 * 当有一台server 上线的时候，需要调用该接口方法，重新生成一份cluster slots 的模板数据
	 * @param proxyHostAndPort
	 */
	public static void addProxyServer(HostAndPort proxyHostAndPort){
		System.out.println("add proxy server:"+proxyHostAndPort.toString());
		lock.lock();
		try{
			proxyServerRegister.put(proxyHostAndPort,proxyHostAndPort);
			List<HostAndPort> proxyHostAndPorts = new ArrayList<HostAndPort>(proxyServerRegister.size());
			for(HostAndPort proxyServer : proxyServerRegister.keySet()){
				proxyHostAndPorts.add(proxyServer);
			}
			
			ClientTemplateFacade.generatorClusterSlotsTemplate(proxyHostAndPorts);
			ClientTemplateFacade.generatorClusterNodesTemplate(proxyHostAndPorts);
			//服务上线的时候，直选一台让客户端连接
			if(ClientTemplateFacade.sentinelGetMasterAddrTemplate == null){
				ClientTemplateFacade.generatorSentinelMasterTemplate(proxyHostAndPort);
			}
		}finally{
			lock.unlock();
		}
	}
	
	/**
	 * 当有一台server 下线的时候，需要调用该接口方法，重新生成一份cluster slots 的模板数据
	 * @param proxyHostAndPort
	 */
	@SuppressWarnings("unchecked")
	public static void removeProxyServer(HostAndPort proxyHostAndPort){
		System.out.println("remove proxy server:"+proxyHostAndPort.toString());
		lock.lock();
		try{
			proxyServerRegister.remove(proxyHostAndPort);
			List<HostAndPort> proxyHostAndPorts = new ArrayList<HostAndPort>(proxyServerRegister.size());
			for(HostAndPort proxyServer : proxyServerRegister.keySet()){
				proxyHostAndPorts.add(proxyServer);
			}
			if(proxyHostAndPorts.isEmpty()){
				return ;
			}
			
			ClientTemplateFacade.generatorClusterSlotsTemplate(proxyHostAndPorts);
			ClientTemplateFacade.generatorClusterNodesTemplate(proxyHostAndPorts);
			//1、server 逻辑结构发生变更，更新客户端连接的模板选第一个，并通知所有的客户端更新跟master 的连接
			ClientTemplateFacade.generatorSentinelMasterTemplate(proxyHostAndPorts.get(0));
			//2、同时生产使用发布订阅的response 模板数据
			ClientTemplateFacade.generatorMasterSwitcherTemplate(proxyHostAndPort,proxyHostAndPorts.get(0));
			//3、notify all client
			Collection<Channel> subscribeChannels =	RedisClientFacade.getSubscribeChannel(Constant.SENTINEL_SWITCH_TOPIC);
			if(subscribeChannels == null){
				return;
			}
			
			for(Channel channel:subscribeChannels){
				ChannelFuture channelFuture = channel.writeAndFlush(ClientTemplateFacade.sentinelMasterSwitcherTemplate);
				channelFuture.addListeners(new WriterFutureListener("switcher master", new String(ClientTemplateFacade.sentinelMasterSwitcherTemplate)));
			}
		}finally{
			lock.unlock();
		}
	}
	
}
