package com.globalegrow.cs.proxy.core.client.server;

import java.util.concurrent.TimeUnit;
import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.timeout.IdleStateHandler;

public class RedisChannelInitializer extends ChannelInitializer<SocketChannel> {

	@Override
	protected void initChannel(SocketChannel socketChannel) throws Exception {
		//slave handler for client channel handler
		Log.debug(socketChannel.toString()+" initialize.");
		ChannelPipeline channelPipeline = socketChannel.pipeline();
		channelPipeline.addLast(new RedisMessageDecoder());
		channelPipeline.addLast(new RedisMessageEncoder());
		channelPipeline.addLast(new IdleStateHandler(0, 0, 90, TimeUnit.SECONDS));
		channelPipeline.addLast(new RedisMessageHanndler());
	}

}
