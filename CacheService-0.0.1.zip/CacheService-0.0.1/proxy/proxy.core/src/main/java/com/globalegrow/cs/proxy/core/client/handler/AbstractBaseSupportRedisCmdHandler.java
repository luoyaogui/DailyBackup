package com.globalegrow.cs.proxy.core.client.handler;

import java.io.ByteArrayOutputStream;
import java.util.List;

import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.shared.event.common.IdempotentConfirmer;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;
import redis.clients.util.SafeEncoder;

public abstract class AbstractBaseSupportRedisCmdHandler extends AbstractSupportRedisCmdHandler {

	@Override
	public void execute(final Channel channel,final RedisMessage redisMessage) {
		final int appid = redisMessage.getAppId();
		if (appid < 0 || appid > Integer.MAX_VALUE) {
			return;
		}
		final String key = redisMessage.getKey();
		final ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Log.debug("[ BEGIN ] handler the redistribution command="+redisMessage.getCmd()+", the app id is="+appid+" key="+key);
		boolean flag = true ;
		boolean result = new IdempotentConfirmer(3) {
			@Override
			public boolean execute() {
				byte[] byteBuffer = null ;
				try {
					byteBuffer = AbstractBaseSupportRedisCmdHandler.this.execute(channel, appid, key,redisMessage.getArgs());
					if (byteBuffer == null || byteBuffer.length == 0) {
						return false;
					}
					baos.write(byteBuffer, 0, byteBuffer.length);
					return true;
				} catch (Exception e) {
					Log.error("handler the redis cmd execute for the channel="+channel.toString()+" occuer the exception", e);
					return false ;
				}
			}
		}.run();
		flag = result;
		byte[] response = baos.toByteArray();
		super.handlerResponse(channel, flag,response, redisMessage);
		Log.debug("[ END ] handler the redistribution command="+redisMessage.getCmd()+", the app id is="+appid+" key="+key+",the handler result is="+result+" and response is="+SafeEncoder.encode(response));
	}

	public abstract byte[] execute(Channel channel, int appid, String key, List<byte[]> args) throws Exception;
}
