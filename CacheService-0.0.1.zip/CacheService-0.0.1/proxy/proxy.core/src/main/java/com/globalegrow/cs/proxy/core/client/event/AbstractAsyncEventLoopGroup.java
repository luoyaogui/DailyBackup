package com.globalegrow.cs.proxy.core.client.event;

import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.shared.common.utils.cmd.Result;
import com.globalegrow.cs.shared.event.loop.AsyncEventLoopGroup;
import com.globalegrow.cs.shared.event.task.queue.Executor;
import com.globalegrow.cs.shared.event.task.queue.Log;
import io.netty.channel.ChannelFuture;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;

/**
 * 
 * @author pengbingting
 *
 */
public abstract class AbstractAsyncEventLoopGroup extends AsyncEventLoopGroup<ChannelRedisMessage>{

	public AbstractAsyncEventLoopGroup(Executor executor, long loopInterval) {
		super(executor, loopInterval);
	}

	public AbstractAsyncEventLoopGroup(String executorName, long loopInterval) {
		super(executorName, loopInterval);
	}

	/**
	 * 
	 * @param result
	 * @return
	 */
	public Result<Object> handlerResult(Result<String> result,final ChannelRedisMessage redisClient){
		try {
			final byte[] response = getResponse(result, redisClient);
			ChannelFuture channelFuture = redisClient.getChannel().writeAndFlush(response);
			channelFuture.addListener(new GenericFutureListener<Future<? super Void>>() {
				public void operationComplete(Future<? super Void> future) throws Exception {
					//support asyn call back
					responseResult(future.isSuccess(),redisClient,response);
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			Log.error(this.getClass().getName()+" handler result is exception", e);
			return new Result<Object>(false);
		}
		
		return new Result<Object>(true);
	
	}
	
	public abstract boolean jedisProcess(ChannelRedisMessage channelRedisMessage,int cmdType);
	
	public abstract byte[] getResponse(Result<String> result, ChannelRedisMessage redisClient);
	
	/**
	 * 如果需要特殊的处理，则子类重载该方法
	 * @param successOrFail
	 * @param redisClient
	 * @param response
	 */
	public void responseResult(boolean successOrFail,ChannelRedisMessage redisClient,byte[] response){
		if(successOrFail){
			Log.debug("[BLOCK event LOOP GROUP]appid="+redisClient.getRedisMessage().getAppId()+" "+redisClient.getRedisMessage().getCmd()+" response success.");
		}else{
			Log.debug("[BLOCK event LOOP GROUP]appid="+redisClient.getRedisMessage().getAppId()+" "+redisClient.getRedisMessage().getCmd()+" response fail.");
			redisClient.getChannel().write(response);
		}
	}
}
