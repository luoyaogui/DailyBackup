package com.globalegrow.cs.proxy.core.client.event;

import java.util.concurrent.TimeUnit;

import com.globalegrow.cs.proxy.core.client.ChannelRedisMessage;
import com.globalegrow.cs.proxy.core.client.CheckStatus;
import com.globalegrow.cs.proxy.core.client.ClientHandlerFacade;
import com.globalegrow.cs.proxy.core.client.RedisClientFacade;
import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.handler.IRedisCmdHandler;
import com.globalegrow.cs.proxy.core.client.server.RedisMessage;
import com.globalegrow.cs.proxy.core.client.server.WriterFutureListener;
import com.globalegrow.cs.proxy.core.monitor.GlobalManager;
import com.globalegrow.cs.shared.common.exception.InitRedisServerBootstrapException;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineAbstractEventObject;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Protocol;
/*
 * 代理客户端统一处理。包括命令的统一转发和代理额外的自处理
 */
public class RedisProxyClientInspector extends PipelineAbstractEventObject<ChannelRedisMessage> {
	public final static int REDIS_PROXY_CLIENT_CHECK = 1 ;
	public final static int REDIS_PROXY_CLIENT_PROCESS = 2 ;
	@Override
	public void attachListener() {
		//1、客户端验证 handler
		this.addLast(new AppIdCheckHandler(this), REDIS_PROXY_CLIENT_CHECK);
		//2、命令处理 handler
		this.addLast(new FilterCmdSetHandler(), REDIS_PROXY_CLIENT_PROCESS);
		this.addLast(new KeySizeHandler(), REDIS_PROXY_CLIENT_PROCESS);
		this.addLast(new ValueSizeHandler(), REDIS_PROXY_CLIENT_PROCESS);
		this.addLast(new DirectlyCmdHandler(this), REDIS_PROXY_CLIENT_PROCESS);
		this.addLast(new DispatcherCmdHandler(this), REDIS_PROXY_CLIENT_PROCESS);
	}

	private void processRedisCmd(String redisCmd,RedisMessage redisMessage,Channel channel){
		IRedisCmdHandler redisCmdHandler = ClientHandlerFacade.getRedisCmdHandler(redisCmd);
		if(redisCmdHandler == null){
			channel.writeAndFlush(String.format(ResponseMessage.UNSUPPORT_CMD,redisCmd).getBytes());
			Log.warn(redisCmd+" refers to redis command handler is null.");
			return ;
		}
		
		redisCmdHandler.execute(channel, redisMessage);
	}
	
	/**
	 * 
	 * @author pengbingting
	 *
	 */
	public class AppIdCheckHandler implements PipelineObjectListener<ChannelRedisMessage>{
		@SuppressWarnings("unused")
		private RedisProxyClientInspector redisProxyCientCheck;
		
		public AppIdCheckHandler(RedisProxyClientInspector redisProxyCientCheck) {
			super();
			this.redisProxyCientCheck = redisProxyCientCheck;
		}

		@Override
		public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
			RedisMessage redisMessage = event.getValue().getRedisMessage();
			Channel channel = event.getValue().getChannel();
			int appId = redisMessage.getAppId();
			if(appId!=Constant.CACHE_CLOUD_APPID && appId <=0 || appId > Integer.MAX_VALUE){
				channel.writeAndFlush(ResponseMessage.APPI_ERROR.getBytes());
				RedisClientFacade.setAppCheckStatus(appId, Constant.APPID_CHECK_KEY,CheckStatus.checkInvalidate);
				return false;
			}
			//进入开始检测状态
			RedisClientFacade.setAppCheckStatus(appId,Constant.APPID_CHECK_KEY,CheckStatus.checkpass);
			RedisProxyClientInspector.this.publish(event.getValue(), REDIS_PROXY_CLIENT_PROCESS);
			return true;
		}
	}
	
	public class FilterCmdSetHandler implements PipelineObjectListener<ChannelRedisMessage>{

		@Override
		public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
			//返回false,后续handler 将不会执行
			return !GlobalManager.getInstance().isFilterCmd(event.getValue().getRedisMessage().getCmd());
		}
		
	}
	
	/**
	 * 对 key size 大小做进行过滤的操作
	 * @author pengbingting
	 */
	public class KeySizeHandler implements PipelineObjectListener<ChannelRedisMessage>{

		@Override
		public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
			int keyLimit = GlobalManager.getInstance().getParamConfig().getPgParameters().getKeyLimits();
			
			return event.getValue().getRedisMessage().getKey().getBytes().length < keyLimit;
		}
		
	}
	/**
	 * 对 value size 大小做进行过滤的操作
	 * @author pengbingting
	 */
	public class ValueSizeHandler implements PipelineObjectListener<ChannelRedisMessage>{

		@Override
		public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
			int valueLimit = GlobalManager.getInstance().getParamConfig().getPgParameters().getValueLimits();
			
			return event.getValue().getRedisMessage().getOriginalMessage().size() < valueLimit;
		}
	}
	
	/**
	 * 代理层直接处理的 command 
	 * @author pengbingting
	 */
	public class DirectlyCmdHandler implements PipelineObjectListener<ChannelRedisMessage>{
		private RedisProxyClientInspector clientCheck ;
		
		public DirectlyCmdHandler(RedisProxyClientInspector clientCheck) {
			super();
			this.clientCheck = clientCheck;
		}
		@Override
		public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
			RedisMessage redisMessage = event.getValue().getRedisMessage();
			Channel channel = event.getValue().getChannel();
			String cmd = redisMessage.getCmd();
			//额外命令的支持
			if(ClientHandlerFacade.isDirectlyRedisCmd(cmd)){
				clientCheck.processRedisCmd(cmd, redisMessage, channel);
				return false;
			}
			//让后续handler 处理
			return true;
		}
	}
	
	/**
	 * 直接dispatcher redis server handler
	 * @author pengbingting
	 */
	public class DispatcherCmdHandler implements PipelineObjectListener<ChannelRedisMessage>{
		@SuppressWarnings("unused")
		private RedisProxyClientInspector clientCheck ;
		public DispatcherCmdHandler(RedisProxyClientInspector clientCheck) {
			super();
			this.clientCheck = clientCheck;
		}

		@Override
		public boolean onEvent(ObjectEvent<ChannelRedisMessage> event, int listenerIndex) {
			RedisMessage redisMessage = event.getValue().getRedisMessage();
			Channel channel = event.getValue().getChannel();
			int appId = redisMessage.getAppId();
			//消息直发
			Jedis jedis = null;
			try {
				jedis = RedisClientFacade.getRedisServerJedis(appId,channel);
				byte[] response = null;
				response = jedis.writeAndGetResponse(redisMessage.getOriginalMessage().toByteArray());
				System.out.println("directly:"+new String(response));
				ChannelFuture channelFuture = channel.writeAndFlush(response);
				channelFuture.addListener(new WriterFutureListener(this.getClass().getName()+".execute,[appid="+redisMessage.getAppId()+"] cmd="+redisMessage.getCmd()+"; key="+redisMessage.getKey(), new String()));
				try {
					channelFuture.await(Protocol.DEFAULT_TIMEOUT, TimeUnit.SECONDS);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			} catch (InitRedisServerBootstrapException e2) {
				e2.printStackTrace();
			}
			return true;
		}
	}
}
