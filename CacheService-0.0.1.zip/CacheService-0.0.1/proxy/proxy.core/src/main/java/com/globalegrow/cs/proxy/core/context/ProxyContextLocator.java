package com.globalegrow.cs.proxy.core.context;

import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.globalegrow.cs.proxy.core.client.ClientHandlerFacade;
import com.globalegrow.cs.proxy.core.client.ClientTemplateFacade;
import com.globalegrow.cs.proxy.core.client.server.RedisProxyServer;
import com.globalegrow.cs.shared.common.utils.model.config.ConfigException;

/**
* Title: ProxyContextLocator
* Description: 上下文加载管理
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月10日 上午9:57:24
*/
public class ProxyContextLocator {

    private static ClassPathXmlApplicationContext context       = null;
    private static RuntimeException               initException = null;

    static {
        try {
            context = new ClassPathXmlApplicationContext("applicationContext.xml") {

                @Override
                protected void customizeBeanFactory(DefaultListableBeanFactory beanFactory) {
                    super.customizeBeanFactory(beanFactory);
                    beanFactory.setAllowBeanDefinitionOverriding(false);
                }
            };
            System.out.println(context);
        } catch (RuntimeException e) {
            throw new ConfigException("ERROR ## ", e);
        }
    }

    private static ApplicationContext getApplicationContext() {
        if (context == null) {
            throw initException;
        }

        return context;
    }

    public static void close() {
        ((ClassPathXmlApplicationContext) context).close();
    }

    public static ProxyController getProxyController() {
        return (ProxyController) getApplicationContext().getBean("proxyController");
    }

    public static RedisProxyServer getRedisProxyServer(){
    	return (RedisProxyServer) getApplicationContext().getBean("redisProxyServer");
    }
    
    public static ClientHandlerFacade getClientHandlerFacade(){
    	
    	return (ClientHandlerFacade) getApplicationContext().getBean("clientHandlerFacade");
    }
    
    public static ClientTemplateFacade getClientTemplateFacade(){
    	
    	return (ClientTemplateFacade) getApplicationContext().getBean("clientTemplateFacade");
    }
    
    public static <T> T getBean(String name) {
        return (T) getApplicationContext().getBean(name);
    }

    /**
     * 根据当前spring容器的bean定义，解析对应的object并完成注入
     */
    public static void autowire(Object obj) {
        // 重新注入一下对象
        context.getAutowireCapableBeanFactory().autowireBeanProperties(obj,
                                                                       AutowireCapableBeanFactory.AUTOWIRE_BY_NAME,
                                                                       false);
    }

}
