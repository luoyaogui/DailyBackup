package com.globalegrow.cs.proxy.core.client.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.globalegrow.cs.proxy.core.client.RedisClientFacade;
import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.server.chain.RedisCmdExecuteChain;
import com.globalegrow.cs.proxy.core.client.server.chain.ClusterExecuteChain;
import com.globalegrow.cs.proxy.core.client.server.chain.DefaultExecuteChain;
import com.globalegrow.cs.proxy.core.client.server.chain.IExecuteChain;
import com.globalegrow.cs.proxy.core.client.server.chain.SentineExecuteChain;
import com.globalegrow.cs.proxy.core.client.server.chain.SubscribeExecuteChain;
import com.globalegrow.cs.proxy.core.monitor.GlobalManager;
import com.globalegrow.cs.shared.config.base.Constant;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.util.Attribute;
import io.netty.util.AttributeKey;
import redis.clients.jedis.Jedis;
/**
 * 
 * @author pengbingting
 *
 */
public class RedisMessageHanndler extends SimpleChannelInboundHandler<RedisMessage> {
	//一组执行链。如果其中一个执行链返回false,则后续的将不会执行
	private List<IExecuteChain> executeChains = new ArrayList<>();
	public RedisMessageHanndler() {
		this.executeChains.add(new SentineExecuteChain(1));
		this.executeChains.add(new ClusterExecuteChain(2));
		this.executeChains.add(new SubscribeExecuteChain(3));
		this.executeChains.add(new RedisCmdExecuteChain(4));
		this.executeChains.add(new DefaultExecuteChain(5));
		Collections.sort(executeChains, new Comparator<IExecuteChain>() {
			@Override
			public int compare(IExecuteChain filter1, IExecuteChain filter2) {
				return filter1.getOrder()-filter2.getOrder();
			}
		});
		
		Log.info("initialize redistribution message handler finish.there are "+executeChains.size()+" execute chain.");
	}
	
	public static final AttributeKey<Integer> appIdAttryKey = AttributeKey.valueOf(Constant.PROXY_CLIENT_APPID_KEY);
	public static final AttributeKey<Long> clusterTemEpoolKey = AttributeKey.valueOf(Constant.CLUSTER_SLOT_TEMPLATE_EPOLL);
	public static final AttributeKey<Jedis> channelInTransaction = AttributeKey.valueOf(Constant.JEDIS_INTRANSACTION);
	/**
	 * 标识客户端三种连接方式的类型
	 */
	public static final AttributeKey<String> channelConnectType = AttributeKey.valueOf(Constant.PROXY_CLIENT_CONNECT_TYPE);
	@Override
	protected void channelRead0(ChannelHandlerContext ctx, RedisMessage redisMessage) throws Exception {
		Channel channel = ctx.channel();
		String cmd = redisMessage.getCmd();
		Log.info(channel.toString()+" handler cmd:"+cmd+" of appid=["+ redisMessage.getAppId() +"]");
		for(IExecuteChain chain:executeChains){
			//返回false,则后续的将不会执行
			Log.debug("[ BEGIN ]"+chain.getClass().getName()+" execute. process the command of="+redisMessage.getCmd());
			boolean isFuse = chain.executeChain(redisMessage, channel);
			Log.debug("[ END ]"+this.getClass().getName()+" execute. return [ "+isFuse+" ]");
			if(!isFuse){
				break;
			}
		}
	}

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		Log.info(ctx.channel().toString()+" builder connect!");
		super.channelActive(ctx);
	}
	
	/**
	 * 客户端channel disconnect,then do something:
	 */
	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		Log.warn(ctx.channel().toString()+" is inactive");
		Attribute<Integer> attribute = ctx.channel().attr(appIdAttryKey);
		if(attribute != null){
			//1.1、关闭和这个channel 绑定的Jedis
			int appId = attribute.get();
			Log.info("begin desctory proxy client of appid=["+appId+"] when the channel of"+ctx.channel().toString()+" is inactive.");
			RedisClientFacade.closeJedis(ctx.channel(),appId);
			//1.2、
			GlobalManager.getInstance().appOffline(String.valueOf(appId));
		}
		//2、
		RedisClientFacade.removeSubscribeChannel(ctx.channel());
		//3、
		RedisMessageHanndler.closeOnFlush(ctx.channel());
		super.channelInactive(ctx);
	}
	
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		StackTraceElement[] test = cause.getStackTrace();
		Log.error("redis proxy caught exception:"+cause.toString());
		for(StackTraceElement s : test){
			Log.error("redis proxy caught exception "+ s.toString());
		}
		if(cause instanceof Exception && cause instanceof IOException){
			Log.warn("redis proxy caught exception:"+cause.toString()+" is IOException ,then close the channel:"+ctx.channel().toString());;
			ctx.close();//如果是在这个channel 读/写数据的过程中发生异常，则关闭 channel.
		}else{//将这个异常会写客户端
			ctx.channel().write(String.format(ResponseMessage.ERROR_REPLY, cause.getMessage()).getBytes());
		}
	}
	
	/**
     * Closes the specified channel after all queued write requests are flushed.
     */
    public static void closeOnFlush(Channel ch) {
        if (ch.isActive()) {
            ch.writeAndFlush(Unpooled.EMPTY_BUFFER).addListener(ChannelFutureListener.CLOSE);
        }
    }
}
