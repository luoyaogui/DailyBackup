package com.globalegrow.cs.proxy.core.monitor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.globalegrow.cs.shared.common.utils.StringUtil;
import com.globalegrow.cs.shared.common.utils.TimeUtil;
import com.globalegrow.cs.shared.common.utils.lifecycle.LifeCycle;
import com.globalegrow.cs.shared.config.zk.base.ProxyNodeParameter;

/**
* Title: GlobalManager
* Description: 全局服务类，记录客户端登陆、基础服务运行状态监控、共享配置信息等操作
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月18日 上午8:48:48
*/
public class GlobalManager {
	private GlobalManager (){}
	/**
	 * 存储重要服务，以便可实时查询运行状态
	 * 由于这些服务在创建的时候加入进来了，所以无关线程安全
	 */
	private List<LifeCycle> services = new LinkedList<LifeCycle>();
	/**
	 * 记录客户端app登陆情况，方便统计客户端连接
	 * appID为key，登陆时间（格式为）为value。
	 */
	private Map<String,String> clients = new ConcurrentHashMap<String,String>();
	/**
	 * 存储代理节点的获取的参数（1，方便服务查询     2，方便后端回查确定配置是否更新）
	 * 默认为无数据的实例
	 */
	private ProxyNodeParameter paramConfig = new ProxyNodeParameter();
	/**
	 * 代理的唯一标识
	 */
	private long proxyUuid = 0;
	
	//过滤命令注册表
	private HashMap<String, Boolean> filterCmdSetRegister = new HashMap<>();
	//单例模式
	private static class SingletonHolder {  
		private static final GlobalManager INSTANCE = new GlobalManager();
	}
	public static final GlobalManager getInstance() {
		return SingletonHolder.INSTANCE;
	} 
	
	/**
	 * 添加服务进行监控
	 * @param service  被监控的服务
	 */
	public void addService(LifeCycle service){
		services.add(service);
	}
	/**
	 * 应用上线
	 * @param appID 应用标识
	 */
	public void appOnline(String appID){
		clients.put(appID, TimeUtil.getCurrentTime());
	}
	/**
	 * 应用下线
	 * @param appID 应用标识
	 */
	public void appOffline(String appID){
		clients.remove(appID);
	}
	/**
	 * 获取参数配置
	 */
	public ProxyNodeParameter getParamConfig() {
		return paramConfig;
	}
	/**
	 * 设置参数配置，初始化时使用，其他地方不应该使用该方法
	 */
	public void setParamConfig(ProxyNodeParameter paramConfig) {
		this.paramConfig = paramConfig;
		if(StringUtil.empty(paramConfig.getPgParameters().getFiltersRedisCommand()))
			return;
		List<String> filterCmdSet = Arrays.asList(paramConfig.getPgParameters().getFiltersRedisCommand().split("[,]"));
		for(String cmd:filterCmdSet){
			filterCmdSetRegister.put(cmd, true);
		}
	}
	/**
	 * 获取代理的唯一标识
	 */
	public long getProxyUuid() {
		return proxyUuid;
	}
	/**
	 * 设置代理的唯一标识，初始化时使用，其他地方不应该使用该方法
	 */
	public void setProxyUuid(long proxyUuid) {
		this.proxyUuid = proxyUuid;
	}
	
	public boolean isFilterCmd(String srcCmd){
		
		Boolean bool = this.filterCmdSetRegister.get(srcCmd);
		
		return bool != null;
	}
}
