package com.globalegrow.cs.proxy.core.client.handler.sentinel;

import java.util.List;

import com.globalegrow.cs.proxy.core.client.ClientTemplateFacade;
import com.globalegrow.cs.proxy.core.client.ResponseMessage;
import com.globalegrow.cs.proxy.core.client.anotation.RedisCmd;
import com.globalegrow.cs.proxy.core.client.handler.AbstractBaseSupportRedisCmdHandler;
import com.globalegrow.cs.shared.config.base.RedisProtocol;

import io.netty.channel.Channel;

/**
 * if client connect by sentinel,then must send the command of that "get-master-addr-by-name".
 * because this command to find the master ip and port.so we know this client the type of connect
 * if sentinel.
 * @author pengbingting
 *
 */
@RedisCmd(cmd=RedisProtocol.SENTINEL,desc="")
public class SentinelCmdHandler extends AbstractBaseSupportRedisCmdHandler{

	@Override
	public byte[] execute(Channel channel, int appid, String key, List<byte[]> args) throws Exception {
		if(RedisProtocol.SENTINEL_GET_MASTER_ADDR_BY_NAME.equals(key)){
			System.out.println(new String(ClientTemplateFacade.sentinelGetMasterAddrTemplate));
			return ClientTemplateFacade.sentinelGetMasterAddrTemplate;
		}
		
		return String.format(ResponseMessage.UNSUPPORT_CMD, key).getBytes();
	}

}
