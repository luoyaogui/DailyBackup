package com.globalegrow.cs.proxy.core.client.server;

import java.net.InetSocketAddress;

import com.globalegrow.cs.proxy.core.client.RedisProxyClusterFacade;
import com.globalegrow.cs.proxy.core.lifecycle.AbstractLifeCycle;
import com.globalegrow.cs.proxy.core.monitor.GlobalManager;
import com.globalegrow.cs.shared.config.base.HostAndPort;
import com.globalegrow.cs.shared.event.task.queue.Log;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LoggingHandler;

/**
 * 启动redis proxy server 的入口。主要就是使用netty 监听指定的端口。
 * @author pengbingting
 *
 */
public class RedisProxyServer extends AbstractLifeCycle{
	private String ip;
	private int port ;
	
	public RedisProxyServer() {
	}
	private final NioEventLoopGroup boss = new NioEventLoopGroup();
	private final NioEventLoopGroup worker = new NioEventLoopGroup();
	@Override
	public void start() {
		port = GlobalManager.getInstance().getParamConfig().getPort();
		if(GlobalManager.getInstance().getParamConfig().isCloseOuterIP()){
			ip = GlobalManager.getInstance().getParamConfig().getIp();
		} else {
			ip = GlobalManager.getInstance().getParamConfig().getOuterIp();
		}
		new Thread(new Runnable() {
			@Override
			public void run() {
				//1、set the nio event loop group
				ServerBootstrap serverBootstrap = new ServerBootstrap();
				serverBootstrap.group(boss, worker);
				//2、the some configuration for tcp
				serverBootstrap.channel(NioServerSocketChannel.class);
				serverBootstrap.option(ChannelOption.SO_BACKLOG, 1024);
				serverBootstrap.option(ChannelOption.TCP_NODELAY, true);
				//3、set master handler for server channel handler
				serverBootstrap.handler(new LoggingHandler());
				serverBootstrap.childHandler(new RedisChannelInitializer());
				//4、bind the ip address by user pointed
				ChannelFuture channelFuture = serverBootstrap.bind(new InetSocketAddress(ip,port));
				Log.info("listener on :"+getIpPort());
				try {
					Channel channel = channelFuture.sync().channel();
					channel.closeFuture().sync();
				} catch (InterruptedException e) {
					Log.error("proxy server listener fail.",e);
				}finally{
					boss.shutdownGracefully();
					worker.shutdownGracefully();
				}
			}
		}).start();
	}
	
	public void shutdown() {
		super.stop();
		Log.info("##Proxy Server is stop!");
		RedisProxyClusterFacade.removeProxyServer(new HostAndPort(ip, port));
	}
	
	public String getIpPort(){
		return this.ip+":"+this.port;
	}
	public String getIp() {
		return ip;
	}
	public int getPort() {
		return port;
	}
}
