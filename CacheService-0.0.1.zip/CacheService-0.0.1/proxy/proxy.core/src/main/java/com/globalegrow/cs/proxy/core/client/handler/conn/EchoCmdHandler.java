package com.globalegrow.cs.proxy.core.client.handler.conn;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.globalegrow.cs.proxy.core.client.anotation.RedisCmd;
import com.globalegrow.cs.proxy.core.client.handler.AbstractBaseSupportRedisCmdHandler;
import com.globalegrow.cs.shared.config.base.RedisProtocol;

import io.netty.channel.Channel;

@RedisCmd(cmd=RedisProtocol.ECHO,desc="")
public class EchoCmdHandler extends AbstractBaseSupportRedisCmdHandler{

	@Override
	public byte[] execute(Channel channel, int appid, String message, List<byte[]> args) throws Exception {
		message = StringUtils.isEmpty(message) ? "[globalegrow] REDIS PROXY" : message;
		
		return message.getBytes();
	}

}
