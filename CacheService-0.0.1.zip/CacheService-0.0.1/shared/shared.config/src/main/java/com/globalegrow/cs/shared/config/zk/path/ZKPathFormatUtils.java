package com.globalegrow.cs.shared.config.zk.path;

import java.text.MessageFormat;


/**
* Title: ZKPathFormatUtils
* Description:  zookeeper路径帮助类
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月13日 上午11:45:33
*/
public class ZKPathFormatUtils implements ZKPathInterf {
	private ZKPathFormatUtils(){}
	
	/**
    *返回对应的CacheServer root path
    */
    public static String getRoot() {
        return CS_ROOT;
    }

    /**
    *返回对应的proxy root path
    */
    public static String getProxyRoot() {
        return PROXY_ROOT;
    }

    /**
    *返回对应的statistic root path
    */
    public static String getStatisticRoot() {
        return STATISTIC_ROOT;
    }

    /**
    *返回对应的proxy-group root path
    */
    public static String getProxyGroupRoot() {
        return PROXY_GROUP_ROOT;
    }
    
    /**
    *返回对应的proxy-group path
    */
    public static String getProxyGroup(String groupName) {
        // 根据groupName 构造path
        return MessageFormat.format(PROXY_GROUP_FORMAT, groupName);
    }

    /**
    *返回对应的proxy-group    状态
    */
    public static String getProxyGroupStatus(String groupName) {
        // 根据groupName 构造path
        return MessageFormat.format(PROXY_GROUP_STATUS, groupName);
    }
    
    /**
    *返回对应的proxy-group    节点的根路径
    */
    public static String getProxyGroupNodeRoot(String groupName) {
    		// 根据groupName 构造path
    		return MessageFormat.format(PROXY_GROUP_NODE_ROOT, groupName);
    }

    /**
    *返回对应的proxy-group    节点的根路径   具体的代理节点
    */
    public static String getProxyGroupNode(String groupName, Long proxyUuid) {
        // 根据channelId , pipelineId 构造path
        return MessageFormat.format(PROXY_GROUP_NODE_FORMAT,
        		groupName,
            String.valueOf(proxyUuid));
    }

    /**
     * 返回对应的proxy-group    app的根路径
     */
    public static String getProxyGroupAppRoot(String groupName) {
    		// 根据groupName 构造path
    		return MessageFormat.format(PROXY_GROUP_APP_ROOT, groupName);
    }
    /**
    *返回对应的proxy-group    app的根路径   具体的app信息
    */
    public static String getProxyGroupApp(String groupName, String appId, String appKey) {
        // 根据channelId , pipelineId 构造path
        return MessageFormat.format(PROXY_GROUP_APP_FORMAT,
        		groupName,
            appId,
            appKey);
    }
}
