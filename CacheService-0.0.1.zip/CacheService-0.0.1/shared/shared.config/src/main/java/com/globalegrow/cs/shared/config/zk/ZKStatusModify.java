package com.globalegrow.cs.shared.config.zk;

import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.curator.framework.CuratorFramework;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.globalegrow.cs.shared.common.utils.ByteUtils;
import com.globalegrow.cs.shared.config.base.AppInstanceInfo;
import com.globalegrow.cs.shared.config.base.HostAndPort;
import com.globalegrow.cs.shared.config.zk.path.ZKPathFormatUtils;
import com.globalegrow.cs.shared.config.zk.path.ZKPathOperator;

/**
 * Title: ZKStatusModifyService
 * Description: 提供状态变更实现，该服务类面向应用（包括上下线变更、查询、更改参数数据）
 * Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
 * @author yaoguiluo
 * @date 2017年5月13日 下午6:11:51
 */
public abstract class ZKStatusModify {
	private static final Logger logger = LoggerFactory.getLogger(ZKStatusModify.class);

	/**
	 * 代理组上线
	 * @param client  连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName  代理组组名
	 * @return  上线成功返回true，否则返回false
	 */
	public static boolean proxyGroupOnline(CuratorFramework client, String proxyGroupName) {
		String path = ZKPathFormatUtils.getProxyGroupStatus(proxyGroupName);
		try {
			ZKPathOperator.createPersistent(client, path, ByteUtils.customType2JsonByte(Boolean.TRUE));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + " create failed : " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
		try {
			ZKPathOperator.setData(client, path, ByteUtils.customType2JsonByte(Boolean.TRUE));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + " online failed : " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
		return true;
	}

	/**
	 * 代理组下线
	 * @param client   连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @return  下线成功返回true，否则返回false
	 */
	public static boolean proxyGroupOffline(CuratorFramework client, String proxyGroupName) {
		try {
			ZKPathOperator.setData(client, ZKPathFormatUtils.getProxyGroupStatus(proxyGroupName), ByteUtils.customType2JsonByte(Boolean.FALSE));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + " offline failed : " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
		return true;
	}
	/**
	 * 判断代理组是否在线
	 * @param client   连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @return 代理组在线返回true，否则返回false
	 */
	public static boolean isOnlineAboutProxyGroup(CuratorFramework client, String proxyGroupName){
		try {
			byte[] data = ZKPathOperator.getData(client, ZKPathFormatUtils.getProxyGroupStatus(proxyGroupName), null);
			return ByteUtils.jsonByte2CustomType(data, Boolean.class);
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + " get status failed: " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
	}
	/**
	 * 获取代理组下在线的所有代理节点
	 * @param client		连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @return  当前在线的代理节点puuid列表
	 */
	public static List<String> getOnlineProxyNodeAboutProxyGroup(CuratorFramework client, String proxyGroupName){
		try {
			return ZKPathOperator.getAllChildren(client, ZKPathFormatUtils.getProxyGroupNodeRoot(proxyGroupName));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + " get all proxy-node childrens failed: " + ExceptionUtils.getFullStackTrace(e));
			return Collections.emptyList();
		}
	}
	/**
	 * 获取代理组下在线的所有app
	 * @param client		连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @return 当前在线的app（appid:appkey）列表
	 */
	public static List<String> getOnlineAppAboutProxyGroup(CuratorFramework client, String proxyGroupName){
		try {
			return ZKPathOperator.getAllChildren(client, ZKPathFormatUtils.getProxyGroupAppRoot(proxyGroupName));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + " get all app-childrens failed: " + ExceptionUtils.getFullStackTrace(e));
			return Collections.emptyList();
		}
	}
	
	/**
	 * 代理节点上线
	 * @param client		连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @param proxyUuid  代理节点uuid
	 * @return 上线成功返回true，否则返回false
	 */
	public static boolean proxyNodeOnline(CuratorFramework client, String proxyGroupName, long proxyUuid, HostAndPort data) {
		try {
			ZKPathOperator.createEphemeral(client, ZKPathFormatUtils.getProxyGroupNode(proxyGroupName, proxyUuid), ByteUtils.customType2JsonByte(data));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + ",proxyUuid:" + proxyUuid + " online failed: " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
		return true;
	}
	/**
	 * 代理节点是否在线
	 * @param client 	连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @param proxyUuid  代理节点uuid
	 * @return  代理节点在线返回true，否则返回false
	 */
	public static boolean isOnlineAboutProxyNode(CuratorFramework client, String proxyGroupName, long proxyUuid) {
		try {
			return ZKPathOperator.isExist(client, ZKPathFormatUtils.getProxyGroupNode(proxyGroupName, proxyUuid));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + ",proxyUuid:" + proxyUuid + " get status failed: " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
	}
	/**
	 * app上线
	 * @param client 	连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @param appId  app唯一标识
	 * @param appKey  app密钥
	 * @param dataInfo 参数信息
	 * @return app上线成功返回true，否则返回false
	 */
	public static boolean appOnline(CuratorFramework client, String proxyGroupName, String appId, String appKey, AppInstanceInfo dataInfo) {
		try {
			ZKPathOperator.createPersistent(client, ZKPathFormatUtils.getProxyGroupApp(proxyGroupName, appId, appKey), ByteUtils.customType2JsonByte(dataInfo));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + ",appId:"+ appId + ",appKey:" + appKey + " online failed: " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
		return true;
	}
	/**
	 * app下线
	 * @param client 	连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @param appId  app唯一标识
	 * @param appKey  app密钥
	 * @param dataInfo 参数信息
	 * @return app下线成功返回true，否则返回false
	 */
	public static boolean appOffline(CuratorFramework client, String proxyGroupName, String appId, String appKey) {
		try {
			ZKPathOperator.delete(client, ZKPathFormatUtils.getProxyGroupApp(proxyGroupName, appId, appKey));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + ",appId:"+ appId + ",appKey:" + appKey + " offline failed: " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
		return true;
	}
	/**
	 * app是否在线
	 * @param client 	连接zk的客户端（已经初始化，执行start的）
	 * @param proxyGroupName		代理组组名
	 * @param appId  app唯一标识
	 * @param appKey  app密钥
	 * @return 在线返回true，否则返回flase
	 */
	public static boolean isOnlineAboutApp(CuratorFramework client, String proxyGroupName, String appId, String appKey) {
		try {
			return ZKPathOperator.isExist(client, ZKPathFormatUtils.getProxyGroupApp(proxyGroupName, appId, appKey));
		} catch (Exception e) {
			logger.error("proxy-group:" + proxyGroupName + ",appId:"+ appId + ",appKey:" + appKey + " get status failed: " + ExceptionUtils.getFullStackTrace(e));
			return false;
		}
	}
}
