package com.globalegrow.cs.shared.config.zk.base;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.globalegrow.cs.shared.common.utils.CSToStringStyle;


/**
* Title: ZKGroup
* Description: 代理组信息
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月15日 上午10:33:16
*/
public class ZKGroup implements Serializable {

    private static final long serialVersionUID = 1L;
	private String            name;// 唯一标示
	private String            addresses;// 地址列表，10.2.2.1:9009;12.3.4.4:384……
    private String            description;                              // 描述信息
    private Date              gmtCreate;//创建时间
    private Date              gmtModified;//最后一次更新时间

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

	public String getAddresses() {
		return addresses;
	}

	public void setAddresses(String addresses) {
		this.addresses = addresses;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, CSToStringStyle.DEFAULT_STYLE);
    }

}
