package com.globalegrow.cs.shared.config.zk.base;


/**
* Title: ProxyGroupSupportModel
* Description:  代理组支持的模式
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月15日 上午10:08:16
*/
public enum ProxyGroupSupportModel {
    /** 所有模式-----默认 */
    ALL(0),
    /** 单机 */
    STANDALONE(1),
    /** 哨兵模式 */
    SENTINEL(2),
    /** 集群模式 */
    CLUSTER(3);
	private int value;
	private ProxyGroupSupportModel(int value){
		this.value = value;
	}
	public int getValue(){
		return this.value;
	}
	public static ProxyGroupSupportModel getDefault(){
		return ProxyGroupSupportModel.ALL;
	}
	public static  ProxyGroupSupportModel from(int value){
		switch(value){
		case 1:
			return ProxyGroupSupportModel.STANDALONE;
		case 2:
			return ProxyGroupSupportModel.SENTINEL;
		case 3:
			return ProxyGroupSupportModel.CLUSTER;
		default:
			return ProxyGroupSupportModel.ALL;
		}
	}
}
