package com.globalegrow.cs.shared.config.zk.path;

import java.util.List;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.api.CuratorWatcher;
import org.apache.zookeeper.CreateMode;

/**
* Title: ZKPathOperator
* Description: zookeeper路径操作实现类
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月13日 上午11:47:30
*/
public class ZKPathOperator {
	
	private ZKPathOperator() {
	}
	
	public static boolean isExist(CuratorFramework client, String path) throws Exception{
		return client.checkExists().forPath(path) != null ? true : false;
	}
	/**
	 * 创建持久路径（路径=数据，相当于key=value）
	 * @param path   路径
	 * @param value   值
	 * @throws Exception  创建异常
	 */
	public static void createPersistent(CuratorFramework client, String path,byte[] value) throws Exception{
		if(client.checkExists().forPath(path) != null)
			return;
		client.create()//创建一个路径
			.creatingParentsIfNeeded()//如果指定的节点的父节点不存在，递归创建父节点
			.withMode(CreateMode.PERSISTENT)//存储类型（临时的还是持久的）
			.forPath(path,value);//创建的路径
	}
	/**
	 * 删除路径
	 * @param path  路径
	 * @throws Exception  删除异常
	 */
	public static void delete(CuratorFramework client, String path) throws Exception{
		client.delete().deletingChildrenIfNeeded().forPath(path);
	}
	/**
	 * 创建临时路径（路径=数据，相当于key=value）
	 * @param path   路径
	 * @param value  值
	 * @throws Exception  创建异常
	 */
	public static void createEphemeral(CuratorFramework client, String path,byte[] value) throws Exception{
		if(client.checkExists().forPath(path) != null)
			return;
		client.create()//创建一个路径
			.creatingParentsIfNeeded()//如果指定的节点的父节点不存在，递归创建父节点
			.withMode(CreateMode.EPHEMERAL)//存储类型（临时的还是持久的）
			.forPath(path,value);//创建的路径
	}
	/**
	 * 更新路径的数据（路径=数据，相当于key=value）
	 * @param path  路径
	 * @param value  新的值
	 * @throws Exception  更新异常
	 */
	public static void setData(CuratorFramework client, String path,byte[] value) throws Exception{
		client.setData().forPath(path,value);
	}
	/**
	 * 获取路径的数据（路径=数据，相当于key=value）
	 * @param path  路径
	 * @param watcher  监听器实现类，可选
	 * @return 当前路径的值
	 * @throws Exception 读取异常
	 */
	public static byte[] getData(CuratorFramework client, String path,CuratorWatcher watcher) throws Exception{
		byte[] value = null;
		if(watcher != null){
			value = client.getData().usingWatcher(watcher).forPath(path);
		}else {
			value = client.getData().forPath(path);
		}
		return value;
	}
	/**
	 * 获取子节点列表
	 * @param path 路径
	 * @return  所有子节点
	 * @throws Exception 读取异常
	 */
	public static List<String> getAllChildren(CuratorFramework client, String path) throws Exception{
		return client.getChildren().forPath(path);
	}
}
