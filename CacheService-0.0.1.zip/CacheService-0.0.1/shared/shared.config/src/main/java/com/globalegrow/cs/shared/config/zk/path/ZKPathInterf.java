package com.globalegrow.cs.shared.config.zk.path;

/**
 * zk相关常量定义
 */
public interface ZKPathInterf {
	
	//Appid appkey的分隔符
	public String  APPID_APPKEY_SEPARATOR = ":";

    //CacheService根节点
    public String CS_ROOT         = "/cacheservice";

    //CacheService分支--代理节点
    public String PROXY_ROOT           = CS_ROOT + "/proxy";
    
    //CacheService分支--统计节点
    public String STATISTIC_ROOT           = CS_ROOT + "/statistic";

  //代理的分支-组节点
    public String PROXY_GROUP_ROOT         = PROXY_ROOT + "/group";
    
    //代理的分支-组的format格式,接受组名做为参数
    public String PROXY_GROUP_FORMAT         = PROXY_GROUP_ROOT + "/{0}";
    
    //代理组的分支-节点列表（用于记录有哪些代理服务节点属于这个组），接受组名作为参数，值为true／false
    public String PROXY_GROUP_STATUS       = PROXY_GROUP_FORMAT + "/online";
    
    //代理组的分支-节点列表（用于记录有哪些代理服务节点属于这个组），接受组名作为参数
    public String PROXY_GROUP_NODE_ROOT       = PROXY_GROUP_FORMAT + "/nodes";
    
    //代理组的分支-节点信息（用于保存代理服务节点的信息），接受组名、代理的uuid作为参数
    public String PROXY_GROUP_NODE_FORMAT       = PROXY_GROUP_NODE_ROOT + "/{1}";

    //代理组的分支-app（用于记录有哪些app属于这个组），接受组名作为参数
    public String PROXY_GROUP_APP_ROOT       = PROXY_GROUP_FORMAT + "/app";
    
    //代理组的分支-app（用于记录有哪些app属于这个组），接受组名、appid、appkey作为参数
    public String PROXY_GROUP_APP_FORMAT       = PROXY_GROUP_APP_ROOT + "/{1}" + APPID_APPKEY_SEPARATOR + "{2}";
}
