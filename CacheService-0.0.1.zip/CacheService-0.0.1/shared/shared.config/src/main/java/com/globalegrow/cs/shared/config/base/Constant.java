package com.globalegrow.cs.shared.config.base;

import java.util.Arrays;
import java.util.List;

public final class Constant {
	
	private Constant(){
	}
	public static final String 		LOCALHOST			= "localhost";  	//本机域名
	public static final String 		LOCAL_IP 			= "127.0.0.1";	//本地ip
	public static final int 			DEFAULT_PORT 		= 0;//默认端口
	
	public static final String INTEGER_REG = "^\\d+$"; 
	public static final String APPID_CMD_SPLIT = ":" ;
	//用来表示没跟netty channel 是属于哪个 app id 的key
	public final static String PROXY_CLIENT_APPID_KEY = "proxyClientAppIdKey" ;
	
	public final static String CLUSTER_SLOT_TEMPLATE_EPOLL = "clusterSlotTemplateEpoll" ;
	
	public final static String JEDIS_INTRANSACTION = "jedisInTransaction" ;
	
	//客户端连接的类型
	public final static String PROXY_CLIENT_CONNECT_TYPE = "proxyClientConnecttype" ;
	
	//集群模式下服务发现的cluster slots/nodes
	public final static List<String> CLUSTER_DISCOVER_KEY = 
			Arrays.asList(RedisProtocol.CLUSTER_SLOTS,RedisProtocol.CLUSTER_NODES);
	
	//对 app id 进行检测时的状态存储 key
	public final static int APPID_CHECK_KEY = 1 ;
	
	//对cache cloud 每个 app id 生成的 app key 进行检测
	public final static int APP_SECRET_KEY = 2 ;
	
	//cache cloud 和redis proxy 进行自由交互的 app id
	public final static int CACHE_CLOUD_APPID = -135;
	
	//预初始化集群模板多少个
	public final static int INIT_CLUSTER_TEMPLATE_SIZE = 5 ;
	
	//subscribe constant
	public final static String SENTINEL_SWITCH_TOPIC = "+switch-master";
	
	//-----------------------zookeeper------------
	public static final int TRY_NUM_AFTER_ZK_CONNECT_FAILED = 5;//创建临时节点失败后重试次数
	public static final int ZK_CONNECT_RETRY_INTERNAL = 3000;//zk连接断开后自动重连时间间隔
	//编码格式
	//public static final String  ENCODE = "utf-8";
	
	public static final String FILTER_COMMAND_SEPARATOR = ";";//过滤命令列表分隔符
	
	/**
	 * 代理节点启动时获取配置信息的http路径，接受ip、端口、校验码、puuid作为参数
	 */
	public static final String PROXY_NODE_HTTP_PATH = "http://{0}:{1}/cache/client/redis/proxy/{2}/{3}.json";
}
