package com.globalegrow.cs.shared.config.base;

import java.util.List;

/**
* Title: AppInstanceInfo
* Description: app实例相关的信息
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月9日 下午5:18:07
*/
public class AppInstanceInfo {
	private boolean offline;//是否离线
	private String masterName;//后端redis的sentinel的master名称
	private List<HostAndPort> sentinel;//后端redis的sentinel地址列表
	
	public boolean isOffline() {
		return offline;
	}
	public void setOffline(boolean offline) {
		this.offline = offline;
	}
	public String getMasterName() {
		return masterName;
	}
	public void setMasterName(String masterName) {
		this.masterName = masterName;
	}
	public List<HostAndPort> getSentinel() {
		return sentinel;
	}
	public void setSentinel(List<HostAndPort> sentinel) {
		this.sentinel = sentinel;
	}
	@Override
	public String toString() {
		return "AppInstanceInfo [offline=" + offline + ", masterName=" + masterName + ", sentinel=" + sentinel + "]";
	}
}
