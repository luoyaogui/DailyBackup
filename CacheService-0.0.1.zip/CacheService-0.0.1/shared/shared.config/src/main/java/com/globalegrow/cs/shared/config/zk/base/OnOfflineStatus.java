package com.globalegrow.cs.shared.config.zk.base;


/**
* Title: OnOfflineStatus
* Description:  上下线状态
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月15日 上午10:08:16
*/
public enum OnOfflineStatus {
    /** 已上线 */
    ONLINE,
    /** 已下线 */
    OFFLINE;

    public boolean isOnline() {
        return this.equals(OnOfflineStatus.ONLINE);
    }

    public boolean isOffline() {
        return this.equals(OnOfflineStatus.OFFLINE);
    }
}
