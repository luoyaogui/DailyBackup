package com.globalegrow.cs.shared.config.zk.base;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.globalegrow.cs.shared.common.utils.CSToStringStyle;


/**
* Title: ProxyNodeParameter
* Description: 代理节点相关参数
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月15日 上午10:31:39
*/
public class ProxyNodeParameter implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String ip;//ip地址
	private int port;//端口
	private boolean closeOuterIP;//是否关闭外网ip
	private String outerIp;//外网ip
	private String belongProxyGroup;//所属代理组组名
	private ProxyGroupParameter  pgParameters       = new ProxyGroupParameter();//代理组参数
	private String belongZKGroup;//所属ZK组
	private String zkAddresses;//zk地址列表

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public boolean isCloseOuterIP() {
		return closeOuterIP;
	}

	public void setCloseOuterIP(boolean closeOuterIP) {
		this.closeOuterIP = closeOuterIP;
	}

	public String getOuterIp() {
		return outerIp;
	}

	public void setOuterIp(String outerIp) {
		this.outerIp = outerIp;
	}

	public String getBelongProxyGroup() {
		return belongProxyGroup;
	}

	public void setBelongProxyGroup(String belongProxyGroup) {
		this.belongProxyGroup = belongProxyGroup;
	}

	public ProxyGroupParameter getPgParameters() {
		return pgParameters;
	}

	public void setPgParameters(ProxyGroupParameter pgParameters) {
		this.pgParameters = pgParameters;
	}

	public String getBelongZKGroup() {
		return belongZKGroup;
	}

	public void setBelongZKGroup(String belongZKGroup) {
		this.belongZKGroup = belongZKGroup;
	}

	public String getZkAddresses() {
		return zkAddresses;
	}

	public void setZkAddresses(String zkAddresses) {
		this.zkAddresses = zkAddresses;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, CSToStringStyle.DEFAULT_STYLE);
    }

}
