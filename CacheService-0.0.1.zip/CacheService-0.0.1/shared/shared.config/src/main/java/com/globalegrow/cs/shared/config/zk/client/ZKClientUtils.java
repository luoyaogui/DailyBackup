package com.globalegrow.cs.shared.config.zk.client;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;

import com.globalegrow.cs.shared.config.base.Constant;

/**
* Title: ZKClientUtils
* Description: 单例模式获取客户端
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月13日 下午6:11:18
*/
public class ZKClientUtils {
	private static CuratorFramework instance = null;
	
	public static CuratorFramework getInstance(String zkServer){
		if(null == instance){
            synchronized(ZKClientUtils.class){
                if(null == instance){
                    instance = CuratorFrameworkFactory.builder().connectString(zkServer).retryPolicy(new ZKConnRetryForever(Constant.ZK_CONNECT_RETRY_INTERNAL)).build();
                    instance.start();
                }
            }
        }
		return instance;
	}
}
