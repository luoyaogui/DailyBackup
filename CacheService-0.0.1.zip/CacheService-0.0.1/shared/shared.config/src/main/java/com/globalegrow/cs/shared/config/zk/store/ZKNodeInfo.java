package com.globalegrow.cs.shared.config.zk.store;

import java.util.Arrays;

/**
* Title: ZKNodeInfo
* Description: zookeeper节点信息
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月13日 上午11:49:12
*/
public class ZKNodeInfo {
    private byte[] data;
    
    ZKNodeInfo() {
    }

    public ZKNodeInfo(byte[] data) {
        this.data = data;
    }
    /**
     * 获取节点的数据
     * @return  节点数据
     */
    public synchronized byte[] getData(){
    		return this.data;
    }
    /**
     * 设置节点的塑胶
     * @param data  新的节点数据
     */
    public synchronized void setData(byte[] data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "ZKNodeInfo [data=" + new String(data) + "]";
	}
}
