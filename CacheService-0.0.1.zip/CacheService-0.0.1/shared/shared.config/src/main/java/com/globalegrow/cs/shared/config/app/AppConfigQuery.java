package com.globalegrow.cs.shared.config.app;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.globalegrow.cs.shared.config.base.AppInstanceInfo;
import com.globalegrow.cs.shared.config.zk.path.ZKPathFormatUtils;
import com.globalegrow.cs.shared.config.zk.store.ZKNodeTree;

/**
 * Title: AppConfigQuery
 * Description: 客户端查询入口，提供app相关的认证、查询
 * Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
 * @author yaoguiluo
 * @date 2017年5月9日 下午4:45:34
 */
public abstract class AppConfigQuery {
	private static final Logger logger = LoggerFactory.getLogger(AppConfigQuery.class);

	/**
	 * 查询sentinel信息
	 * @param appID  客户端appID
	 * @param appKey 客户端appKey
	 * @return  实例相关的信息，不会返回null
	 * @throws Exception 
	 */
	public static AppInstanceInfo belongCurrentProxyGroup(String appID, String appKey) throws Exception {
		String path = ZKPathFormatUtils.getProxyGroupApp(ZKNodeTree.getInstance().getGroup(), appID, appKey);
		try {
			return ZKNodeTree.getInstance().getData(path,AppInstanceInfo.class);
		} catch (Exception e) {
			logger.error("appID="+appID+",appKey="+appKey+" check failed: \n{}", ExceptionUtils.getFullStackTrace(e));
			throw new Exception("server check failed！"); 
		}
	}
}
