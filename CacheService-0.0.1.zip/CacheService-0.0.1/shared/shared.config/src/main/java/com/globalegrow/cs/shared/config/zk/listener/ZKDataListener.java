package com.globalegrow.cs.shared.config.zk.listener;

public interface ZKDataListener<T>{

	void dataChange(String data);
	
	void dataRemove(String data);
	
	void dataAdd(String data);
}
