package com.globalegrow.cs.shared.config.zk.base;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.globalegrow.cs.shared.common.utils.CSToStringStyle;


/**
* Title: ProxyGroupParameter
* Description: 代理组相关参数
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月15日 上午10:31:39
*/
public class ProxyGroupParameter implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private ProxyGroupSupportModel modelSupport = ProxyGroupSupportModel.getDefault();//支持的模式
	private String filtersRedisCommand;//过滤的命令列表
	private String exchangeCommandNames;//
	private String commandCustom;
	private int keyLimits;//key的大小限制
	private int valueLimits;//value的大小限制

    public int getKeyLimits() {
		return keyLimits;
	}

	public void setKeyLimits(int keyLimits) {
		this.keyLimits = keyLimits;
	}

	public int getValueLimits() {
		return valueLimits;
	}

	public void setValueLimits(int valueLimits) {
		this.valueLimits = valueLimits;
	}

	public ProxyGroupSupportModel getModelSupport() {
		return modelSupport;
	}

	public void setModelSupport(ProxyGroupSupportModel modelSupport) {
		this.modelSupport = modelSupport;
	}

	public String getFiltersRedisCommand() {
		return filtersRedisCommand;
	}

	public void setFiltersRedisCommand(String filtersRedisCommand) {
		this.filtersRedisCommand = filtersRedisCommand;
	}

	public String getExchangeCommandNames() {
		return exchangeCommandNames;
	}

	public void setExchangeCommandNames(String exchangeCommandNames) {
		this.exchangeCommandNames = exchangeCommandNames;
	}

	public String getCommandCustom() {
		return commandCustom;
	}

	public void setCommandCustom(String commandCustom) {
		this.commandCustom = commandCustom;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, CSToStringStyle.DEFAULT_STYLE);
    }

}
