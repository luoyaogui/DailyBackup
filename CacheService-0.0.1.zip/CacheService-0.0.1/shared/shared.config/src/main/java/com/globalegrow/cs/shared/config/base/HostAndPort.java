package com.globalegrow.cs.shared.config.base;

/**
* Title: HostAndPort
* Description: 存储ip和端口
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月9日 下午4:36:13
*/
public final class HostAndPort implements Comparable<HostAndPort>{
	private String host = Constant.LOCAL_IP;
	private int port = Constant.DEFAULT_PORT;
	private PointSlot pointSlot;//这个cluster 生成 服务发现模板时动态设置的。
	public HostAndPort(){
	}
	
	public HostAndPort(String host, int port){
		this.host = host;
		this.port = port;
	}
	
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	
	public PointSlot getPointSlot() {
		return pointSlot;
	}

	public void setPointSlot(PointSlot pointSlot) {
		this.pointSlot = pointSlot;
	}

	public String getHostAndPort() {
		return this.host + ":" + this.port;
	}

	@Override
	public String toString() {
		return "HostAndPort [host=" + host + ", port=" + port + "]";
	}

	@Override
	public int compareTo(HostAndPort o) {
		int val = this.host.compareTo(o.host);
		return val==0 ? (this.port-o.port):val;
	}
}
