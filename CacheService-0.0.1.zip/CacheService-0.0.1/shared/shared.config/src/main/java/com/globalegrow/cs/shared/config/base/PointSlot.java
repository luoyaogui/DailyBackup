package com.globalegrow.cs.shared.config.base;

public class PointSlot {
	private int startSlot;
	private int endSlot ;
	public PointSlot(int startSlot, int endSlot) {
		super();
		this.startSlot = startSlot;
		this.endSlot = endSlot;
	}
	public int getStartSlot() {
		return startSlot;
	}
	public void setStartSlot(int startSlot) {
		this.startSlot = startSlot;
	}
	public int getEndSlot() {
		return endSlot;
	}
	public void setEndSlot(int endSlot) {
		this.endSlot = endSlot;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + endSlot;
		result = prime * result + startSlot;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PointSlot other = (PointSlot) obj;
		if (endSlot != other.endSlot)
			return false;
		if (startSlot != other.startSlot)
			return false;
		return true;
	}

}
