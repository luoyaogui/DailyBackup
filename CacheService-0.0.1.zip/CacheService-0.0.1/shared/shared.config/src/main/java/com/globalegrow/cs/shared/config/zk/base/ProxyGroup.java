package com.globalegrow.cs.shared.config.zk.base;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.globalegrow.cs.shared.common.utils.CSToStringStyle;


/**
* Title: ProxyGroup
* Description: 代理组信息
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月15日 上午10:33:16
*/
public class ProxyGroup implements Serializable {

    private static final long serialVersionUID = 1L;
    
	private String            name;// 唯一标示
    private OnOfflineStatus     status;//状态
    private String            description;                              // 描述信息
    private Date              gmtCreate;//创建时间
    private Date              gmtModified;//最后一次更新时间
    private ProxyGroupParameter  parameters       = new ProxyGroupParameter();//参数

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public OnOfflineStatus getStatus() {
        return status;
    }

    public void setStatus(OnOfflineStatus status) {
        this.status = status;
    }

    public ProxyGroupParameter getParameters() {
        return parameters;
    }

    public void setParameters(ProxyGroupParameter parameters) {
        this.parameters = parameters;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, CSToStringStyle.DEFAULT_STYLE);
    }

}
