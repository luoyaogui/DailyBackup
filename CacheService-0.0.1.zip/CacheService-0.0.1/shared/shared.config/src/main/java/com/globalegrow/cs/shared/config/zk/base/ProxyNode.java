package com.globalegrow.cs.shared.config.zk.base;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.globalegrow.cs.shared.common.utils.CSToStringStyle;


/**
* Title: ProxyNode
* Description: 代理节点信息
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月15日 上午10:33:16
*/
public class ProxyNode implements Serializable {

    private static final long serialVersionUID = 1L;
    
	private long            uuid;// 唯一标示
    private OnOfflineStatus     status;//状态
    private String            description;                              // 描述信息
    private Date              gmtCreate;//创建时间
    private Date              gmtModified;//最后一次更新时间
    private ProxyNodeParameter  parameters       = new ProxyNodeParameter();//参数

    public long getUuid() {
		return uuid;
	}

	public void setUuid(long uuid) {
		this.uuid = uuid;
	}

	public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public OnOfflineStatus getStatus() {
        return status;
    }

    public void setStatus(OnOfflineStatus status) {
        this.status = status;
    }

    public ProxyNodeParameter getParameters() {
        return parameters;
    }

    public void setParameters(ProxyNodeParameter parameters) {
        this.parameters = parameters;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, CSToStringStyle.DEFAULT_STYLE);
    }

}
