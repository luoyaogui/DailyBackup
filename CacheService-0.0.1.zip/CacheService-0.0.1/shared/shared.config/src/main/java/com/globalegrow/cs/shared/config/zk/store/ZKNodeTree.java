package com.globalegrow.cs.shared.config.zk.store;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.zookeeper.KeeperException;

import com.globalegrow.cs.shared.common.utils.ByteUtils;


/**
 * Title: ZKNodeTree
 * Description: 存储路径、路径数据相关的信息
 *             路径作为key，ZKNodeInfo作为value（路径的数据信息）
 * Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
 * @author yaoguiluo
 * @date 2017年5月13日 上午10:13:19
 */
public final class ZKNodeTree {

	private ZKNodeTree() {
		reset();
	}

	private static class SingletonHolder {  
		private static final ZKNodeTree INSTANCE = new ZKNodeTree();
	}  

	public static final ZKNodeTree getInstance() { 
		return SingletonHolder.INSTANCE;  
	}  
	/**
	 * key为路径，value为该路径对应的信息
	 */
	private final ConcurrentHashMap<String, ZKNodeInfo> nodes = new ConcurrentHashMap<String, ZKNodeInfo>();
	/**
	 * 切换时备份
	 * 	上线时，把cutBackUp放入nodes中，清空cutBackUp
	 *  下线时，把node放入cutBackUp中，清空nodes
	 */
	private final Map<String, ZKNodeInfo> cutBackUp = new ConcurrentHashMap<String, ZKNodeInfo>();
	

	/** 当前组 */
	private String group;
	
	/**
	 * 清空本地缓存
	 */
	public void reset(){
		nodes.clear();
	}
	
	public synchronized void turnOn(){
		for(Map.Entry<String, ZKNodeInfo> entry :cutBackUp.entrySet()){
			nodes.putIfAbsent(entry.getKey(), entry.getValue());
		}
		cutBackUp.clear();
	}
	public synchronized void turnOff(){
		cutBackUp.putAll(nodes);
		nodes.clear();
	}

	/**
	 * 创建路径节点
	 * @param path  路径
	 * @param data  数据
	 */
	public void createNode(String path, byte[] data) {
		nodes.put(path, new ZKNodeInfo(data));
	}
	/**
	 * 删除路径
	 * @param path  路径 
	 */
	public void deleteNode(String path) throws KeeperException.NoNodeException {
		nodes.remove(path);
	}
	/**
	 * 更新路径的数据
	 * @param path  路径
	 * @param data  新的数据
	 */
	public void setData(String path, byte[] data) {
		ZKNodeInfo node = nodes.get(path);
		if(null == node){
			nodes.put(path, new ZKNodeInfo(data));
		}else{
			synchronized (node) {
				node.setData(data);
			}
		}
		node = null;
	}
	/**
	 * 获取数据
	 * @param path 路径
	 * @param dataType  返回的数据类型
	 * @return 该路径的数据信息，不存在或数据格式不对则抛出异常
	 * @throws Exception 
	 */
	public <T> T getData(String path,Class<T> dataType) throws Exception {
		ZKNodeInfo n = nodes.get(path);
		if (n == null) {
			throw new Exception(path + " get data failed !");
		}
		synchronized (n) {
			try {
				return ByteUtils.jsonByte2CustomType(n.getData(), dataType);
			} catch (Exception e) {
				throw new Exception(e);
			}
		}
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	/*public void print(){
		for(Map.Entry<String, ZKNodeInfo> entry :nodes.entrySet()){
			System.out.println("key:"+entry.getKey()+", value="+entry.getValue());
		}
	}*/
}
