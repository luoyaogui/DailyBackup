package com.globalegrow.cs.shared.config.test;

import org.junit.Test;

import com.globalegrow.cs.shared.common.utils.JsonUtils;
import com.globalegrow.cs.shared.config.zk.base.ProxyGroupParameter;
import com.globalegrow.cs.shared.config.zk.base.ProxyNodeParameter;

public class JsonTest {
	
	@Test
	public void testDcode(){
		ProxyGroupParameter gpara = new ProxyGroupParameter();
		gpara.setCommandCustom("new Runnable() {}");
		gpara.setFiltersRedisCommand("rpop");
		gpara.setExchangeCommandNames("get:sget");
		gpara.setKeyLimits(128);
		gpara.setValueLimits(256);
		String toJson = JsonUtils.marshalToString(gpara);
		System.out.println("(1) to string : "+toJson);
		System.out.println("(1) from string : "+JsonUtils.unmarshalFromString(toJson, ProxyGroupParameter.class));

		ProxyNodeParameter npara = new ProxyNodeParameter();
		npara.setBelongProxyGroup("test");
		npara.setPgParameters(gpara);
		npara.setBelongZKGroup("kx_inner_ip");
		npara.setZkAddresses("127.0.0.1:2181;");
		npara.setIp("10.2.2.1");
		npara.setPort(8090);
		npara.setOuterIp("183.3.3.3");
		npara.setCloseOuterIP(true);
		toJson = JsonUtils.marshalToString(npara);
		System.out.println("(2) to string : "+toJson);
		System.out.println("(2) from string : "+JsonUtils.unmarshalFromString(toJson, ProxyNodeParameter.class));
	}
}
