package com.globalegrow.cs.shared.config.test;

import org.junit.Test;

import com.globalegrow.cs.shared.common.utils.JsonUtils;
import com.globalegrow.cs.shared.common.utils.StringUtil;
import com.globalegrow.cs.shared.config.base.HostAndPort;
import com.globalegrow.cs.shared.config.zk.listener.ZKDataListener;

public class ListenerTest {
	
	@Test
	public void testDataChange(){
		ZKDataListener li = new ZKDataListener<HostAndPort>() {
			@Override
			public void dataChange(String data) {//Class<HostAndPort> dataType
				if(StringUtil.isNoneEmpty(data))
					System.out.println("change : "+JsonUtils.unmarshalFromString(data,HostAndPort.class));
				System.out.println("exception  data is null !");
			}

			@Override
			public void dataRemove(String data) {
				if(StringUtil.isNoneEmpty(data))
					System.out.println("remove : "+JsonUtils.unmarshalFromString(data,HostAndPort.class));
				System.out.println("exception  data is null !");
			}

			@Override
			public void dataAdd(String data) {
				if(StringUtil.isNoneEmpty(data))
					System.out.println("add : "+JsonUtils.unmarshalFromString(data,HostAndPort.class));
				System.out.println("exception  data is null !");
				
			}
		};
		String toJson = JsonUtils.marshalToString(new HostAndPort("10.10.2.2",100));
		li.dataChange(toJson);
	}
}
