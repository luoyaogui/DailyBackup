package com.globalegrow.cs.shared.common.utils.system;

import java.util.Date;

public class DiskUsedUtil
{
  public static MonitorResult getDiskUsed(String ip, int port, String user, String password)
  {
    return getDiskUsed(SSHSupport.newInstance(ip, port, user, password), ip); }

  public static MonitorResult getDiskUsed(String ip, String user, String password) {
    return getDiskUsed(SSHSupport.newInstance(ip, user, password), ip); }

  public static MonitorResult getDiskUsed(SSHSupport support, String ip) {
    String result = support.execute("df -h | grep home");
    double used = getDiskUsed(result);
    MonitorResult oneResult = new MonitorResult();
    oneResult.setDescribe("");
    oneResult.setKey("disk used");
    oneResult.setIp(ip);
    oneResult.setTime(new Date());
    oneResult.setValue(Double.valueOf(used));

    return oneResult;
  }

  private static double getDiskUsed(String loadStr)
  {
    if ((loadStr == null) || (loadStr.indexOf("%") == -1)) {
      return 0.0D;
    }
    int index = loadStr.indexOf("%");
    String subStr = loadStr.substring(index - 3, index).trim();

    if (subStr != null) {
      return Double.valueOf(subStr).doubleValue();
    }
    return 0.0D;
  }
}