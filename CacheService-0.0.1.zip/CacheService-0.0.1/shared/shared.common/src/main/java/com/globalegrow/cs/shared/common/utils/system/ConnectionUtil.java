package com.globalegrow.cs.shared.common.utils.system;

import java.util.Date;

public class ConnectionUtil
{
  public static MonitorResult getConnectedCount(String ip, int port, String user, String password, String filterString)
  {
    return getConnectedCount(SSHSupport.newInstance(ip, port, user, password), ip, filterString);
  }

  public static MonitorResult getConnectedCount(String ip, String user, String password, String filterString) {
    return getConnectedCount(SSHSupport.newInstance(ip, user, password), ip, filterString);
  }

  private static MonitorResult getConnectedCount(SSHSupport support, String ip, String filterString) {
    String result = support.execute("netstat -nat|grep " + filterString + "|awk '{print $5}'");

    double count = 0.0D;
    try {
      count = Double.parseDouble(result);
    } catch (NumberFormatException e) {
      throw new RuntimeException(e);
    }

    MonitorResult monitorResult = new MonitorResult();
    monitorResult.setDescribe("");
    monitorResult.setKey("dummy");
    monitorResult.setIp(ip);
    monitorResult.setTime(new Date());
    monitorResult.setValue(Double.valueOf(count));
    return monitorResult;
  }

  public static boolean IsConnected(String ip, int port, String toString, String user, String password)
  {
    return (getConnectedCount(ip, port, toString, user, password).getValue().intValue() > 0);
  }

  public static boolean IsConnected(String ip, String toString, String user, String password) {
    return (getConnectedCount(ip, toString, user, password).getValue().intValue() > 0);
  }

  public static String getConnectionInfo(String ip, int port, String user, String password)
  {
    SSHSupport support = SSHSupport.newInstance(user, password, ip);
    return support.execute(SystemStatisticConstant.getConnOfPortCMD(port));
  }
}