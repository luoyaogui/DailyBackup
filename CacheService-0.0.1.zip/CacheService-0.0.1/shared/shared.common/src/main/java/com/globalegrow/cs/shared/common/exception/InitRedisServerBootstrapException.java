package com.globalegrow.cs.shared.common.exception;

public class InitRedisServerBootstrapException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InitRedisServerBootstrapException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InitRedisServerBootstrapException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InitRedisServerBootstrapException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InitRedisServerBootstrapException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InitRedisServerBootstrapException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
