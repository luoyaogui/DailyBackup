package com.globalegrow.cs.shared.common.utils.cmd;

public class Result<V> {

	private V v;
	public Result() {
	}
	public Result(V v) {
		super();
		this.v = v;
	}

	public V getV() {
		return v;
	}

	public void setV(V v) {
		this.v = v;
	}
	
}
