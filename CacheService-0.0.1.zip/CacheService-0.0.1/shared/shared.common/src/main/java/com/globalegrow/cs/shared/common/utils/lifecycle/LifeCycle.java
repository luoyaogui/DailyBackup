package com.globalegrow.cs.shared.common.utils.lifecycle;

public interface LifeCycle {

	void start();

    void stop();

    boolean isStart();
}
