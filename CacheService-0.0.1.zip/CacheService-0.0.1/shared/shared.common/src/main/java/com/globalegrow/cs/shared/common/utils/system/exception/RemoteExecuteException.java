package com.globalegrow.cs.shared.common.utils.system.exception;

public class RemoteExecuteException extends RuntimeException
{
  private static final long serialVersionUID = -7410016800727397507L;

  public RemoteExecuteException(String message)
  {
    super(message);
  }

  public RemoteExecuteException(Throwable cause)
  {
    super(cause);
  }

  public RemoteExecuteException(String message, Throwable cause)
  {
    super(message, cause);
  }
}