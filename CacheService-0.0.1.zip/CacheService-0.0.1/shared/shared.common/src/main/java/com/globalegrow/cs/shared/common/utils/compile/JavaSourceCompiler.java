package com.globalegrow.cs.shared.common.utils.compile;

import com.globalegrow.cs.shared.common.utils.compile.model.JavaSource;

public abstract interface JavaSourceCompiler {
	
  public abstract Class compile(String paramString);

  public abstract Class compile(JavaSource paramJavaSource);
}