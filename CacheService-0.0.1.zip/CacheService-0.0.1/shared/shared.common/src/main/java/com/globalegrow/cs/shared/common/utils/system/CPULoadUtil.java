package com.globalegrow.cs.shared.common.utils.system;

import java.util.Date;

public class CPULoadUtil
{
  public static MonitorResult getCpuLoad(String ip, int port, String user, String password)
  {
    return getCpuLoad(SSHSupport.newInstance(ip, port, user, password), ip);
  }

  public static MonitorResult getCpuLoad(String ip, String user, String password) {
    return getCpuLoad(SSHSupport.newInstance(ip, user, password), ip);
  }

  private static MonitorResult getCpuLoad(SSHSupport support, String ip) {
    String result = support.execute("uptime");
    double load = getAvarageLoad(result);
    MonitorResult oneResult = new MonitorResult();
    oneResult.setDescribe("");
    oneResult.setIp(ip);
    oneResult.setKey("cpu load");
    oneResult.setTime(new Date());
    oneResult.setValue(Double.valueOf(load));

    return oneResult;
  }

  private static double getAvarageLoad(String loadStr)
  {
    if ((loadStr == null) || (loadStr.indexOf("load average:") == -1)) {
      return 0.0D;
    }
    int index = loadStr.indexOf("load average:");
    String subStr = loadStr.substring(index + 14);
    int subIndex = subStr.indexOf(44);
    String valueStr = subStr.substring(0, subIndex).trim();
    if (valueStr != null) {
      return Double.valueOf(valueStr).doubleValue();
    }
    return 0.0D;
  }
}