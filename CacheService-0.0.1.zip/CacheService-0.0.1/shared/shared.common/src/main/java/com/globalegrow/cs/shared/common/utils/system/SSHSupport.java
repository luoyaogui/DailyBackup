package com.globalegrow.cs.shared.common.utils.system;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;
import com.globalegrow.cs.shared.common.utils.system.exception.RemoteExecuteException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class SSHSupport
{
  private String user = "nobody";
  private String password = "look";
  private String ip = "127.0.0.1";
  private int port = 22;

  private SSHSupport(String ip, int port, String user, String password)
  {
    this.ip = ip;
    this.port = port;
    this.user = user;
    this.password = password;
  }

  private SSHSupport(String ip, String user, String password) {
    this.ip = ip;
    this.user = user;
    this.password = password;
  }

  public static SSHSupport newInstance(String ip, int port, String user, String password)
  {
    return new SSHSupport(ip, port, user, password);
  }

  public static SSHSupport newInstance(String ip, String user, String password)
  {
    return new SSHSupport(ip, user, password);
  }

  public String execute(String cmd) throws RemoteExecuteException
  {
    StringBuilder result = new StringBuilder();
    try {
      Connection conn = new Connection(this.ip, this.port);
      conn.connect();
      boolean isAuthenticated = conn.authenticateWithPassword(this.user, this.password);
      if (!(isAuthenticated)) {
        result.append("ERROR: Authentication Failed !");
      }

      Session session = conn.openSession();

      session.execCommand(cmd);

      BufferedReader read = new BufferedReader(new InputStreamReader(new StreamGobbler(session
        .getStdout()), "GBK"));
      String line = "";
      while ((line = read.readLine()) != null) {
        result.append(line).append("\r\n");
      }
      session.close();
      conn.close();
      return result.toString();
    }
    catch (Throwable e) {
      throw new RemoteExecuteException("-------", e);
    }
  }
}