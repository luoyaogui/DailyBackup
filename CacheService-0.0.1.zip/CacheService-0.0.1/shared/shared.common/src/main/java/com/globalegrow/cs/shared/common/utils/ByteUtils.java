package com.globalegrow.cs.shared.common.utils;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.exception.NestableRuntimeException;

public class ByteUtils{
	//编码格式
	public static final String  ENCODE = "utf-8";

	/**
	 * json字节数组转自定义类型
	 */
	public static <T> T jsonByte2CustomType(byte[] data,Class<T> dataType) throws Exception{
		if(data == null)
			throw new Exception("ByteUtils-jsonByte2CustomType  data is null !");
		String json = new String(data,Charset.forName(ENCODE));
		return JsonUtils.unmarshalFromString(json,dataType);//数据反序列化
	}
	/**
	 * 自定义类型转json字节数组
	 */
	public static byte[] customType2JsonByte(Object obj) throws Exception{
		if(obj == null)
			throw new Exception("ByteUtils-customType2JsonByte2  object is null !");
		String toJson = JsonUtils.marshalToString(obj);
		return toJson.getBytes(Charset.forName(ENCODE));
	}

	public static String bigIntToHex(BigInteger big) {
		return big.toString(16);
	}

	public static BigInteger hexToBigInt(String hex) {
		return new BigInteger(hex, 16);
	}

	public static String bytesToString(byte[] bytes) {
		try {
			return new String(bytes, ENCODE);
		} catch (UnsupportedEncodingException e) {
			throw new NestableRuntimeException(e);
		}
	}

	public static byte[] stringToBytes(String string) {
		try {
			return string.getBytes(ENCODE);
		} catch (UnsupportedEncodingException e) {
			throw new NestableRuntimeException(e);
		}
	}

	public static String bytesToBase64String(byte[] bytes) {
		try {
			return new String(Base64.encodeBase64(bytes), ENCODE);
		} catch (UnsupportedEncodingException e) {
			throw new NestableRuntimeException(e);
		}
	}

	public static byte[] base64StringToBytes(String string) {
		try {
			return Base64.decodeBase64(string.getBytes(ENCODE));
		} catch (UnsupportedEncodingException e) {
			throw new NestableRuntimeException(e);
		}
	}

	public static byte[] int2bytes(int i) {
		byte[] b = new byte[4];
		int2bytes(i, b, 0);
		return b;
	}

	public static int bytes2int(byte[] b) {
		ByteBuffer buf = ByteBuffer.allocate(4);
		buf.put(b);
		buf.flip();
		return buf.getInt();
	}

	public static byte[] long2bytes(long l) {
		byte[] b = new byte[8];
		long2bytes(l, b, 0);
		return b;
	}

	public static long bytes2long(byte[] b) {
		ByteBuffer buf = ByteBuffer.allocate(8);
		buf.put(b);
		buf.flip();
		return buf.getLong();
	}

	public static int int2bytes(int i, byte[] data, int offset) {
		data[(offset++)] = (byte)(i >> 24 & 0xFF);
		data[(offset++)] = (byte)(i >> 16 & 0xFF);
		data[(offset++)] = (byte)(i >> 8 & 0xFF);
		data[offset] = (byte)(i & 0xFF);
		return 4;
	}

	public static int bytes2int(byte[] data, int offset) {
		ByteBuffer buffer = ByteBuffer.wrap(data, offset, 4);
		return buffer.getInt();
	}

	public static int long2bytes(long l, byte[] data, int offset) {
		data[(offset++)] = (byte)(int)(l >> 56 & 0xFF);
		data[(offset++)] = (byte)(int)(l >> 48 & 0xFF);
		data[(offset++)] = (byte)(int)(l >> 40 & 0xFF);
		data[(offset++)] = (byte)(int)(l >> 32 & 0xFF);
		data[(offset++)] = (byte)(int)(l >> 24 & 0xFF);
		data[(offset++)] = (byte)(int)(l >> 16 & 0xFF);
		data[(offset++)] = (byte)(int)(l >> 8 & 0xFF);
		data[offset] = (byte)(int)(l & 0xFF);
		return 8;
	}

	public static long bytes2long(byte[] data, int offset) {
		ByteBuffer buffer = ByteBuffer.wrap(data, offset, 8);
		return buffer.getLong();
	}
	
	public static void main(String[] args) {
		try {
			System.out.println(ByteUtils.jsonByte2CustomType(null, Boolean.class));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println(ByteUtils.jsonByte2CustomType("aa".getBytes(), Boolean.class));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println(ByteUtils.jsonByte2CustomType(Boolean.FALSE.toString().getBytes(), Boolean.class));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}