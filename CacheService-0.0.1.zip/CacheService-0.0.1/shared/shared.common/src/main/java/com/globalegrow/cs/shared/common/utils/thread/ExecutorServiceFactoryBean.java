package com.globalegrow.cs.shared.common.utils.thread;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;

/**
 * 基于spring 提供一个async的容器
 * 
 */
public class ExecutorServiceFactoryBean implements FactoryBean, InitializingBean, DisposableBean {

    private ThreadPoolExecutor executor;
    private static final int   DEFAULT_POOL_SIZE    = 50;
    private static final int   DEFAULT_ACCEPT_COUNT = 100;
    private int                poolSize             = DEFAULT_POOL_SIZE;
    private int                acceptCount          = DEFAULT_ACCEPT_COUNT;
    private String             name                 = "CS-Async-Executor";

    public Object getObject() throws Exception {
        return executor;
    }

    public Class getObjectType() {
        return ThreadPoolExecutor.class;
    }

    public boolean isSingleton() {
        return true;
    }

    public void afterPropertiesSet() throws Exception {
        if (executor == null) {// 初始化一个默认值
            executor = new ThreadPoolExecutor(poolSize, poolSize, 60, TimeUnit.SECONDS,
                                              new ArrayBlockingQueue(acceptCount), new NamedThreadFactory(name),
                                              new ThreadPoolExecutor.CallerRunsPolicy());
        }
    }

    public void destroy() throws Exception {
        executor.shutdown();
    }

    public void setExecutor(ThreadPoolExecutor executor) {
        this.executor = executor;
    }

    public void setPoolSize(int poolSize) {
        this.poolSize = poolSize;
    }

    public void setAcceptCount(int acceptCount) {
        this.acceptCount = acceptCount;
    }

    public void setName(String name) {
        this.name = name;
    }

}
