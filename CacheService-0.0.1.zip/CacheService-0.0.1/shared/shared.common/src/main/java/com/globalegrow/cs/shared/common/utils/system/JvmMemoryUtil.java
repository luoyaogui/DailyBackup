package com.globalegrow.cs.shared.common.utils.system;

import com.globalegrow.cs.shared.common.utils.AddressUtils;
import java.util.Date;

public class JvmMemoryUtil
{
  public static MonitorResult getMemoryInfo()
  {
    Runtime imp = Runtime.getRuntime();

    double usedPercent = (imp.maxMemory() - imp.freeMemory()) / imp.maxMemory() * 100L;
    MonitorResult oneResult = new MonitorResult();
    oneResult.setDescribe("");
    oneResult.setKey("memory used");
    oneResult.setIp(AddressUtils.getHostIp());
    oneResult.setTime(new Date());
    oneResult.setValue(Double.valueOf(usedPercent));
    return oneResult;
  }
}