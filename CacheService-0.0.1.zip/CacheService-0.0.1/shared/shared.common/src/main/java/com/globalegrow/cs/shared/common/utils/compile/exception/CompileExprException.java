package com.globalegrow.cs.shared.common.utils.compile.exception;

public class CompileExprException extends RuntimeException
{
  private static final long serialVersionUID = 1L;

  public CompileExprException(String message)
  {
    super(message);
  }

  public CompileExprException(String message, Throwable cause) {
    super(message, cause);
  }
}