package com.globalegrow.cs.shared.common.utils.lifecycle;

import org.apache.commons.lang.exception.NestableRuntimeException;

public class LifecycleException extends NestableRuntimeException {

    private static final long serialVersionUID = -654893533794556357L;

    public LifecycleException(String errorCode){
        super(errorCode);
    }

    public LifecycleException(String errorCode, Throwable cause){
        super(errorCode, cause);
    }

    public LifecycleException(String errorCode, String errorDesc){
        super(errorCode + ":" + errorDesc);
    }

    public LifecycleException(String errorCode, String errorDesc, Throwable cause){
        super(errorCode + ":" + errorDesc, cause);
    }

    public LifecycleException(Throwable cause){
        super(cause);
    }

    public Throwable fillInStackTrace() {
        return this;
    }

}
