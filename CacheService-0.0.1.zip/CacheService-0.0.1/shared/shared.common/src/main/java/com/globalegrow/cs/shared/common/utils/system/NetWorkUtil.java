package com.globalegrow.cs.shared.common.utils.system;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class NetWorkUtil
{
  public static NetWorkUtil newInstance()
  {
    return new NetWorkUtil();
  }

  public Map<String, MonitorResult> getNetWorkUsed(String ip, int port, String user, String password)
  {
    return getNetWorkUsed(SSHSupport.newInstance(ip, port, user, password), ip); }

  public Map<String, MonitorResult> getNetWorkUsed(String ip, String user, String password) {
    return getNetWorkUsed(SSHSupport.newInstance(ip, user, password), ip); }

  private Map<String, MonitorResult> getNetWorkUsed(SSHSupport support, String ip) {
    String result = support.execute("/sbin/ifconfig eth0 | grep bytes");
    if (result == null) {
      return null;
    }
    String[] subStrings = result.split(":");
    if (subStrings.length != 3) {
      return null;
    }
    Map resultMap = new HashMap();

    MonitorResult oneResult = new MonitorResult();
    oneResult.setDescribe("");
    oneResult.setIp(ip);
    oneResult.setKey("RX network used");
    oneResult.setTime(new Date());
    oneResult.setValue(Double.valueOf(getTXResult(subStrings[1])));
    resultMap.put("RX", oneResult);

    MonitorResult oneResult2 = new MonitorResult();
    oneResult2.setDescribe("");
    oneResult2.setIp(ip);
    oneResult2.setKey("TX network used");
    oneResult2.setTime(new Date());
    oneResult2.setValue(Double.valueOf(getRxResult(subStrings[2])));
    resultMap.put("TX", oneResult2);
    return resultMap;
  }

  public double getTXResult(String result)
  {
    String sub = result.substring(0, result.indexOf("("));
    if (sub != null) {
      return Double.valueOf(sub.trim()).doubleValue();
    }

    return 0.0D;
  }

  public double getRxResult(String result)
  {
    String sub = result.substring(0, result.indexOf("("));
    if (sub == null) {
      return 0.0D;
    }
    return Double.valueOf(sub.trim()).doubleValue();
  }
}