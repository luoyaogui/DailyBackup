package com.globalegrow.cs.shared.common.utils.system;

public class SystemStatisticConstant
{
  public static final String CPU_LOAD = "cpu load";
  public static final String CPU_LOAD_CMD = "uptime";
  public static final String CPU_LOAD_NAME = "cpuLoad";
  public static final String MEM_NAME = "memory";
  public static final String DISK_NAME = "disk";
  public static final String RX_NETWORK_NAME = "rxNetwork";
  public static final String TX_NETWORK_NAME = "txNetwork";
  public static final String DISK = "disk used";
  public static final String DISK_CMD = "df -h | grep home";
  public static final String NETWORK_CMD = "/sbin/ifconfig eth0 | grep bytes";
  public static final String RX_NETWORK = "RX network used";
  public static final String TX_NETWORK = "TX network used";
  public static final String MEM = "memory used";
  public static final String DUMMY = "dummy";
  private static final String CONN_FORMAT = "netstat -nat|grep -i %s |wc -l";

  public static String getConnOfPortCMD(int port)
  {
    return String.format("netstat -nat|grep -i %s |wc -l", new Object[] { Integer.valueOf(port) });
  }
}