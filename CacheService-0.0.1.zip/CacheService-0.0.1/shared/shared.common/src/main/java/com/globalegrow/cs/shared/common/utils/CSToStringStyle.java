package com.globalegrow.cs.shared.common.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.lang.builder.ToStringStyle;

public class CSToStringStyle extends ToStringStyle
{
  private static final long serialVersionUID = -6568177374288222145L;
  private static final String DEFAULT_TIME = "yyyy-MM-dd HH:mm:ss";
  private static final String DEFAULT_DAY = "yyyy-MM-dd";
  public static final ToStringStyle TIME_STYLE = new DateStyle("yyyy-MM-dd HH:mm:ss");

  public static final ToStringStyle DAY_STYLE = new DateStyle("yyyy-MM-dd");

  public static final ToStringStyle DEFAULT_STYLE = TIME_STYLE;

  private static class DateStyle extends ToStringStyle
  {
    private static final long serialVersionUID = 5208917932254652886L;
    private String pattern;

    public DateStyle(String pattern)
    {
      setUseShortClassName(true);
      setUseIdentityHashCode(false);

      this.pattern = pattern;
    }

    protected void appendDetail(StringBuffer buffer, String fieldName, Object value)
    {
      if (value instanceof Date) {
        value = new SimpleDateFormat(this.pattern).format(value);
      }

      buffer.append(value);
    }
  }
}