package com.globalegrow.cs.shared.common.utils.code;

import java.text.MessageFormat;
import java.util.ResourceBundle;
import org.apache.commons.lang.StringUtils;

public class ResourceBundleUtil{
  private ResourceBundle bundle;

  public ResourceBundleUtil(String bundleName) {
    this.bundle = ResourceBundle.getBundle(bundleName);
  }

  public String getMessage(String key, String[] params) {
    if (key == null) {
      return null;
    }

    String msg = this.bundle.getString(key);

    if ((params == null) || (params.length == 0)) {
      return msg;
    }

    if (StringUtils.isBlank(msg))
    {
      return msg;
    }
    return MessageFormat.format(msg, (Object[])params);
  }
}