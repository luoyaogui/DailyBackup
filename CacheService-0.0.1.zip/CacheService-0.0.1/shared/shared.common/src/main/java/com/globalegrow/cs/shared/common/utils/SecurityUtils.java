package com.globalegrow.cs.shared.common.utils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SecurityUtils
{
	
  public static String StringToMD5L32(String plainText) {

		// 首先判断是否为空
		if (StringUtil.isNoneEmpty(plainText)) {
			try {
				// 首先进行实例化和初始化
				MessageDigest md = MessageDigest.getInstance("MD5");
				// 得到一个操作系统默认的字节编码格式的字节数组
				byte[] btInput = plainText.getBytes();
				// 对得到的字节数组进行处理
				md.update(btInput);
				// 进行哈希计算并返回结果
				byte[] btResult = md.digest();
				// 进行哈希计算后得到的数据的长度
				StringBuffer sb = new StringBuffer();
				for (byte b : btResult) {
					int bt = b & 0xff;
					if (bt < 16) {
						sb.append(0);
					}
					sb.append(Integer.toHexString(bt));
				}
				return sb.toString();
			} catch (NoSuchAlgorithmException e) {
			}
		}
		return null;
	}
	
	
  public static String getMD5Str(String str)
  {
    MessageDigest messageDigest = null;
    try
    {
      messageDigest = MessageDigest.getInstance("MD5");

      messageDigest.reset();

      messageDigest.update(str.getBytes("UTF-8"));
    } catch (NoSuchAlgorithmException e) {
      System.out.println("NoSuchAlgorithmException caught!");
      System.exit(-1);
    } catch (UnsupportedEncodingException e) {
      e.printStackTrace();
    }

    byte[] byteArray = messageDigest.digest();

    StringBuffer md5StrBuff = new StringBuffer();

    for (int i = 0; i < byteArray.length; ++i) {
      if (Integer.toHexString(0xFF & byteArray[i]).length() == 1) md5StrBuff.append("0").append(Integer.toHexString(0xFF & byteArray[i]));
      else md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));
    }

    return md5StrBuff.toString();
  }

  public static String getPassword(String str) {
    StringBuffer password = new StringBuffer();
    String md5Str = getMD5Str(str);
    password.append(md5Str.substring(26, 32));
    password.append(md5Str.substring(10, 17));
    password.append(md5Str.substring(15, 22));
    return password.toString();
  }
}