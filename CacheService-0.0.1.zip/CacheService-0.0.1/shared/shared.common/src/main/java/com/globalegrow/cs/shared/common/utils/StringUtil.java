package com.globalegrow.cs.shared.common.utils;

public class StringUtil
{
  public static boolean empty(String s)
  {
    return ((s == null) || (s.length() == 0) || (s.trim().length() == 0));
  }
  
  // 验证字符串不是null、空格填充的字符串、tab填充的字符串
	public static boolean isNoneEmpty(String str){
		if(null == str)
			return false;
		if(0 == str.length()){
			return false;
		}
		return str.trim().replaceAll("\\s{1,}", "").length() > 0;//	^\\s*$
	}
}