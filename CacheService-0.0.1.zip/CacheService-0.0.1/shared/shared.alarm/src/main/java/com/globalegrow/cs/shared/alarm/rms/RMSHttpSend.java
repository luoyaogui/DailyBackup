package com.globalegrow.cs.shared.alarm.rms;

import java.io.IOException;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.globalegrow.cs.shared.alarm.rms.RMSReqData.Content;
import com.globalegrow.cs.shared.common.utils.AddressUtils;
import com.globalegrow.cs.shared.common.utils.JsonUtils;
import com.globalegrow.cs.shared.common.utils.SecurityUtils;
import com.globalegrow.cs.shared.common.utils.TimeUtil;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


/**
 * @author yaoguiluo
 * 2017年3月4日 上午9:37:44
 * 报警服务类
 */
public class RMSHttpSend {
	private static OkHttpClient client = new OkHttpClient();
	private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
	
	private static final Logger         logger = LoggerFactory.getLogger(RMSHttpSend.class);
	private static String HB = "HeartBeat";
	private static String EQ = "=";
    
    public static class Builder {
    		RMSReq req = new RMSReq();
		RMSReqData param = new RMSReqData();
    		
    		public Builder(){
    		}
    		public Builder token(String token){
    			req.setToken(token);
    			return this;
    		}
    		public Builder pointCode(String pointCode){
    			param.setPoint_code(pointCode);
    			return this;
    		}
    		public Builder errorCode(String errorCode){
    			param.setError_code(errorCode);
    			return this;
    		}
    		public Builder errorLevel(int errorLevel){
    			param.setLevel(errorLevel);
    			return this;
    		}
    		public Builder HeartBeat(){
    			param.setIs_test(1);
    			Content cont = new Content();
    			cont.setInfo(HB);
    			param.setContent(cont);
    			return this;
    		}
    		public Builder msg(String msg){
    			Content cont = new Content();
    			cont.setInfo(msg);
    			param.setContent(cont);
    			return this;
    		}
    		private String build() {
    			param.setNotice_time(TimeUtil.getCurrentTime());
    			param.setServer_ip(AddressUtils.getHostIp());
    			param.setServer_name(AddressUtils.getHostName());
    			
    			req.setToken(SecurityUtils.StringToMD5L32(req.getToken()+JsonUtils.marshalToString(param)));
    			req.setData(param);
    			
    			return JsonUtils.marshalToString(req);
    		}
    }
	
	public static void post(String url, String ProjectCode, Builder param) {
	    RequestBody body = RequestBody.create(JSON, param.build());
	    Request request = new Request.Builder()
	            .url(url+EQ+ProjectCode)
	            .post(body)
	            .build();
	    Response response;
		try {
			response = client.newCall(request).execute();
			if (!response.isSuccessful()) {
		    		logger.error("send alarm failed : " + response);
		    }
		} catch (IOException e) {
			logger.error("send alarm error : " + ExceptionUtils.getFullStackTrace(e));
		}
	}
}
