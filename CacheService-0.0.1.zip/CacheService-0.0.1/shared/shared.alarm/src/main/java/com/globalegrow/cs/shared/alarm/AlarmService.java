package com.globalegrow.cs.shared.alarm;

public abstract interface AlarmService {
	
  public abstract void sendAlarm(String[] paramArrayOfString, String paramString);
  
}