package com.globalegrow.cs.shared.alarm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DefaultAlarmService implements AlarmService {
  private static final Logger logger = LoggerFactory.getLogger(DefaultAlarmService.class);

  public void sendAlarm(String[] receivers, String msg) {
    for (String re : receivers)
      logger.info(re, msg);
  }
}