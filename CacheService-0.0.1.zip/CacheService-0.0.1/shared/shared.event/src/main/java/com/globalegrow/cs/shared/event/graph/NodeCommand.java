package com.globalegrow.cs.shared.event.graph;
/**
 * 触发节点执行的业务逻辑处理.如果某个节点达到执行的条件,就会触发这里的业务代码
 * @author pengbingting
 *
 */
public interface NodeCommand {

}
