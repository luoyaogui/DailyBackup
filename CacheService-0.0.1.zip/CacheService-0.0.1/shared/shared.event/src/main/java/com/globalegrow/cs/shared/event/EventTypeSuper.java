package com.globalegrow.cs.shared.event;

public interface EventTypeSuper {

}
