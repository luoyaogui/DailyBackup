package com.globalegrow.cs.shared.event;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.globalegrow.cs.shared.event.pool.ObjectEventFactory;
import com.globalegrow.cs.shared.event.task.queue.Log;

/**
 * 绝对业务流水线编程模型：即不管前一个是否执行成功，后一个业务逻辑都会执行。直至这个工序的所有动作都走完。
 * @author pengbingting
 *
 * @param <V>
 */
public abstract class AbstractEventObject<V> extends AbstractEventOptimizer<V> implements ObjectListenerEventObject<V>{
	protected ConcurrentHashMap<Integer, Collection<ObjectListener<V>>> listeners;
	public AbstractEventObject(){
		this(false);
	}
	
	/**
	 * 支持乐观触发和悲观触发两种模式.
	 * @param isOptimism true 表示乐观触发，false 表示悲观触发
	 */
	public AbstractEventObject(boolean isOptimism){
		super(isOptimism);
		this.attachListener();
	}
	
	/**
	 * 支持乐观触发和悲观触发两种模式.
	 * @param isOptimism true 表示乐观触发，false 表示悲观触发
	 */
	public AbstractEventObject(ObjectEventFactory objectEventFactory,boolean isOptimism){
		super(objectEventFactory, isOptimism);
		this.attachListener();
	}
	
	public abstract void attachListener();
	
	/**
	 * 如果子类不支持对象池技术，那么重写该方法可能会带来更佳的性能
	 */
	@SuppressWarnings("unchecked")
	public void publish(V v, int eventType) {
		if(!isobjectEventPool){
			notifyListeners(new ObjectEvent<V>(v, eventType));
		}else{
			ObjectEvent<V> objectEvent = null ;
			try {
				objectEvent =(ObjectEvent<V>) objectEventFactory.borrowObjectEvent();
			} catch (Exception e) {
				e.printStackTrace();
				Log.error("borrow object event exception", e);
				objectEvent = new ObjectEvent<V>();
			}
			objectEvent.setValue(v);
			objectEvent.setEventType(eventType);
			notifyListeners(objectEvent);
		}
	}
	
	public void addListener(ObjectListener<V> objectListener, int eventType) {
		lock.lock();
		try{
			if (listeners == null) {
				listeners = new ConcurrentHashMap<Integer, Collection<ObjectListener<V>>>();
			}
		}finally{
			lock.unlock();
		}
		if (listeners.get(eventType) == null) {
			Collection<ObjectListener<V>> tempInfo = new ArrayList<ObjectListener<V>>();
			tempInfo.add(objectListener);
			listeners.put(eventType, tempInfo);
		} else {
			listeners.get(eventType).add(objectListener);
		}
		listenersModifyStatus.incrementAndGet(eventType);
		debugEventMsg("注册一个事件,类型为" + eventType);
	}

	public void removeListener(ObjectListener<V> objectListener, int eventType) {
		if (listeners == null) return;
		
		Collection<ObjectListener<V>> tempInfo = listeners.get(eventType);
		lock.lock();
		try{
			if(tempInfo == null){
				return ;
			}
			if(tempInfo.size()==1){
				tempInfo.clear();
				return ;
			}
			tempInfo.remove(objectListener);
		}finally{
			lock.unlock();
		}
		listenersModifyStatus.decrementAndGet(eventType);
		debugEventMsg("移除一个事件,类型为" + eventType);
	}
	
	public void removeListener(int eventType){
		listeners.remove(eventType);
		listenersModifyStatus.decrementAndGet(eventType);
		debugEventMsg("移除一个事件,类型为" + eventType);
	}
	
	@SuppressWarnings("unchecked")
	public void notifyListeners(ObjectEvent<V> event) {
		@SuppressWarnings("rawtypes")
		List tempList = null;
		if (listeners == null)
			return;
		//1、
		int eventType = event.getEventType();
		//2、乐观触发和悲观触发控制
		if(!isOptimism){
			long modifyStatus = listenersModifyStatus.get(eventType);
			if(getListenerStatus.get(eventType) != modifyStatus){
				getListenerStatus.addAndGet(eventType, modifyStatus);
				Collection<ObjectListener<V>> tempInfo = listeners.get(eventType);
				lock.lock();
				try{
					if (tempInfo != null) {
						tempList = new ArrayList<ObjectListener<V>>(tempInfo);
						//更换新的值
						trrigerObjectListener.put(eventType, tempList);
					}
				}finally{
					lock.unlock();
				}
			}else{
				tempList = trrigerObjectListener.get(eventType);
			}
		}else{
			tempList = (List<ObjectListener<V>>) listeners.get(eventType);
		}
		
		//3、触发,可以改造为异步触发.只需覆盖这个方法即可
		listenerHandler(tempList, event);
	}

	public void listenerHandler(List<ObjectListener<V>> objectListeners,ObjectEvent<V> event) {
		if (objectListeners != null) {
			try {
				for (ObjectListener<V> listener : objectListeners) {
					listener.onEvent(event);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(isobjectEventPool){
					objectEventFactory.returnObjectEvent(event);
				}
			}
		}
	}
	
	public void clearListener() {
		lock.lock();
		try{
			if (listeners != null) {
				listeners = null;
			}
		}finally{
			lock.unlock();
		}
	}

	protected void debugEventMsg(String msg) {
		if (isDebug) {
			System.out.println(msg);;
		}
	}
}
