package com.globalegrow.cs.shared.event;

import java.util.List;

public interface ObjectListenerEventObject<V> extends EventObject<V>{

	/**
	 * 添加某个事件类型的监听器。一个 eventType 可对应多个 object listener
	 * @param objectListener
	 * @param eventType
	 */
	public void addListener(ObjectListener<V> objectListener, int eventType);
	
	/**
	 * 移除指定 event type 中的一个object listener
	 * @param objectListener
	 * @param eventType
	 */
	public void removeListener(ObjectListener<V> objectListener, int eventType);
	
	/**
	 * listener handler the event
	 */
	public void listenerHandler(List<ObjectListener<V>> objectListeners,ObjectEvent<V> event);
	
}
