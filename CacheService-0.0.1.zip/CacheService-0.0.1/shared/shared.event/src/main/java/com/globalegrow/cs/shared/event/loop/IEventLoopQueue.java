package com.globalegrow.cs.shared.event.loop;

import com.globalegrow.cs.shared.event.task.queue.ActionQueue;

public interface IEventLoopQueue<T> extends ActionQueue<T> {

	public void appendEvent(T event);
}
