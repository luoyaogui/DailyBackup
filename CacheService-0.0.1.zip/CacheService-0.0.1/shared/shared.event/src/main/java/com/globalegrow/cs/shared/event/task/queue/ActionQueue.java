package com.globalegrow.cs.shared.event.task.queue;

import java.util.Queue;

public interface ActionQueue<T> {

	public ActionQueue<T> getActionQueue();

	public void enqueue(T event);

	public void dequeue(T event);

	public void clear();

	public Queue<T> getQueue();
}
