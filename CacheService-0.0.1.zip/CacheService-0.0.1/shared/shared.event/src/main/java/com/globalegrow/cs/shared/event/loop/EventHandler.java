package com.globalegrow.cs.shared.event.loop;

import java.util.Collection;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Log;

public class EventHandler<E> implements IEventHandler<E> {
	protected IEventLoopQueue<EventHandler<E>> eventLoopQueue;
	protected Collection<PipelineObjectListener<E>> pipelineListeners ;
	protected ObjectEvent<E> event;
	protected Long createTime;
	
	public EventHandler(IEventLoopQueue<EventHandler<E>> eventLoopQueue,
			Collection<PipelineObjectListener<E>> pipelineListeners, ObjectEvent<E> event) {
		super();
		this.eventLoopQueue = eventLoopQueue;
		this.pipelineListeners = pipelineListeners;
		this.event = event;
		this.createTime = System.currentTimeMillis();
	}

	public EventHandler(Collection<PipelineObjectListener<E>> pipelineListeners, ObjectEvent<E> event) {
		super();
		this.pipelineListeners = pipelineListeners;
		this.event = event;
		this.createTime = System.currentTimeMillis();
	}
	
	public void setEventLoopQueueIfAbsent(IEventLoopQueue<EventHandler<E>> queue){
		synchronized (this) {
			if(this.eventLoopQueue == null){
				this.eventLoopQueue = queue;
			}
		}
	}
	
	public ObjectEvent<E> getEvent() {
		return event;
	}

	public void setEvent(ObjectEvent<E> event) {
		this.event = event;
	}

	@Override
	public void run() {
		boolean isAppend = false ;
		if (eventLoopQueue != null) {
			long start = System.currentTimeMillis();
			try {
				int listenerIndex = 1 ;
				for(PipelineObjectListener<E> pipeline: pipelineListeners){
					//get the last handler to Decide to append event loop queue
					isAppend = pipeline.onEvent(event, listenerIndex);
					listenerIndex++;
				}
				long end = System.currentTimeMillis();
				long interval = end - start;
				long leftTime = end - createTime;
				if (interval >= 1000) {
					System.err.println("execute action : " + this.toString() + ", interval : " + interval + ", leftTime : " + leftTime + ", size : " + eventLoopQueue.getQueue().size());
					Log.warn("execute action : " + this.toString() + ", interval : " + interval + ", leftTime : " + leftTime + ", size : " + eventLoopQueue.getQueue().size());
				}
			} catch (Exception e) {
				e.printStackTrace();
				Log.error("run action execute exception. action : " + this.toString()+e.getMessage());
			} finally {
				eventLoopQueue.dequeue(this);
				if(!isAppend){
					eventLoopQueue.appendEvent(this);
				}
			}
		}
	}
}
