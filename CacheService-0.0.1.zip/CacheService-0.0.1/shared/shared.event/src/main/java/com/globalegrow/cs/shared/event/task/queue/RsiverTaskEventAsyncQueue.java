package com.globalegrow.cs.shared.event.task.queue;

import com.globalegrow.cs.shared.event.ObjectEvent;

/**
 * 
 * 递归拉取消息队列实现
 * @author pengbingting
 *
 * @param <V>
 */
public class RsiverTaskEventAsyncQueue<V extends Action> extends TaskEventAsyncQueue<V> {

	public RsiverTaskEventAsyncQueue(Executor executor) {
		super(executor);
	}

	public RsiverTaskEventAsyncQueue(String executorName) {
		super(executorName);
	}

	@Override
	public void notifyListeners(ObjectEvent<V> event) {
		int eventType = event.getEventType();
		eventQueueInit(eventType);
		super.notifyListeners(event);
	}
}
