package com.globalegrow.cs.shared.event.pool;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.impl.AbandonedConfig;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import com.globalegrow.cs.shared.event.ObjectEvent;

public class ObjectEventFactory {

	protected static long defaultMinEvictableIdleTimeMillis = (long) 1000 * 60 * 60;//默认链接空闲时间
    protected static long defaultSoftMinEvictableIdleTimeMillis = (long) 1000 * 60 * 10;//
    protected static long defaultTimeBetweenEvictionRunsMillis = (long) 1000 * 60 * 10;//默认回收周期
	
	private GenericObjectPool<ObjectEvent<?>> objectEventPool = null ;
	protected GenericObjectPoolConfig poolConfig;
	protected BasePooledObjectFactory<ObjectEvent<?>> factory;
	public ObjectEventFactory() {
		initPool(false, 2<<8, 2<<10);
	}
	
	public ObjectEventFactory(int minIdle,int maxIdle){
		initPool(false, minIdle, maxIdle);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void initPool(boolean lazyInit,int minIdle,int maxIdle) {
        poolConfig = new GenericObjectPoolConfig();
        poolConfig.setMinIdle(1);  
        poolConfig.setMaxIdle(2);//假设每隔核有两个硬件线程  
        poolConfig.setTestOnReturn(false);  
        poolConfig.setTestOnBorrow(false);//每次borrow 的时候，都检测这个管道是否可用，直到拿到一根可用的NettyChannel
        poolConfig.setMaxTotal(2);  
        
        poolConfig.setMaxWaitMillis(1000);//3s
        poolConfig.setLifo(true);
        poolConfig.setMinEvictableIdleTimeMillis(defaultMinEvictableIdleTimeMillis); 
        poolConfig.setSoftMinEvictableIdleTimeMillis(defaultSoftMinEvictableIdleTimeMillis);
        poolConfig.setTimeBetweenEvictionRunsMillis(defaultTimeBetweenEvictionRunsMillis); 
        factory = new ObjectEventPool();

        objectEventPool = new GenericObjectPool<ObjectEvent<?>>(factory,poolConfig);
        
        AbandonedConfig abandonedConfig = new AbandonedConfig();
        abandonedConfig.setRemoveAbandonedOnMaintenance(true); //在Maintenance的时候检查是否有泄漏
        abandonedConfig.setRemoveAbandonedOnBorrow(true); //borrow 的时候检查泄漏
        /**
         * 设置一个被遗弃的对象，多少秒后可从池中移除：
         * 单位：s. 这里设置的是 半个小时
         */
        abandonedConfig.setRemoveAbandonedTimeout(60 * 30);
        objectEventPool.setAbandonedConfig(abandonedConfig);
        
        if (lazyInit) {
        	return ;
        }
        
        for (int i = 0; i < poolConfig.getMinIdle(); i++) {
        	try {
        		objectEventPool.addObject();
        	} catch (Exception e) {
        		e.printStackTrace();
        	}
        }
	}
	
	public ObjectEvent<?> borrowObjectEvent(){
		try {
			return objectEventPool.borrowObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null ;
	}
	
	public void returnObjectEvent(ObjectEvent<?> objectEvent){
		objectEventPool.returnObject(objectEvent);
	}
}
