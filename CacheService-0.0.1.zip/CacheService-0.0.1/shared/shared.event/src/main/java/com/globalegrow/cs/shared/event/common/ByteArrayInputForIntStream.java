package com.globalegrow.cs.shared.event.common;

import java.io.ByteArrayInputStream;

public class ByteArrayInputForIntStream extends ByteArrayInputStream {

	public ByteArrayInputForIntStream(byte[] buf) {
		super(buf);
	}

	public ByteArrayInputForIntStream(byte[] buf, int offset, int length) {
		super(buf, offset, length);
	}

	public int readInt(){
		byte b3 = (byte) read();
		byte b2 = (byte) read();
		byte b1 = (byte) read();
		byte b0 = (byte) read();
		
		return(((b3) << 24) | ((b2 & 0xff) << 16) | ((b1 & 0xff) <<  8) | ((b0 & 0xff))); 
	}
}
