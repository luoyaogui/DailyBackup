package com.globalegrow.cs.shared.event.loop;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineAbstractEventObject;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Executor;

/**
 * support for event loop groups
 * @author pengbingting
 *
 * @param <E>
 */
public abstract class AsyncEventLoopGroup<E> extends PipelineAbstractEventObject<E> {
	protected ConcurrentHashMap<Integer, EventLoopQueue<E>> eventLoopQueueGroup = new ConcurrentHashMap<Integer, EventLoopQueue<E>>();
	protected Executor executor = null ;
	protected long schedulerInterval;
	public AsyncEventLoopGroup(String executorName,boolean isOptimism) {
		super(isOptimism);
		int coreSize = Runtime.getRuntime().availableProcessors()*4;
		this.executor = new Executor(coreSize, 2 * coreSize ,60,TimeUnit.SECONDS, executorName);
	}
	
	public AsyncEventLoopGroup(Executor executor,boolean isOptimism) {
		super(isOptimism);
		this.executor = executor;
	}
	
	public AsyncEventLoopGroup(String executorName,long schedulerInterval) {
		super(true);
		this.schedulerInterval = schedulerInterval;
		int coreSize = Runtime.getRuntime().availableProcessors()*4;
		this.executor = new Executor(coreSize, 2 * coreSize ,60,TimeUnit.SECONDS, executorName);
	}
	
	public AsyncEventLoopGroup(Executor executor,long schedulerInterval) {
		super(true);
		this.schedulerInterval = schedulerInterval;
		this.executor = executor;
	}
	
	//then can call must add event loop queue
	@Override
	public void listenerHandler(List<PipelineObjectListener<E>> objectListeners, ObjectEvent<E> event) {
		int eventType = event.getEventType();
		eventLoopQueueGroup.putIfAbsent(eventType, new EventLoopQueue<E>(executor, schedulerInterval));
		eventLoopQueueGroup.get(eventType).enqueue(new EventHandler<E>(objectListeners, event));
	}
}
