package com.globalegrow.cs.shared.event.task.queue;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.ObjectListener;

/**
 * 基于事件驱动的 任务执行 async 队列
 * @author pengbingting
 *
 * @param <V>
 */
public class TaskEventAsyncQueue<V extends Action> implements ITaskEventQueue<V> {
	protected ConcurrentHashMap<Integer, TaskActionQueue> eventQueues = new ConcurrentHashMap<Integer, TaskActionQueue>();
	protected ReentrantLock lock = new ReentrantLock();
	protected Executor executor;
	
	public TaskEventAsyncQueue(String executorName){
		int coreSize = Runtime.getRuntime().availableProcessors()*4;
		int maxPoolSize = coreSize * 2;
		executor = new Executor(coreSize, maxPoolSize, 1, executorName);
	}
	
	public TaskEventAsyncQueue(Executor executor){
		this.executor = executor;
	}
	
	public void attachListener() {
		//nothing to do
	}

	public void removeListener(int queueTopic) {
		//nothing to do
	}

	public void removeTaskActionQueue(int queueTopic){
		eventQueues.remove(queueTopic);
	}
	
	public void notifyListeners(ObjectEvent<V> event) {
		eventQueues.get(event.getEventType()).enqueue(event.getValue());
	}

	public void clearListener() {
		//nothing to do
	}
	
	/**
	 * we call all of the queue is the collect of the handler topic.so you muster know one of the task will enqueue the queue by you point the topic
	 */
	public void publish(V v, int queueTopic) {
		notifyListeners(new ObjectEvent<V>(v, queueTopic));
	}
	/**
	 * you muster carefully call this method.after then all of queue will remove from the hash map
	 */
	public void clearTaskActionQueue() {
		eventQueues.clear();
	}

	public void listenerHandler(List<ObjectListener<V>> objectListeners, ObjectEvent<V> event) {
		
	}

	public void eventTypeInit() {
		
	}
	
	public void eventQueueInit(int queueTopic) {
		eventQueues.putIfAbsent(queueTopic, new TaskActionQueue(executor));//(queueTopic);
	}
}
