package com.globalegrow.cs.shared.event.task.queue;

import com.globalegrow.cs.shared.event.EventObject;

public interface ITaskEventQueue<V> extends EventObject<V> {
	
	/**
	 * can remove a type of topic queue
	 * @param queueTopic
	 */
	public void removeTaskActionQueue(int queueTopic);
	
	public void clearTaskActionQueue();
	
	public void eventQueueInit(int queueTopic);
}
