package com.globalegrow.cs.shared.event.queue;

import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import com.globalegrow.cs.shared.event.AbstractAsyncEventObject;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.ObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Command;
import com.globalegrow.cs.shared.event.task.queue.Executor;
import com.globalegrow.cs.shared.event.task.queue.TaskExecuteException;

/**
 * 提供线程安全的异步事件操作。基于reentrant lock 公平锁实现。这个经过测试发现在window 环境下性能比较高
 * @author pengbingting
 *
 * @param <V>
 */
public abstract class AbstractAsynEventReentQueue<V> extends AbstractAsyncEventObject<V> {

	private ConcurrentHashMap<Integer,ReentrantLockQueue<V>> queueRegister = new ConcurrentHashMap<Integer, AbstractAsynEventReentQueue<V>.ReentrantLockQueue<V>>() ;
	public abstract void attachListener() ;

	public AbstractAsynEventReentQueue(Executor executor, boolean isOptimism) {
		super(executor, isOptimism);
		eventQueueInit(listeners.keys());
	}

	public AbstractAsynEventReentQueue(String executorName, boolean isOptimism) {
		super(executorName, isOptimism);
		eventQueueInit(listeners.keys());
	}
	
	@Override
	public void addListener(ObjectListener<V> objectListener, int eventType) {
		super.addListener(objectListener, eventType);
	}
	
	@Override
	public void publish(V v, int eventType) {
		notifyListeners(new ObjectEvent<V>(v, eventType));
	}
	
	public void eventQueueInit(Enumeration<Integer> eventTypes){
		if(eventTypes == null || !eventTypes.hasMoreElements()){
			return ;
		}
		
		for(;eventTypes.hasMoreElements();){
			int eventType = eventTypes.nextElement().intValue();
			eventQueueInit(eventType);
		}
	}
	
	/**
	 * 动态添加(即：动态调用 addListener )的时候，需要手动触发该方法的执行。在attachListener 中调用的初始化添加不应该调用这个方法执行相关的初始化操作。
	 * 因为那个时候当前类还没有初始化完（是有父类进行回调子类的方法进行初始化操作的），queueRegister 对象还是 null 未初始化。
	 * @param eventType
	 */
	public void eventQueueInit(int eventType){
		ReentrantLockQueue<V> queue = queueRegister.get(eventType);
		if (queue == null) {
			synchronized (queueRegister) {
				queue = queueRegister.get(eventType);
				if (queue == null) {
					queue = new ReentrantLockQueue<V>(executor);
					queueRegister.put(eventType, queue);
				}
			}
		}
	}
	
	@Override
	public void removeListener(int eventType) {
		super.removeListener(eventType);
		queueRegister.remove(eventType);
	}
	
	/**
	 * 这将是代码热点区
	 */
	@Override
	public void listenerHandler(List<ObjectListener<V>> objectListeners, ObjectEvent<V> event) {
		queueRegister.get(event.getEventType()).handlerMessage(objectListeners, event);
	}
	
	@Override
	public void clearListener() {
		super.clearListener();
		this.queueRegister.clear();
	}
	
	@SuppressWarnings("hiding")
	public class ReentrantLockQueue<V> {
		private ReentrantLock lock = new ReentrantLock(true);
		private Executor executor ;
		
		public ReentrantLockQueue(Executor executor){
			this.executor = executor;
		}
		
		/**
		 * 异步串行
		 * @param objectListener
		 * @param objectEvent
		 */
		public void handlerMessage(List<ObjectListener<V>> objectListeners, ObjectEvent<V> objectEvent){
			executor.execute(new MessageTrriger<V>(objectListeners, objectEvent));
		}
		private class MessageTrriger<V> extends Command{
			private List<ObjectListener<V>> objectListeners ;
			private ObjectEvent<V> objectEvent ;
			public MessageTrriger(List<ObjectListener<V>> objectListeners, ObjectEvent<V> objectEvent) {
				super();
				this.objectListeners = objectListeners;
				this.objectEvent = objectEvent;
			}

			@Override
			public void execute() throws TaskExecuteException {
				lock.lock();
				try{
					for(ObjectListener<V> objectListener:objectListeners){
						objectListener.onEvent(objectEvent);
					}
				}finally{
					lock.unlock();
				}
			}
			
		}
	}

}
