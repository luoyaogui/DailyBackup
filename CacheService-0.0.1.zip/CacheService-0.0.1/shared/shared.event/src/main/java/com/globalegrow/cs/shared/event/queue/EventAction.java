package com.globalegrow.cs.shared.event.queue;

import java.util.List;

import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.ObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Action;
import com.globalegrow.cs.shared.event.task.queue.TaskExecuteException;

public class EventAction<V> extends Action{
	
	private List<ObjectListener<V>> objectListeners ;
	@SuppressWarnings("rawtypes")
	private ObjectEvent objectEvent ;
	public EventAction(List<ObjectListener<V>> objectListeners,ObjectEvent<?> objectEvent) {
		super();
		this.objectListeners = objectListeners;
		this.objectEvent = objectEvent;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void execute() throws TaskExecuteException {
		for(ObjectListener<V> objectListener:objectListeners){
			objectListener.onEvent(objectEvent);
		}
	}

}
