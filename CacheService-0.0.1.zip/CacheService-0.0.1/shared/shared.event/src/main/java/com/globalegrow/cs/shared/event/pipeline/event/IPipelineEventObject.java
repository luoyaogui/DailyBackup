package com.globalegrow.cs.shared.event.pipeline.event;

import java.util.List;

import com.globalegrow.cs.shared.event.EventObject;
import com.globalegrow.cs.shared.event.ObjectEvent;

public interface IPipelineEventObject<V> extends EventObject<V>{

	/**
	 * 添加某个事件类型的监听器。一个 eventType 可对应多个 object listener
	 * @param objectListener
	 * @param eventType
	 */
	public void addListener(PipelineObjectListener<V> objectListener, int eventType);
	
	/**
	 * 移除指定 event type 中的一个object listener
	 * @param objectListener
	 * @param eventType
	 */
	public void removeListener(PipelineObjectListener<V> objectListener, int eventType);

	/**
	 * 在某个事件类型后面添加一个新的 对象监听器
	 * @param objectListener
	 * @param eventType
	 */
	public void addLast(PipelineObjectListener<V> objectListener, int eventType);
	
	/**
	 * listener handler the event
	 */
	public void listenerHandler(List<PipelineObjectListener<V>> objectListeners,ObjectEvent<V> event);
	
}
