package com.globalegrow.cs.shared.event.loop;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import com.globalegrow.cs.shared.event.task.queue.Executor;
import com.globalegrow.cs.shared.event.task.queue.Log;

/**
 * the base implement of event loop queue.
 * @author pengbingting
 *
 * @param <E>
 */
public class EventLoopQueue<E> implements IEventLoopQueue<EventHandler<E>> {
	private Queue<EventHandler<E>> queue;
	private Queue<EventHandler<E>> appendQueue;
	private Executor executor;
	private ReentrantLock queueLock = new ReentrantLock();
	private ReentrantLock appendQueuelock = new ReentrantLock();
	protected volatile long schedulerInterval = 0;//ms
	public EventLoopQueue(Executor executor,long schedulerInterval) {
		this.executor = executor;
		queue = new LinkedList<EventHandler<E>>();
		this.schedulerInterval = TimeUnit.MILLISECONDS.toMillis(schedulerInterval);
	}

	public EventLoopQueue(Executor executor, Queue<EventHandler<E>> queue,long schedulerInterval) {
		this.executor = executor;
		this.queue = queue;
		this.schedulerInterval = schedulerInterval;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public IEventLoopQueue getActionQueue() {
		return this;
	}
	@Override
	public void clear() {
		
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Queue getQueue() {
		return queue;
	}

	@Override
	public void enqueue(EventHandler<E> eventHandler) {
		int queueSize = 0;
		eventHandler.setEventLoopQueueIfAbsent(this);
		queueLock.lock();
		try{
			queue.add(eventHandler);
			queueSize = queue.size();
		}finally{
			queueLock.unlock();
		}
		if (queueSize == 1) {
			executor.execute(eventHandler);
		}
		if (queueSize > 4 * Runtime.getRuntime().availableProcessors()) {
			 Log.warn(eventHandler.getEvent().getValue().toString() + " queue size : " + queueSize);
		}
	}

	@Override
	public void dequeue(EventHandler<E> eventHandler) {
		EventHandler<E> nextEventHandler = null;
		int queueSize = 0;
		String tmpString = null;
		queueLock.lock();
		try{
			queueSize = queue.size();
			EventHandler<E> temp = queue.remove();
			if (temp != eventHandler) {
				tmpString = temp.getEvent().getValue().toString();
			}
			if (queueSize != 0) {
				nextEventHandler = queue.peek();
			}
		}finally{
			queueLock.unlock();
		}

		if (nextEventHandler != null) {
			executor.execute(nextEventHandler);
		}
		if (queueSize == 0) {
			 Log.debug("queue.size() is 0.");
		}
		if (tmpString != null) {
			 Log.debug("action queue error. temp " + tmpString + ", action : " + eventHandler.getEvent().getValue().toString());
		}
	}

	@Override
	public void appendEvent(EventHandler<E> eventHandler) {
		//1、
		appendQueuelock.lock();
		try{
			if(appendQueue == null){
				appendQueue = new LinkedList<EventHandler<E>>();
			}
			appendQueue.add(eventHandler);
		}finally{
			appendQueuelock.unlock();
		}
		//2、
		int queueSize = 0;
		queueLock.lock();
		try{
			queueSize = queue.size();
		}finally{
			queueLock.unlock();
		}
		//3、
		if(queueSize==0){//一遍 遍历完成，等待多长时间to next loop
			try {
				TimeUnit.MILLISECONDS.sleep(schedulerInterval);
			} catch (InterruptedException e) {
				Log.debug("event loop group wait to trigger next cause an exception.",e);
			}
			appendQueuelock.lock();
			try{
				for(EventHandler<E> event:appendQueue){
					enqueue(event);
				}
				appendQueue.clear();
			}finally{
				appendQueuelock.unlock();
			}
		}
	}
	
}
