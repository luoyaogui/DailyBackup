package com.globalegrow.cs.shared.event.loop;

public interface IEventHandler<T> extends Runnable{

}
