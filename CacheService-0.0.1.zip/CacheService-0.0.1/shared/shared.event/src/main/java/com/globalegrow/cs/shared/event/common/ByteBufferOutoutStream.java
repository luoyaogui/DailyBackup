package com.globalegrow.cs.shared.event.common;

import java.io.IOException;
import java.io.OutputStream;

public class ByteBufferOutoutStream extends OutputStream {
	private ByteArrayOutputForIntStream byteArrayOutputForIntStream = null ;
	private OutputStream outputStream;
	private final static int DEFAULE_SIZE = 8192;
	private final static int FLUSH_FACTOR = 2;//控制刷新因子
	public ByteBufferOutoutStream(OutputStream outputStream) {
		this.outputStream = outputStream;
		byteArrayOutputForIntStream = new ByteArrayOutputForIntStream(DEFAULE_SIZE);
	}
	
	@Override
	public void write(int b) throws IOException {
		byteArrayOutputForIntStream.write(b);
		check();
	}

	@Override
	public void write(byte[] src) throws IOException{
		byteArrayOutputForIntStream.write(src);
		check();
	}
	
	@Override
	public void write(byte[] src,int offset,int len) throws IOException{
		byteArrayOutputForIntStream.write(src, offset, len);
		check();
	}

	private void check() throws IOException {
		int times = byteArrayOutputForIntStream.size() / DEFAULE_SIZE;
		if(times >FLUSH_FACTOR){
			flush();
		}
	}
	
	public void writeInt(int val) throws IOException{
		byteArrayOutputForIntStream.writeInt(val);
		check();
	}
	
	@Override
	public void flush() throws IOException {
		byteArrayOutputForIntStream.writeTo(outputStream);
		outputStream.flush();
		byteArrayOutputForIntStream.reset();
	}
	
	@Override
	public void close() throws IOException {
		outputStream.close();
		byteArrayOutputForIntStream.close();
	}
}
