
package com.globalegrow.cs.shared.event.task.queue;

public class TaskExecuteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TaskExecuteException() {
	}
	public TaskExecuteException(String message){
		super(message);
	}
}
