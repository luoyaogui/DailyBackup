package com.globalegrow.cs.shared.event;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 用来在个监听器之间进行参数传递的上下文
 * @author pengbingting
 *
 */
public class ObjectEventContext {
	
	/**
	 * 支持参数传递
	 */
	private ConcurrentHashMap<Object, Object> parametersMap = new ConcurrentHashMap<Object, Object>();
	
	private volatile Object[] indexParameter = null;
	
	public ObjectEventContext(int parameterCapacity) {
		indexParameter = new Object[parameterCapacity];
	}
	public ConcurrentHashMap<Object, Object> getParametersMap() {
		return parametersMap;
	}

	public List<Object> getIndexParameter() {
		
		return Arrays.asList(indexParameter);
	}

	public void setParameter(Object parameter,Object value){
		parametersMap.put(parameter, value);
	}
	
	public Object getParameter(Object object){
		return parametersMap.get(object);
	}
	
	public void setParameter(int index,Object value){
		
		indexParameter[index] = value ;
	}
	
	public Object getParameter(int index){
		if(indexParameter.length < index){
			return "";
		}
		
		return indexParameter[index];
	} 
}
