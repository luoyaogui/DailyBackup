package com.globalegrow.cs.shared.event.common;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ByteArrayOutputForIntStream extends ByteArrayOutputStream {
	
	public ByteArrayOutputForIntStream() {
		super();
	}

	public ByteArrayOutputForIntStream(int size) {
		super(size);
	}

	/**
	 * the default store mode is use the bigEndian
	 * @param value
	 * @return
	 */
	public ByteArrayOutputForIntStream writeInt(int value) throws IOException{
		byte[] byteVal = makeIntB(value);
		for(byte b:byteVal){
			write(b);
		}
		return this;
	}
	
	byte[] makeIntB(int value){
		byte[] intByteVal = new byte[4];
		intByteVal[0] = int3(value);
		intByteVal[1] = int2(value);
		intByteVal[2] = int1(value);
		intByteVal[3] = int0(value);
		return intByteVal;
	}
	
    private byte int3(int x) { return (byte)(x >> 24); }
    private byte int2(int x) { return (byte)(x >> 16); }
    private byte int1(int x) { return (byte)(x >>  8); }
    private byte int0(int x) { return (byte)(x      ); }
}
