package com.globalegrow.cs.shared.event.pool;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;

import com.globalegrow.cs.shared.event.ObjectEvent;

public class ObjectEventPool<V> extends BasePooledObjectFactory<ObjectEvent<V>> {

	@Override
	public ObjectEvent<V> create() throws Exception {
		return new ObjectEvent<V>();
	}

	@Override
	public PooledObject<ObjectEvent<V>> wrap(ObjectEvent<V> obj) {

		return new DefaultPooledObject<ObjectEvent<V>>(obj);
	}

}
