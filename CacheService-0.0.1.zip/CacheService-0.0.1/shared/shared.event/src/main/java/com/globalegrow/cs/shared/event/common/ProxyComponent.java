package com.globalegrow.cs.shared.event.common;

public interface ProxyComponent {

	public boolean init(String... params);
}
