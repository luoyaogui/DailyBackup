package com.globalegrow.cs.shared.event.queue;

import java.util.Enumeration;
import java.util.List;

import com.globalegrow.cs.shared.event.AbstractEventObject;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.ObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Action;
import com.globalegrow.cs.shared.event.task.queue.Executor;
import com.globalegrow.cs.shared.event.task.queue.ITaskEventQueue;
import com.globalegrow.cs.shared.event.task.queue.Log;
import com.globalegrow.cs.shared.event.task.queue.TaskEventAsyncQueue;

/**
 * 异步的 业务流水线的设计模型：
 * @author pengbingting
 *
 * @param <V>
 */
public abstract class AbstractAsynEventQueue<V> extends AbstractEventObject<V>{
	protected ITaskEventQueue<Action> taskEventQueue = null ;
	
	/**
	 * 预先初始化相关的 event type listener.如果需要在程序运行过程中添加。则手动调用dynamicAttachListener
	 */
	public abstract void attachListener() ;
	
	public abstract void dynamicAttachListener(int eventType,ObjectListener<V>... objectListener);
	/**
	 * 是否是乐观触发。true 表示乐观触发，将不会对一组listener 进行加锁处理。false 表示悲观触发。
	 * @param isOptimism
	 */
	public AbstractAsynEventQueue(boolean isOptimism){
		super(isOptimism);
		this.taskEventQueue = new TaskEventAsyncQueue<Action>("asyn-event-executor");
		eventQueueInit(listeners.keys());
	}
	
	public AbstractAsynEventQueue(Executor executor){
		super(false);
		this.taskEventQueue = new TaskEventAsyncQueue<Action>(executor);
		eventQueueInit(listeners.keys());
	}
	
	public AbstractAsynEventQueue(Executor executor,boolean isOptimism){
		super(false);
		super.isOptimism = isOptimism;
		this.taskEventQueue = new TaskEventAsyncQueue<Action>(executor);
		eventQueueInit(listeners.keys());
	}
	
	@Override
	public void addListener(ObjectListener<V> objectListener, int eventType) {
		super.addListener(objectListener, eventType);
	}
	
	public void removeListener(int eventType) {
		super.removeListener(eventType);
		taskEventQueue.removeTaskActionQueue(eventType);
	}
	
	@Override
	public void publish(V v, int eventType) {
		notifyListeners(new ObjectEvent<V>(v, eventType));
	}
	
	public void eventQueueInit(Enumeration<Integer> eventTypes){
		if(eventTypes == null || !eventTypes.hasMoreElements()){
			return ;
		}
		
		for(;eventTypes.hasMoreElements();){
			int eventType = eventTypes.nextElement().intValue();
			eventQueueInit(eventType);
		}
	}
	
	/**
	 * 队列形式
	 * @param eventType
	 */
	public void eventQueueInit(int eventType){
		taskEventQueue.eventQueueInit(eventType);
	}
	
	@Override
	public void listenerHandler(List<ObjectListener<V>> objectListeners, ObjectEvent<V> event) {
		if (objectListeners == null) {return;}
		try {
			taskEventQueue.publish(new EventAction<V>(objectListeners, event), event.getEventType());
		} catch (Exception e) {
			Log.error("publish a message to driver event action occur exception", e);
		}
	}
	
	/**
	 * will clear all of the listener and task action queue
	 */
	public void clearListener() {
		super.clearListener();
		taskEventQueue.clearTaskActionQueue();
	}
}
