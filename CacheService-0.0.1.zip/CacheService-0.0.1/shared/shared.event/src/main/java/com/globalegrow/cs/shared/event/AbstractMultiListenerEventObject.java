package com.globalegrow.cs.shared.event;

import java.util.List;

import com.globalegrow.cs.shared.event.task.queue.Command;
import com.globalegrow.cs.shared.event.task.queue.Executor;
import com.globalegrow.cs.shared.event.task.queue.TaskExecuteException;

/**
 * 支持多个消费者的执行模式
 * @author pengbingting
 *
 * @param <V>
 */
public abstract class AbstractMultiListenerEventObject<V> extends AbstractEventObject<V> {
	private Executor executor;
	public AbstractMultiListenerEventObject(Executor executor) {
		super();
		this.executor = executor;
	}

	public AbstractMultiListenerEventObject(boolean isOptimism,Executor executor) {
		super(isOptimism);
		this.executor = executor;
	}

	@Override
	public void listenerHandler(List<ObjectListener<V>> objectListeners, ObjectEvent<V> event) {
		for(ObjectListener<V> objectListener : objectListeners){
			executor.execute(new AsyncListenerTrigger(objectListener, event));
		}
	}
	
	public class AsyncListenerTrigger extends Command{
		private ObjectListener<V> objectListener;
		private ObjectEvent<V> event;
		public AsyncListenerTrigger(ObjectListener<V> objectListener,ObjectEvent<V> event) {
			super();
			this.objectListener = objectListener;
			this.event = event;
		}

		@Override
		public void execute() throws TaskExecuteException {
			objectListener.onEvent(event);
		}
	}
}
