package com.globalegrow.cs.shared.event.common;

/**
 * only to identify the semantics of being facade。
 * @author pengbingting
 *
 */
public interface Facade{

}
