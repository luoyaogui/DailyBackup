package com.globalegrow.cs.shared.event;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.globalegrow.cs.shared.event.pool.ObjectEventFactory;
import com.globalegrow.cs.shared.event.task.queue.Command;
import com.globalegrow.cs.shared.event.task.queue.Executor;
import com.globalegrow.cs.shared.event.task.queue.Log;
import com.globalegrow.cs.shared.event.task.queue.TaskExecuteException;

/**
 * please note:if you extends this class then all of the object listener must handler the problem in concurrent environment
 * @author pengbingting
 *
 * @param <V>
 */
public abstract class AbstractAsyncEventObject<V> extends AbstractEventObject<V> {
	protected Executor executor = null ;
	public AbstractAsyncEventObject(String executorName,boolean isOptimism) {
		super(isOptimism);
		int coreSize = Runtime.getRuntime().availableProcessors()*4;
		this.executor = new Executor(coreSize, 2 * coreSize ,60,TimeUnit.SECONDS, executorName);
	}
	
	public AbstractAsyncEventObject(String executorName,ObjectEventFactory objectEventFactory,boolean isOptimism){
		this(executorName,isOptimism);
		
		if(objectEventFactory == null){
			throw new IllegalArgumentException("objectEventFactory does not allow null");
		}
		this.objectEventFactory = objectEventFactory;
		this.isobjectEventPool = true;
	}
	
	public AbstractAsyncEventObject(Executor executor,boolean isOptimism) {
		super(isOptimism);
		this.executor = executor;
	}
	public AbstractAsyncEventObject(Executor executor,ObjectEventFactory objectEventFactory,boolean isOptimism) {
		super(objectEventFactory,isOptimism);
		this.executor = executor;
	}
	
	@Override
	public void listenerHandler(List<ObjectListener<V>> objectListeners, ObjectEvent<V> event) {
		// 触发,可以改造为异步触发
		if (objectListeners != null) {
			Log.info(event.getEventType() + " point to listener is start to run.");
			executor.execute(new AsyncEventTrigger(objectListeners, event));
		} else {
			Log.warn(event.getEventType() + " point to listener is null");
		}
	}
	public class AsyncEventTrigger extends Command{
		private List<ObjectListener<V>> tempList;
		private ObjectEvent<V> event;
		public AsyncEventTrigger(List<ObjectListener<V>> tempList,ObjectEvent<V> event) {
			super();
			this.tempList = tempList;
			this.event = event;
		}

		@Override
		public void execute() throws TaskExecuteException {
			try {
				for (ObjectListener<V> listener : tempList) {
					try {
						listener.onEvent(event);
					} catch (Exception e) {
						e.printStackTrace();
					}
				} 
			} finally {
				if(isobjectEventPool){
					objectEventFactory.returnObjectEvent(event);
				}
			}
		}
	}
}
