package shared.event.loop;

import java.util.concurrent.TimeUnit;
import com.globalegrow.cs.shared.event.ObjectEvent;
import com.globalegrow.cs.shared.event.loop.AsyncEventLoopGroup;
import com.globalegrow.cs.shared.event.pipeline.event.PipelineObjectListener;
import com.globalegrow.cs.shared.event.task.queue.Executor;

public class EventLoopTest extends AsyncEventLoopGroup<String> {
	
	public EventLoopTest(Executor executor, long loopInterval) {
		super(executor, loopInterval);
	}

	public EventLoopTest(String executorName, long loopInterval) {
		super(executorName, loopInterval);
	}

	public static void main(String[] args) {
		Executor executor = new Executor(4, 10, 1, TimeUnit.MINUTES, "test");
		EventLoopTest eventLoopTest = new EventLoopTest(executor,10);
		
	}

	@Override
	public void attachListener() {
		this.addLast(new PipelineObjectListener<String>() {
			
			@Override
			public boolean onEvent(ObjectEvent<String> event, int listenerIndex) {
				return false;
			}
		}, 1);
	}
	
}
