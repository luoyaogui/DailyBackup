package redis.clients.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;

public class IOUtils {
  private IOUtils() {
  }

  public static void closeQuietly(Socket sock) {
    // It's same thing as Apache Commons - IOUtils.closeQuietly()
    if (sock != null) {
      try {
        sock.close();
      } catch (IOException e) {
        // ignored
      }
    }
  }
  
	public static void writeInfo(String path, byte[] message,boolean isAppend) {
		File file = new File(path);
		try {
			if(!file.exists()) file.createNewFile();

			try(BufferedWriter writer = new BufferedWriter(new FileWriter(file,isAppend))){
				writer.write(new String(message));
				writer.flush();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
