package redis.clients.jedis.params.sortedset;

import redis.clients.jedis.params.Params;
import redis.clients.util.SafeEncoder;

import java.util.ArrayList;

public class ZAddParams extends Params {

  public static final String XX = "xx";
  public static final byte[] XX_BYTE = SafeEncoder.encode(XX);
  
  public static final String NX = "nx";
  public static final byte[] NX_BYTE = SafeEncoder.encode(NX);

  public static final String CH = "ch";
  public static final byte[] CH_BYTE = SafeEncoder.encode(CH);

  private ZAddParams() {
  }

  public static ZAddParams zAddParams() {
    return new ZAddParams();
  }

  /**
   * Only set the key if it does not already exist.
   * @return ZAddParams
   */
  public ZAddParams nx() {
    addParam(NX);
    return this;
  }

  /**
   * Only set the key if it already exist.
   * @return ZAddParams
   */
  public ZAddParams xx() {
    addParam(XX);
    return this;
  }

  /**
   * Modify the return value from the number of new elements added to the total number of elements
   * changed
   * @return ZAddParams
   */
  public ZAddParams ch() {
    addParam(CH);
    return this;
  }

  public byte[][] getByteParams(byte[] key, byte[]... args) {
    ArrayList<byte[]> byteParams = new ArrayList<byte[]>();
    byteParams.add(key);

    if (contains(NX)) {
      byteParams.add(SafeEncoder.encode(NX));
    }
    if (contains(XX)) {
      byteParams.add(SafeEncoder.encode(XX));
    }
    if (contains(CH)) {
      byteParams.add(SafeEncoder.encode(CH));
    }

    for (byte[] arg : args) {
      byteParams.add(arg);
    }

    return byteParams.toArray(new byte[byteParams.size()][]);
  }

  public static void main(String[] args) {
	byte[] tmp = ZAddParams.CH.getBytes();
	for(byte b:tmp){
		System.out.println(b);
	}
	
	byte[] t = SafeEncoder.encode(CH);
	for(byte b: t){
		System.out.println(b);
	}
	
  }
}
