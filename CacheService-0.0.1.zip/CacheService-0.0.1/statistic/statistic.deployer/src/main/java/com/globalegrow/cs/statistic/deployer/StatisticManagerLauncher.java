package com.globalegrow.cs.statistic.deployer;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
* Title: StatisticManagerLauncher
* Description: 统计启动类
* Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
* @author yaoguiluo
* @date 2017年5月8日 下午2:49:54
*/
public class StatisticManagerLauncher {
	private static final Logger logger = LoggerFactory.getLogger(StatisticManagerLauncher.class);

	public static void main(String[] args) {

		String conf = System.getProperty("cs.conf", "classpath:cs.properties");

		logger.info("## start the manager server.");

		final StatisticServer server = new StatisticServer(conf);
		try {
			server.start();
			Runtime.getRuntime().addShutdownHook(new Thread(){
				@Override
				public void run() {
					try {
						server.join();
					} catch (Exception e) {
						logger.error("## Something goes wrong when execute server.join():\n{}", 
								ExceptionUtils.getFullStackTrace(e));
					}
				}
			});
		} catch (Throwable e){
			logger.error("## Something goes wrong when starting up the manager Server:\n{}", 
					ExceptionUtils.getFullStackTrace(e));

			System.exit(0);
		}
	}
}