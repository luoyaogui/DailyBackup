package com.globalegrow.cs.statistic.deployer;

import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.globalegrow.cs.shared.common.utils.lifecycle.AbstractLifeCycle;

/**
 * Title: StatisticServer
 * Description: 统计服务类
 * Company: ShenZhen Globalegrow E-Commerce Co. ,Ltd. 
 * @author yaoguiluo
 * @date 2017年5月8日 下午2:50:50
 */
public class StatisticServer extends AbstractLifeCycle {
	private static final Logger logger = LoggerFactory.getLogger(StatisticServer.class);
	private String config;

		this.config = config;
		public StatisticServer(String config) {
	}

	public void start() {
		if(isStart())
			logger.error("##has started ! please checked");
		super.start();

		logger.error("##get config : " + this.config);
		if (logger.isInfoEnabled())
			logger.info("##Statistic Server is startup!");
	}

	public void join() throws Exception {
		TimeUnit.SECONDS.sleep(30000L);
		
		if (logger.isInfoEnabled())
			logger.info("##Statistic Server joined!");
	}

	public void stop() {
		super.stop();
		
		if (logger.isInfoEnabled())
			logger.info("##Statistic Server is stop!");
	}
}