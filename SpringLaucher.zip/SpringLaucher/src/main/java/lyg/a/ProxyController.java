package lyg.a;

public class ProxyController {
    public void start() {
    }
    
    private void checkIpAndPort(String ip,int port){
    }
    
    public String getUrl(){
    		return "test-url";
    }
}
