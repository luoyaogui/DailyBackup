package lyg.a;

import lyg.a.b.TestService;
import lyg.a.b.TestServiceImpl;

public class ProxyManagerLauncher{
	
	public static void main(String[] args) {

		final ProxyController server = ProxyContextLocator.getProxyController();
		final TestService service = ProxyContextLocator.getBean("testServiceImpl");
		
		try {
			System.err.println(server.getUrl());
			service.print();
			
			Runtime.getRuntime().addShutdownHook(new Thread(){
				@Override
				public void run() {
					try {
					} catch (Exception e) {
					}
				}
			});
		} catch (Throwable e){
			System.exit(0);
		}
	}
}