package lyg.a.b;

public interface TestService {

	void print();
}
