package lyg.a.b;

import org.springframework.stereotype.Service;

@Service
public class TestServiceImpl implements TestService {

	public void print() {
		System.err.println("\r\n--------------hello print ----------\r\n");
	}

}
